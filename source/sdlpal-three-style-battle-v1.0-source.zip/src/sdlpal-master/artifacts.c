/*
 * Artifact system: data, random generation, bag/equipment, sidecar and
 * combat modifier queries.
 *
 * UI lives in artifactmenu.c.
 */

#include "main.h"
#include "palcfg.h"
#include "artifacts.h"
#include "battle.h"
#include "actionbar.h"

#define ARTIFACT_FILE_MAGIC "DSHS001"
#define ARTIFACT_FILE_VERSION 1
#define ART_NOTICE_MAX 8
#define ART_NOTICE_CHARS 64
#define ART_NOTICE_MS 1400

static WCHAR s_rgszNotice[ART_NOTICE_MAX][ART_NOTICE_CHARS];
static int   s_iNoticeHead = 0;
static int   s_iNoticeTail = 0;
static int   s_iNoticeCount = 0;
static BOOL  s_fNoticeActive = FALSE;
static DWORD s_dwNoticeStart = 0;
static WCHAR s_szNoticeCurrent[ART_NOTICE_CHARS];
static WCHAR s_szNoticeLast[ART_NOTICE_CHARS];
static DWORD s_dwNoticeLastTick = 0;

typedef struct tagARTIFACT_TEMPLATE
{
   LPCWSTR lpszName;
   WORD    wBitmap;
} ARTIFACT_TEMPLATE;

typedef struct tagARTIFACT_AFFIX_DEF
{
   WORD    wId;
   BYTE    bRarity;
   BYTE    bMinTier;
   BYTE    bValueCount;
   WORD    rgValues[5];
} ARTIFACT_AFFIX_DEF;

enum
{
   ART_AFFIX_PROF_POWER = 0,
   ART_AFFIX_ENEMY_SLOW,
   ART_AFFIX_CHANT_UNBREAK,
   ART_AFFIX_START_METER,
   ART_AFFIX_HIT_METER,
   ART_AFFIX_SPEED_MAXHP,
   ART_AFFIX_REDUCE_PHYSICAL,
   ART_AFFIX_REDUCE_FIRE,
   ART_AFFIX_REDUCE_WIND,
   ART_AFFIX_REDUCE_LIGHTNING,
   ART_AFFIX_REDUCE_WATER,
   ART_AFFIX_REDUCE_EARTH,
   ART_AFFIX_REDUCE_POISON,
   ART_AFFIX_MP_ABSORB,
   ART_AFFIX_DAMAGE_CAP,
   ART_AFFIX_REFLECT,
   ART_AFFIX_HP_MP_SWAP,
   ART_AFFIX_MP_FIRST,
   ART_AFFIX_FAIL_ATTACK,
   ART_AFFIX_ABNORMAL_SPEED,
   ART_AFFIX_RANDOM_BUFF,
   ART_AFFIX_ITEM_SAVE,
   ART_AFFIX_COMBO,
   ART_AFFIX_POISON_HIT,
   ART_AFFIX_MULTI_HIT,
   ART_AFFIX_ELEMENT_ATTACK,
   ART_AFFIX_MAGIC_ALL,
   ART_AFFIX_MAGIC_SUPPORT,
   ART_AFFIX_MAGIC_FIVE,
   ART_AFFIX_MAGIC_POISON,
   ART_AFFIX_EXTRA_PROF,
   ART_AFFIX_DAMAGE_MP,
   ART_AFFIX_MAGIC_CRIT,
   ART_AFFIX_COUNT
};

static const ARTIFACT_TEMPLATE s_templates[] =
{
   { L"定風珠", 1 },
   { L"追日輪", 2 },
   { L"玄武甲", 3 },
   { L"不壞鏡", 4 },
   { L"天機盤", 5 },
   { L"乾坤袋", 6 },
   { L"誅仙劍", 7 },
   { L"破軍符", 8 },
   { L"太虛鏡", 9 },
   { L"五靈輪", 10 },
   { L"毒王鼎", 11 },
   { L"陰陽玉", 12 },
};

#define ARTIFACT_TEMPLATE_COUNT (sizeof(s_templates) / sizeof(s_templates[0]))

/*
 * Values are ordered from bMinTier upward. bRarity is the weight tier of the
 * affix itself; the actual rolled tier is clamped by item quality.
 */
static const ARTIFACT_AFFIX_DEF s_affixes[] =
{
   { ART_AFFIX_PROF_POWER,        5, 5, 0, { 0 } },
   { ART_AFFIX_ENEMY_SLOW,        5, 5, 1, { 3 } },
   { ART_AFFIX_CHANT_UNBREAK,     4, 4, 0, { 0 } },
   { ART_AFFIX_START_METER,       2, 2, 3, { 20, 35, 50 } },
   { ART_AFFIX_HIT_METER,         2, 2, 3, { 5, 10, 20 } },
   { ART_AFFIX_SPEED_MAXHP,       3, 3, 3, { 25, 40, 60 } },
   { ART_AFFIX_REDUCE_PHYSICAL,   4, 4, 1, { 80 } },
   { ART_AFFIX_REDUCE_FIRE,       4, 4, 1, { 80 } },
   { ART_AFFIX_REDUCE_WIND,       4, 4, 1, { 80 } },
   { ART_AFFIX_REDUCE_LIGHTNING,  4, 4, 1, { 80 } },
   { ART_AFFIX_REDUCE_WATER,      4, 4, 1, { 80 } },
   { ART_AFFIX_REDUCE_EARTH,      4, 4, 1, { 80 } },
   { ART_AFFIX_REDUCE_POISON,     4, 4, 1, { 80 } },
   { ART_AFFIX_MP_ABSORB,         2, 2, 3, { 5, 10, 15 } },
   { ART_AFFIX_DAMAGE_CAP,        5, 5, 1, { 40 } },
   { ART_AFFIX_REFLECT,           3, 3, 1, { 30 } },
   { ART_AFFIX_HP_MP_SWAP,        3, 3, 0, { 0 } },
   { ART_AFFIX_MP_FIRST,          3, 3, 0, { 0 } },
   { ART_AFFIX_FAIL_ATTACK,       1, 1, 0, { 0 } },
   { ART_AFFIX_ABNORMAL_SPEED,    2, 2, 1, { 20 } },
   { ART_AFFIX_RANDOM_BUFF,       2, 2, 0, { 0 } },
   { ART_AFFIX_ITEM_SAVE,         3, 3, 3, { 40, 60, 80 } },
   { ART_AFFIX_COMBO,             3, 3, 3, { 40, 60, 80 } },
   { ART_AFFIX_POISON_HIT,        3, 3, 0, { 0 } },
   { ART_AFFIX_MULTI_HIT,         2, 2, 3, { 2, 3, 4 } },
   { ART_AFFIX_ELEMENT_ATTACK,    2, 2, 1, { 20 } },
   { ART_AFFIX_MAGIC_ALL,         3, 3, 3, { 5, 10, 20 } },
   { ART_AFFIX_MAGIC_SUPPORT,     2, 2, 3, { 10, 15, 20 } },
   { ART_AFFIX_MAGIC_FIVE,        2, 2, 3, { 10, 15, 20 } },
   { ART_AFFIX_MAGIC_POISON,      2, 2, 3, { 10, 15, 20 } },
   { ART_AFFIX_EXTRA_PROF,        1, 1, 0, { 0 } },
   { ART_AFFIX_DAMAGE_MP,         1, 1, 1, { 10 } },
   { ART_AFFIX_MAGIC_CRIT,        1, 1, 5, { 10, 30, 50, 70, 90 } },
};

#define ARTIFACT_AFFIX_COUNT (sizeof(s_affixes) / sizeof(s_affixes[0]))

static const WORD s_rgwFiveMagic[] =
{
   313, 314, 315, 316, 317, 318, 319, 320, 321, 322, 323, 325,
   327, 328, 329, 330, 389, 332, 333, 334, 335, 336
};

static const WORD s_rgwPoisonMagic[] =
{
   303, 304, 305, 352, 354, 372, 374
};

static ARTIFACT_INSTANCE s_bag[MAX_ARTIFACTS];
static SHORT s_equipped[MAX_PLAYER_ROLES][ARTIFACT_SLOTS];
static DWORD s_dwLingChen;
static BOOL  s_fInitialized;
static int   s_iEnemySlowStacks;
static WORD  s_rgwOrigMaxHP[MAX_PLAYER_ROLES];
static WORD  s_rgwOrigHP[MAX_PLAYER_ROLES];
static WORD  s_rgwOrigMP[MAX_PLAYER_ROLES];
static BOOL  s_rgfMaxHPPenalty[MAX_PLAYER_ROLES];
static BOOL  s_rgfHPMPSwap[MAX_PLAYER_ROLES];

static const BYTE s_qualityCount[4] = { 2, 3, 4, 5 };
static const BYTE s_qualityMaxTier[4] = { 2, 3, 4, 5 };
static const WORD s_qualityWeights[4] = { 60, 30, 9, 1 };
static const WORD s_tierWeights[6] = { 0, 50, 30, 12, 6, 2 };

/*
 * Temporary no-drop list (2026-10-23).  Existing instances keep their
 * affixes; only newly generated artifacts stop rolling these.  Remove an ID
 * from this list to put it back into the drop pool.
 */
static const WORD s_rgwNoDropAffixes[] =
{
   ART_AFFIX_REDUCE_PHYSICAL,    /* 6  */
   ART_AFFIX_REDUCE_FIRE,        /* 7  */
   ART_AFFIX_REDUCE_WIND,        /* 8  */
   ART_AFFIX_REDUCE_LIGHTNING,   /* 9  */
   ART_AFFIX_REDUCE_WATER,       /* 10 */
   ART_AFFIX_REDUCE_EARTH,       /* 11 */
   ART_AFFIX_REDUCE_POISON,      /* 12 */
   ART_AFFIX_HP_MP_SWAP,         /* 16 */
   ART_AFFIX_FAIL_ATTACK,        /* 18 */
   ART_AFFIX_ABNORMAL_SPEED,     /* 19 */
   ART_AFFIX_ELEMENT_ATTACK,     /* 25 */
   ART_AFFIX_DAMAGE_MP,          /* 31 */
};

static BOOL
ART_IsAffixDroppable(
   WORD wAffix
)
{
   int i;

   for (i = 0; i < (int)(sizeof(s_rgwNoDropAffixes) / sizeof(s_rgwNoDropAffixes[0])); i++)
   {
      if (s_rgwNoDropAffixes[i] == wAffix)
      {
         return FALSE;
      }
   }
   return TRUE;
}

static VOID
ART_InitState(
   VOID
)
{
   int i, j;

   if (s_fInitialized)
   {
      return;
   }

   for (i = 0; i < MAX_ARTIFACTS; i++)
   {
      memset(&s_bag[i], 0, sizeof(ARTIFACT_INSTANCE));
   }

   for (i = 0; i < MAX_PLAYER_ROLES; i++)
   {
      for (j = 0; j < ARTIFACT_SLOTS; j++)
      {
         s_equipped[i][j] = -1;
      }
   }

   s_dwLingChen = 0;
   s_iEnemySlowStacks = 0;
   s_fInitialized = TRUE;
}

VOID
ART_Init(
   VOID
)
{
   ART_InitState();
   MAGICPROF_Init();
}

VOID
ART_Reset(
   VOID
)
{
   ART_InitState();
   s_fInitialized = FALSE;
   ART_InitState();
   MAGICPROF_Reset();
}

static const ARTIFACT_AFFIX_DEF *
ART_GetAffixDef(
   WORD wAffix
)
{
   int i;

   for (i = 0; i < (int)ARTIFACT_AFFIX_COUNT; i++)
   {
      if (s_affixes[i].wId == wAffix)
      {
         return &s_affixes[i];
      }
   }

   return NULL;
}

static BOOL
ART_IsReductionAffix(
   WORD wAffix
)
{
   return (wAffix >= ART_AFFIX_REDUCE_PHYSICAL && wAffix <= ART_AFFIX_REDUCE_POISON) ? TRUE : FALSE;
}

static BYTE
ART_ReductionType(
   WORD wAffix
)
{
   switch (wAffix)
   {
   case ART_AFFIX_REDUCE_PHYSICAL: return ART_DMG_PHYSICAL;
   case ART_AFFIX_REDUCE_FIRE: return ART_DMG_FIRE;
   case ART_AFFIX_REDUCE_WIND: return ART_DMG_WIND;
   case ART_AFFIX_REDUCE_LIGHTNING: return ART_DMG_LIGHTNING;
   case ART_AFFIX_REDUCE_WATER: return ART_DMG_WATER;
   case ART_AFFIX_REDUCE_EARTH: return ART_DMG_EARTH;
   case ART_AFFIX_REDUCE_POISON: return ART_DMG_POISON;
   default: return 0xFF;
   }
}

static WORD
ART_GetAffixValue(
   const ARTIFACT_AFFIX_DEF *lpDef,
   BYTE bTier
)
{
   int index;

   if (lpDef->bValueCount == 0)
   {
      return 0;
   }

   if (bTier < lpDef->bMinTier)
   {
      bTier = lpDef->bMinTier;
   }

   index = (int)bTier - (int)lpDef->bMinTier;
   if (index < 0)
   {
      index = 0;
   }
   if (index >= lpDef->bValueCount)
   {
      index = lpDef->bValueCount - 1;
   }

   return lpDef->rgValues[index];
}

static BYTE
ART_RollQuality(
   VOID
)
{
   WORD roll = (WORD)RandomLong(0, 99);
   WORD acc = 0;
   int i;

   for (i = 0; i < 4; i++)
   {
      acc += s_qualityWeights[i];
      if (roll < acc)
      {
         return (BYTE)i;
      }
   }

   return ARTIFACT_QUALITY_WHITE;
}

static BYTE
ART_RollTier(
   BYTE bQuality
)
{
   BYTE maxTier = s_qualityMaxTier[bQuality];
   WORD roll = (WORD)RandomLong(0, 99);
   WORD acc = 0;
   BYTE tier;

   for (tier = 1; tier <= maxTier; tier++)
   {
      acc += s_tierWeights[tier];
      if (roll < acc)
      {
         return tier;
      }
   }

   return maxTier;
}

static BOOL
ART_HasAffix(
   const ARTIFACT_INSTANCE *lpInstance,
   WORD wAffix
)
{
   int i;

   for (i = 0; i < lpInstance->bAffixCount; i++)
   {
      if (lpInstance->affixes[i].wAffix == wAffix)
      {
         return TRUE;
      }
   }

   return FALSE;
}

static BOOL
ART_HasReductionType(
   const ARTIFACT_INSTANCE *lpInstance,
   BYTE bType
)
{
   int i;

   for (i = 0; i < lpInstance->bAffixCount; i++)
   {
      if (ART_IsReductionAffix(lpInstance->affixes[i].wAffix) &&
         ART_ReductionType(lpInstance->affixes[i].wAffix) == bType)
      {
         return TRUE;
      }
   }

   return FALSE;
}

static VOID
ART_GenerateInstance(
   ARTIFACT_INSTANCE *lpInstance,
   BYTE bForcedQuality,
   BOOL fForceQuality
)
{
   int i;

   memset(lpInstance, 0, sizeof(ARTIFACT_INSTANCE));
   lpInstance->fUsed = TRUE;
   lpInstance->wTemplate = (WORD)RandomLong(0, (int)ARTIFACT_TEMPLATE_COUNT - 1);
   lpInstance->bQuality = fForceQuality ? bForcedQuality : ART_RollQuality();
   lpInstance->bAffixCount = s_qualityCount[lpInstance->bQuality];

   for (i = 0; i < lpInstance->bAffixCount; i++)
   {
      int tries = 0;
      WORD wAffix = 0;
      BYTE bTier = 1;

      while (tries++ < 100)
      {
         WORD total = 0;
         WORD roll;
         int j;
         int selected = -1;

         for (j = 0; j < (int)ARTIFACT_AFFIX_COUNT; j++)
         {
            if (s_affixes[j].bMinTier <= s_qualityMaxTier[lpInstance->bQuality] &&
               ART_IsAffixDroppable(s_affixes[j].wId) &&
               !ART_HasAffix(lpInstance, s_affixes[j].wId))
            {
               total += s_tierWeights[s_affixes[j].bRarity];
            }
         }

         if (total == 0)
         {
            break;
         }

         roll = (WORD)RandomLong(0, (int)total - 1);
         for (j = 0; j < (int)ARTIFACT_AFFIX_COUNT; j++)
         {
            if (s_affixes[j].bMinTier > s_qualityMaxTier[lpInstance->bQuality] ||
               !ART_IsAffixDroppable(s_affixes[j].wId) ||
               ART_HasAffix(lpInstance, s_affixes[j].wId))
            {
               continue;
            }

            if (roll < s_tierWeights[s_affixes[j].bRarity])
            {
               selected = j;
               break;
            }
            roll -= s_tierWeights[s_affixes[j].bRarity];
         }

         if (selected < 0)
         {
            continue;
         }

         wAffix = s_affixes[selected].wId;
         bTier = ART_RollTier(lpInstance->bQuality);
         if (bTier < s_affixes[selected].bMinTier)
         {
            bTier = s_affixes[selected].bMinTier;
         }

         if (ART_IsReductionAffix(wAffix) &&
            ART_HasReductionType(lpInstance, ART_ReductionType(wAffix)))
         {
            continue;
         }

         lpInstance->affixes[i].wAffix = wAffix;
         lpInstance->affixes[i].bTier = bTier;
         lpInstance->affixes[i].wValue = ART_GetAffixValue(&s_affixes[selected], bTier);
         break;
      }
   }
}

INT
ART_GetFirstFreeBagSlot(
   VOID
)
{
   int i;

   ART_InitState();
   for (i = 0; i < MAX_ARTIFACTS; i++)
   {
      if (!s_bag[i].fUsed)
      {
         return i;
      }
   }

   return -1;
}

INT
ART_AddInstance(
   const ARTIFACT_INSTANCE *lpInstance,
   BOOL *pfAutoDismantled
)
{
   int i;
   BYTE quality = lpInstance->bQuality;

   ART_InitState();
   if (pfAutoDismantled != NULL)
   {
      *pfAutoDismantled = FALSE;
   }

   i = ART_GetFirstFreeBagSlot();
   if (i < 0)
   {
      if (pfAutoDismantled != NULL)
      {
         *pfAutoDismantled = TRUE;
      }
      s_dwLingChen += (quality == ARTIFACT_QUALITY_WHITE) ? 1 :
         (quality == ARTIFACT_QUALITY_BLUE) ? 2 :
         (quality == ARTIFACT_QUALITY_RED) ? 4 : 10;
      return -1;
   }

   s_bag[i] = *lpInstance;
   s_bag[i].fUsed = TRUE;
   return i;
}

ARTIFACT_INSTANCE *
ART_GetInstance(
   int iIndex
)
{
   ART_InitState();
   if (iIndex < 0 || iIndex >= MAX_ARTIFACTS || !s_bag[iIndex].fUsed)
   {
      return NULL;
   }

   return &s_bag[iIndex];
}

INT
ART_GetBagCount(
   VOID
)
{
   int i, count = 0;

   ART_InitState();
   for (i = 0; i < MAX_ARTIFACTS; i++)
   {
      if (s_bag[i].fUsed)
      {
         count++;
      }
   }

   return count;
}

INT
ART_GetBagIndexByOrdinal(
   int iOrdinal
)
{
   int i;

   ART_InitState();
   for (i = 0; i < MAX_ARTIFACTS; i++)
   {
      if (s_bag[i].fUsed)
      {
         if (iOrdinal == 0)
         {
            return i;
         }
         iOrdinal--;
      }
   }

   return -1;
}

INT
ART_GetUnequippedBagCount(
   VOID
)
{
   int i, count = 0;

   ART_InitState();
   for (i = 0; i < MAX_ARTIFACTS; i++)
   {
      if (s_bag[i].fUsed && !ART_IsInstanceEquipped(i, NULL, NULL))
      {
         count++;
      }
   }

   return count;
}

INT
ART_GetUnequippedBagIndexByOrdinal(
   int iOrdinal
)
{
   int i;

   ART_InitState();
   for (i = 0; i < MAX_ARTIFACTS; i++)
   {
      if (s_bag[i].fUsed && !ART_IsInstanceEquipped(i, NULL, NULL))
      {
         if (iOrdinal == 0)
         {
            return i;
         }
         iOrdinal--;
      }
   }

   return -1;
}

BOOL
ART_IsInstanceEquipped(
   int iIndex,
   int *piRole,
   int *piSlot
)
{
   int r, s;

   ART_InitState();
   for (r = 0; r < MAX_PLAYER_ROLES; r++)
   {
      for (s = 0; s < ARTIFACT_SLOTS; s++)
      {
         if (s_equipped[r][s] == iIndex)
         {
            if (piRole != NULL) *piRole = r;
            if (piSlot != NULL) *piSlot = s;
            return TRUE;
         }
      }
   }

   return FALSE;
}

INT
ART_GetEquipped(
   int iRole,
   int iSlot
)
{
   ART_InitState();
   if (iRole < 0 || iRole >= MAX_PLAYER_ROLES ||
      iSlot < 0 || iSlot >= ARTIFACT_SLOTS)
   {
      return -1;
   }

   return s_equipped[iRole][iSlot];
}

BOOL
ART_Equip(
   int iRole,
   int iSlot,
   int iIndex
)
{
   int r, s;

   ART_InitState();
   if (iRole < 0 || iRole >= MAX_PLAYER_ROLES ||
      iSlot < 0 || iSlot >= ARTIFACT_SLOTS ||
      iIndex < 0 || iIndex >= MAX_ARTIFACTS || !s_bag[iIndex].fUsed)
   {
      return FALSE;
   }

   for (r = 0; r < MAX_PLAYER_ROLES; r++)
   {
      for (s = 0; s < ARTIFACT_SLOTS; s++)
      {
         if (s_equipped[r][s] == iIndex)
         {
            s_equipped[r][s] = -1;
         }
      }
   }

   s_equipped[iRole][iSlot] = (SHORT)iIndex;
   return TRUE;
}

VOID
ART_Unequip(
   int iRole,
   int iSlot
)
{
   ART_InitState();
   if (iRole >= 0 && iRole < MAX_PLAYER_ROLES &&
      iSlot >= 0 && iSlot < ARTIFACT_SLOTS)
   {
      s_equipped[iRole][iSlot] = -1;
   }
}

VOID
ART_RemoveInstance(
   int iIndex
)
{
   int r, s;

   if (iIndex < 0 || iIndex >= MAX_ARTIFACTS)
   {
      return;
   }

   for (r = 0; r < MAX_PLAYER_ROLES; r++)
   {
      for (s = 0; s < ARTIFACT_SLOTS; s++)
      {
         if (s_equipped[r][s] == iIndex)
         {
            s_equipped[r][s] = -1;
         }
      }
   }

   memset(&s_bag[iIndex], 0, sizeof(ARTIFACT_INSTANCE));
}

VOID
ART_Dismantle(
   int iIndex
)
{
   ARTIFACT_INSTANCE *lpInstance = ART_GetInstance(iIndex);

   if (lpInstance == NULL)
   {
      return;
   }

   s_dwLingChen += (lpInstance->bQuality == ARTIFACT_QUALITY_WHITE) ? 1 :
      (lpInstance->bQuality == ARTIFACT_QUALITY_BLUE) ? 2 :
      (lpInstance->bQuality == ARTIFACT_QUALITY_RED) ? 4 : 10;
   ART_RemoveInstance(iIndex);
}

DWORD
ART_GetLingChen(
   VOID
)
{
   ART_InitState();
   return s_dwLingChen;
}

VOID
ART_AddLingChen(
   DWORD dwAmount
)
{
   ART_InitState();
   s_dwLingChen += dwAmount;
}

LPCWSTR
ART_GetTemplateName(
   WORD wTemplate
)
{
   if (wTemplate >= ARTIFACT_TEMPLATE_COUNT)
   {
      return L"未知法寶";
   }

   return s_templates[wTemplate].lpszName;
}

WORD
ART_GetTemplateBitmap(
   WORD wTemplate
)
{
   if (wTemplate >= ARTIFACT_TEMPLATE_COUNT)
   {
      return 0;
   }

   return s_templates[wTemplate].wBitmap;
}

LPCWSTR
ART_GetQualityName(
   BYTE bQuality
)
{
   static const LPCWSTR names[4] = { L"白", L"藍", L"紅", L"金" };

   return names[bQuality & 3];
}

BYTE
ART_GetQualityColor(
   BYTE bQuality
)
{
   static const BYTE colors[4] = { 0x4F, 0x5B, 0x1B, 0x2A };

   return colors[bQuality & 3];
}

LPCWSTR
ART_GetAffixName(
   WORD wAffix
)
{
   switch (wAffix)
   {
   case ART_AFFIX_PROF_POWER: return L"慧根";
   case ART_AFFIX_ENEMY_SLOW: return L"遲滯";
   case ART_AFFIX_CHANT_UNBREAK: return L"定心";
   case ART_AFFIX_START_METER: return L"先發";
   case ART_AFFIX_HIT_METER: return L"受擊回氣";
   case ART_AFFIX_SPEED_MAXHP: return L"時間債";
   case ART_AFFIX_REDUCE_PHYSICAL: return L"無相";
   case ART_AFFIX_REDUCE_FIRE: return L"避火";
   case ART_AFFIX_REDUCE_WIND: return L"御風";
   case ART_AFFIX_REDUCE_LIGHTNING: return L"雷遁";
   case ART_AFFIX_REDUCE_WATER: return L"水靈";
   case ART_AFFIX_REDUCE_EARTH: return L"土德";
   case ART_AFFIX_REDUCE_POISON: return L"百毒不侵";
   case ART_AFFIX_MP_ABSORB: return L"納氣";
   case ART_AFFIX_DAMAGE_CAP: return L"不壞";
   case ART_AFFIX_REFLECT: return L"反傷";
   case ART_AFFIX_HP_MP_SWAP: return L"氣血互換";
   case ART_AFFIX_MP_FIRST: return L"真氣護體";
   case ART_AFFIX_FAIL_ATTACK: return L"失手反攻";
   case ART_AFFIX_ABNORMAL_SPEED: return L"受咒加速";
   case ART_AFFIX_RANDOM_BUFF: return L"吉星";
   case ART_AFFIX_ITEM_SAVE: return L"物品節省";
   case ART_AFFIX_COMBO: return L"連擊";
   case ART_AFFIX_POISON_HIT: return L"淬毒";
   case ART_AFFIX_MULTI_HIT: return L"多段";
   case ART_AFFIX_ELEMENT_ATTACK: return L"元素附魔";
   case ART_AFFIX_MAGIC_ALL: return L"仙術強化";
   case ART_AFFIX_MAGIC_SUPPORT: return L"輔助強化";
   case ART_AFFIX_MAGIC_FIVE: return L"五靈強化";
   case ART_AFFIX_MAGIC_POISON: return L"毒蠱強化";
   case ART_AFFIX_EXTRA_PROF: return L"熟能生巧";
   case ART_AFFIX_DAMAGE_MP: return L"以血換氣";
   case ART_AFFIX_MAGIC_CRIT: return L"仙術暴擊";
   default: return L"未知";
   }
}

VOID
ART_GetAffixDesc(
   const ARTIFACT_INSTANCE *lpInstance,
   int iAffix,
   LPWSTR lpBuffer,
   int iBufferChars
)
{
   const ARTIFACT_AFFIX_DEF *lpDef;
   WORD wAffix;
   WORD wValue;

   if (lpBuffer == NULL || iBufferChars <= 0)
   {
      return;
   }

   lpBuffer[0] = 0;
   if (lpInstance == NULL || iAffix < 0 || iAffix >= lpInstance->bAffixCount)
   {
      return;
   }

   wAffix = lpInstance->affixes[iAffix].wAffix;
   wValue = lpInstance->affixes[iAffix].wValue;
   lpDef = ART_GetAffixDef(wAffix);

   switch (wAffix)
   {
   case ART_AFFIX_PROF_POWER:
      PAL_swprintf(lpBuffer, iBufferChars, L"熟練度不再加速/瞬發，每點 +0.3%% 仙術威力");
      break;
   case ART_AFFIX_ENEMY_SLOW:
      PAL_swprintf(lpBuffer, iBufferChars, L"每回合敵人速度 -%u%%，上限 30%%", wValue);
      break;
   case ART_AFFIX_CHANT_UNBREAK:
      PAL_swprintf(lpBuffer, iBufferChars, L"吟唱不可被傷害打斷（死亡/異常除外）");
      break;
   case ART_AFFIX_START_METER:
      PAL_swprintf(lpBuffer, iBufferChars, L"戰鬥開始行動條 +%u%%", wValue);
      break;
   case ART_AFFIX_HIT_METER:
      PAL_swprintf(lpBuffer, iBufferChars, L"每受一次傷害，行動條 +%u%%", wValue);
      break;
   case ART_AFFIX_SPEED_MAXHP:
      PAL_swprintf(lpBuffer, iBufferChars, L"速度 +%u%%，最大生命 -30%%", wValue);
      break;
   case ART_AFFIX_REDUCE_PHYSICAL:
   case ART_AFFIX_REDUCE_FIRE:
   case ART_AFFIX_REDUCE_WIND:
   case ART_AFFIX_REDUCE_LIGHTNING:
   case ART_AFFIX_REDUCE_WATER:
   case ART_AFFIX_REDUCE_EARTH:
   case ART_AFFIX_REDUCE_POISON:
      {
         static const LPCWSTR types[] = { L"物理", L"火系", L"風系", L"雷系", L"水系", L"土系", L"毒蠱" };
         PAL_swprintf(lpBuffer, iBufferChars, L"受到%ls傷害 -%u%%，其他類型傷害 +20%%",
            types[ART_ReductionType(wAffix)], wValue);
      }
      break;
   case ART_AFFIX_MP_ABSORB:
      PAL_swprintf(lpBuffer, iBufferChars, L"受到傷害的 %u%% 吸收為真氣", wValue);
      break;
   case ART_AFFIX_DAMAGE_CAP:
      PAL_swprintf(lpBuffer, iBufferChars, L"單次受到傷害不超過最大生命 %u%%（毒傷除外）", wValue);
      break;
   case ART_AFFIX_REFLECT:
      PAL_swprintf(lpBuffer, iBufferChars, L"反彈 %u%% 物理/仙術傷害（不反毒/環境/不連鎖）", wValue);
      break;
   case ART_AFFIX_HP_MP_SWAP:
      PAL_swprintf(lpBuffer, iBufferChars, L"戰鬥開始當前氣血與真氣百分比互換");
      break;
   case ART_AFFIX_MP_FIRST:
      PAL_swprintf(lpBuffer, iBufferChars, L"受到攻擊時優先消耗真氣（1MP=1HP）");
      break;
   case ART_AFFIX_FAIL_ATTACK:
      PAL_swprintf(lpBuffer, iBufferChars, L"概率仙術失敗時追加一次普通攻擊");
      break;
   case ART_AFFIX_ABNORMAL_SPEED:
      PAL_swprintf(lpBuffer, iBufferChars, L"我方受異常狀態時速度 +%u%%", wValue);
      break;
   case ART_AFFIX_RANDOM_BUFF:
      PAL_swprintf(lpBuffer, iBufferChars, L"戰鬥開始獲得隨機增益");
      break;
   case ART_AFFIX_ITEM_SAVE:
      PAL_swprintf(lpBuffer, iBufferChars, L"使用物品 %u%% 概率不消耗", wValue);
      break;
   case ART_AFFIX_COMBO:
      PAL_swprintf(lpBuffer, iBufferChars, L"普攻 %u%% 概率追加一次攻擊", wValue);
      break;
   case ART_AFFIX_POISON_HIT:
      PAL_swprintf(lpBuffer, iBufferChars, L"普攻附帶一次隨機高級毒");
      break;
   case ART_AFFIX_MULTI_HIT:
      PAL_swprintf(lpBuffer, iBufferChars, L"普攻必定攻擊 %u 次", wValue);
      break;
   case ART_AFFIX_ELEMENT_ATTACK:
      PAL_swprintf(lpBuffer, iBufferChars, L"普攻傷害 +%u%% 並轉為隨機元素", wValue);
      break;
   case ART_AFFIX_MAGIC_ALL:
      PAL_swprintf(lpBuffer, iBufferChars, L"所有仙術威力 +%u%%", wValue);
      break;
   case ART_AFFIX_MAGIC_SUPPORT:
      PAL_swprintf(lpBuffer, iBufferChars, L"輔助仙術威力 +%u%%", wValue);
      break;
   case ART_AFFIX_MAGIC_FIVE:
      PAL_swprintf(lpBuffer, iBufferChars, L"五靈仙術威力 +%u%%", wValue);
      break;
   case ART_AFFIX_MAGIC_POISON:
      PAL_swprintf(lpBuffer, iBufferChars, L"毒蠱仙術威力 +%u%%", wValue);
      break;
   case ART_AFFIX_EXTRA_PROF:
      PAL_swprintf(lpBuffer, iBufferChars, L"每次成功施法額外 +1 熟練度");
      break;
   case ART_AFFIX_DAMAGE_MP:
      PAL_swprintf(lpBuffer, iBufferChars, L"每次施法受到 %u 傷害，回復 %u 真氣", wValue, wValue);
      break;
   case ART_AFFIX_MAGIC_CRIT:
      PAL_swprintf(lpBuffer, iBufferChars, L"仙術 %u%% 概率暴擊，暴擊 200%%", wValue);
      break;
   default:
      if (lpDef == NULL)
      {
         PAL_swprintf(lpBuffer, iBufferChars, L"未知詞條");
      }
      break;
   }
}

/* ---------------------------------------------------------------- */
/* Sidecar                                                          */
/* ---------------------------------------------------------------- */

static const char *
ART_SidecarPath(
   int iSaveSlot,
   char *lpBuffer,
   int iBufferSize
)
{
   const char *path = gConfig.pszSavePath;

   if (path == NULL || path[0] == '\0')
   {
      path = (gConfig.pszGamePath != NULL) ? gConfig.pszGamePath : ".";
   }

   snprintf(lpBuffer, iBufferSize, "%s/%d.dshs", path, iSaveSlot);
   return lpBuffer;
}

BOOL
ART_LoadSidecar(
   int iSaveSlot
)
{
   FILE *fp;
   char path[512];
   char magic[8];
   WORD version, roles, magicCount, artifactCount;
   WORD prof[MAX_PLAYER_ROLES][MAGICPROF_MAGIC_COUNT];
   int i, j;

   ART_Reset();

   ART_SidecarPath(iSaveSlot, path, sizeof(path));
   fp = fopen(path, "rb");
   if (fp == NULL)
   {
      return FALSE;
   }

   if (fread(magic, 1, 8, fp) != 8 || memcmp(magic, ARTIFACT_FILE_MAGIC, 8) != 0 ||
      fread(&version, sizeof(WORD), 1, fp) != 1 ||
      fread(&roles, sizeof(WORD), 1, fp) != 1 ||
      fread(&magicCount, sizeof(WORD), 1, fp) != 1 ||
      fread(&artifactCount, sizeof(WORD), 1, fp) != 1)
   {
      fclose(fp);
      return FALSE;
   }

   if (version != ARTIFACT_FILE_VERSION || roles != MAX_PLAYER_ROLES ||
      (magicCount != 55 && magicCount != MAGICPROF_MAGIC_COUNT) ||
      artifactCount != MAX_ARTIFACTS)
   {
      fclose(fp);
      return FALSE;
   }

   memset(prof, 0, sizeof(prof));
   if (magicCount == 55)
   {
      WORD oldProf[MAX_PLAYER_ROLES][55];
      if (fread(oldProf, sizeof(WORD), MAX_PLAYER_ROLES * 55, fp) !=
         MAX_PLAYER_ROLES * 55)
      {
         fclose(fp);
         return FALSE;
      }
      for (i = 0; i < MAX_PLAYER_ROLES; i++)
      {
         memcpy(prof[i], oldProf[i], sizeof(oldProf[i]));
      }
   }
   else if (fread(prof, sizeof(WORD), MAX_PLAYER_ROLES * MAGICPROF_MAGIC_COUNT, fp) !=
      MAX_PLAYER_ROLES * MAGICPROF_MAGIC_COUNT)
   {
      fclose(fp);
      return FALSE;
   }
   MAGICPROF_Import(&prof[0][0]);

   for (i = 0; i < MAX_ARTIFACTS; i++)
   {
      BYTE used;

      if (fread(&used, 1, 1, fp) != 1 ||
         fread(&s_bag[i].wTemplate, sizeof(WORD), 1, fp) != 1 ||
         fread(&s_bag[i].bQuality, 1, 1, fp) != 1 ||
         fread(&s_bag[i].bAffixCount, 1, 1, fp) != 1)
      {
         fclose(fp);
         ART_Reset();
         return FALSE;
      }

      s_bag[i].fUsed = used ? TRUE : FALSE;
      for (j = 0; j < ARTIFACT_MAX_AFFIXES; j++)
      {
         if (fread(&s_bag[i].affixes[j].wAffix, sizeof(WORD), 1, fp) != 1 ||
            fread(&s_bag[i].affixes[j].wValue, sizeof(WORD), 1, fp) != 1 ||
            fread(&s_bag[i].affixes[j].bTier, 1, 1, fp) != 1)
         {
            fclose(fp);
            ART_Reset();
            return FALSE;
         }
      }
   }

   for (i = 0; i < MAX_PLAYER_ROLES; i++)
   {
      for (j = 0; j < ARTIFACT_SLOTS; j++)
      {
         if (fread(&s_equipped[i][j], sizeof(SHORT), 1, fp) != 1)
         {
            fclose(fp);
            ART_Reset();
            return FALSE;
         }
      }
   }

   if (fread(&s_dwLingChen, sizeof(DWORD), 1, fp) != 1)
   {
      fclose(fp);
      ART_Reset();
      return FALSE;
   }

   fclose(fp);
   return TRUE;
}

BOOL
ART_SaveSidecar(
   int iSaveSlot
)
{
   FILE *fp;
   char path[512];
   char magic[8] = ARTIFACT_FILE_MAGIC;
   WORD version = ARTIFACT_FILE_VERSION;
   WORD roles = MAX_PLAYER_ROLES;
   WORD magicCount = MAGICPROF_MAGIC_COUNT;
   WORD artifactCount = MAX_ARTIFACTS;
   WORD prof[MAX_PLAYER_ROLES][MAGICPROF_MAGIC_COUNT];
   int i, j;

   ART_InitState();
   MAGICPROF_Export(&prof[0][0]);

   ART_SidecarPath(iSaveSlot, path, sizeof(path));
   fp = fopen(path, "wb");
   if (fp == NULL)
   {
      return FALSE;
   }

   fwrite(magic, 1, 8, fp);
   fwrite(&version, sizeof(WORD), 1, fp);
   fwrite(&roles, sizeof(WORD), 1, fp);
   fwrite(&magicCount, sizeof(WORD), 1, fp);
   fwrite(&artifactCount, sizeof(WORD), 1, fp);
   fwrite(prof, sizeof(WORD), MAX_PLAYER_ROLES * MAGICPROF_MAGIC_COUNT, fp);

   for (i = 0; i < MAX_ARTIFACTS; i++)
   {
      BYTE used = s_bag[i].fUsed ? 1 : 0;

      fwrite(&used, 1, 1, fp);
      fwrite(&s_bag[i].wTemplate, sizeof(WORD), 1, fp);
      fwrite(&s_bag[i].bQuality, 1, 1, fp);
      fwrite(&s_bag[i].bAffixCount, 1, 1, fp);
      for (j = 0; j < ARTIFACT_MAX_AFFIXES; j++)
      {
         fwrite(&s_bag[i].affixes[j].wAffix, sizeof(WORD), 1, fp);
         fwrite(&s_bag[i].affixes[j].wValue, sizeof(WORD), 1, fp);
         fwrite(&s_bag[i].affixes[j].bTier, 1, 1, fp);
      }
   }

   for (i = 0; i < MAX_PLAYER_ROLES; i++)
   {
      for (j = 0; j < ARTIFACT_SLOTS; j++)
      {
         fwrite(&s_equipped[i][j], sizeof(SHORT), 1, fp);
      }
   }
   fwrite(&s_dwLingChen, sizeof(DWORD), 1, fp);

   fclose(fp);
   return TRUE;
}

/* ---------------------------------------------------------------- */
/* Combat helpers                                                    */
/* ---------------------------------------------------------------- */

static BOOL
ART_HasFlag(
   WORD wRole,
   WORD wAffix
)
{
   int slot, i;

   for (slot = 0; slot < ARTIFACT_SLOTS; slot++)
   {
      int index = ART_GetEquipped(wRole, slot);
      ARTIFACT_INSTANCE *lpInstance = ART_GetInstance(index);
      if (lpInstance == NULL) continue;

      for (i = 0; i < lpInstance->bAffixCount; i++)
      {
         if (lpInstance->affixes[i].wAffix == wAffix)
         {
            return TRUE;
         }
      }
   }

   return FALSE;
}

static WORD
ART_GetMaxAffixValue(
   WORD wRole,
   WORD wAffix
)
{
   int slot, i;
   WORD value = 0;

   for (slot = 0; slot < ARTIFACT_SLOTS; slot++)
   {
      int index = ART_GetEquipped(wRole, slot);
      ARTIFACT_INSTANCE *lpInstance = ART_GetInstance(index);
      if (lpInstance == NULL) continue;

      for (i = 0; i < lpInstance->bAffixCount; i++)
      {
         if (lpInstance->affixes[i].wAffix == wAffix &&
            lpInstance->affixes[i].wValue > value)
         {
            value = lpInstance->affixes[i].wValue;
         }
      }
   }

   return value;
}

static WORD
ART_GetSumAffixValue(
   WORD wRole,
   WORD wAffix
)
{
   int slot, i;
   WORD value = 0;

   for (slot = 0; slot < ARTIFACT_SLOTS; slot++)
   {
      int index = ART_GetEquipped(wRole, slot);
      ARTIFACT_INSTANCE *lpInstance = ART_GetInstance(index);
      if (lpInstance == NULL) continue;

      for (i = 0; i < lpInstance->bAffixCount; i++)
      {
         if (lpInstance->affixes[i].wAffix == wAffix)
         {
            value += lpInstance->affixes[i].wValue;
         }
      }
   }

   return value;
}

VOID
ART_NotifyEffect(
   LPCWSTR lpszText
)
{
   DWORD now;

   if (lpszText == NULL || lpszText[0] == 0)
   {
      return;
   }

   now = SDL_GetTicks();
   if (s_szNoticeLast[0] != 0 && wcscmp(s_szNoticeLast, lpszText) == 0 &&
      now - s_dwNoticeLastTick < 900)
   {
      return;
   }

   if (s_iNoticeCount >= ART_NOTICE_MAX)
   {
      return;
   }

   wcsncpy(s_rgszNotice[s_iNoticeTail], lpszText, ART_NOTICE_CHARS - 1);
   s_rgszNotice[s_iNoticeTail][ART_NOTICE_CHARS - 1] = 0;
   s_iNoticeTail = (s_iNoticeTail + 1) % ART_NOTICE_MAX;
   s_iNoticeCount++;

   wcsncpy(s_szNoticeLast, lpszText, ART_NOTICE_CHARS - 1);
   s_szNoticeLast[ART_NOTICE_CHARS - 1] = 0;
   s_dwNoticeLastTick = now;
}

BOOL
ART_GetBattleNotice(
   LPWSTR lpszBuffer,
   size_t iBufferChars
)
{
   DWORD now;

   if (lpszBuffer == NULL || iBufferChars == 0)
   {
      return FALSE;
   }

   now = SDL_GetTicks();
   if (s_fNoticeActive && now - s_dwNoticeStart >= ART_NOTICE_MS)
   {
      s_fNoticeActive = FALSE;
   }

   if (!s_fNoticeActive && s_iNoticeCount > 0)
   {
      wcsncpy(s_szNoticeCurrent, s_rgszNotice[s_iNoticeHead], ART_NOTICE_CHARS - 1);
      s_szNoticeCurrent[ART_NOTICE_CHARS - 1] = 0;
      s_iNoticeHead = (s_iNoticeHead + 1) % ART_NOTICE_MAX;
      s_iNoticeCount--;
      s_dwNoticeStart = now;
      s_fNoticeActive = TRUE;
   }

   if (!s_fNoticeActive)
   {
      return FALSE;
   }

   wcsncpy(lpszBuffer, s_szNoticeCurrent, iBufferChars - 1);
   lpszBuffer[iBufferChars - 1] = 0;
   return TRUE;
}

VOID
ART_ClearBattleNotices(
   VOID
)
{
   s_iNoticeHead = 0;
   s_iNoticeTail = 0;
   s_iNoticeCount = 0;
   s_fNoticeActive = FALSE;
   s_szNoticeCurrent[0] = 0;
   s_szNoticeLast[0] = 0;
   s_dwNoticeLastTick = 0;
}

VOID
ART_OnBattleStart(
   VOID
)
{
   int i;
   int split = AB_GetActionSplit();

   ART_ClearBattleNotices();
   s_iEnemySlowStacks = 0;

   for (i = 0; i < MAX_PLAYER_ROLES; i++)
   {
      s_rgfMaxHPPenalty[i] = FALSE;
      s_rgfHPMPSwap[i] = FALSE;
   }

   for (i = 0; i <= gpGlobals->wMaxPartyMemberIndex; i++)
   {
      WORD role = gpGlobals->rgParty[i].wPlayerRole;
      WORD bonus = ART_GetStartMeterBonus(role);

      s_rgwOrigMaxHP[role] = gpGlobals->g.PlayerRoles.rgwMaxHP[role];
      s_rgwOrigHP[role] = gpGlobals->g.PlayerRoles.rgwHP[role];
      s_rgwOrigMP[role] = gpGlobals->g.PlayerRoles.rgwMP[role];

      if (ART_GetSumAffixValue(role, ART_AFFIX_SPEED_MAXHP) > 0)
      {
         gpGlobals->g.PlayerRoles.rgwMaxHP[role] =
            (WORD)((DWORD)gpGlobals->g.PlayerRoles.rgwMaxHP[role] * 70 / 100);
         if (gpGlobals->g.PlayerRoles.rgwHP[role] > gpGlobals->g.PlayerRoles.rgwMaxHP[role])
         {
            gpGlobals->g.PlayerRoles.rgwHP[role] = gpGlobals->g.PlayerRoles.rgwMaxHP[role];
         }
         s_rgfMaxHPPenalty[role] = TRUE;
         ART_NotifyEffect(L"[法寶] 速度換取生命");
      }

      if (ART_HasFlag(role, ART_AFFIX_HP_MP_SWAP))
      {
         WORD hpPct, mpPct;
         WORD maxHP = gpGlobals->g.PlayerRoles.rgwMaxHP[role];
         WORD maxMP = gpGlobals->g.PlayerRoles.rgwMaxMP[role];

         if (maxHP > 0 && maxMP > 0)
         {
            hpPct = (WORD)((DWORD)gpGlobals->g.PlayerRoles.rgwHP[role] * 100 / maxHP);
            mpPct = (WORD)((DWORD)gpGlobals->g.PlayerRoles.rgwMP[role] * 100 / maxMP);
            gpGlobals->g.PlayerRoles.rgwHP[role] = (WORD)((DWORD)maxHP * mpPct / 100);
            gpGlobals->g.PlayerRoles.rgwMP[role] = (WORD)((DWORD)maxMP * hpPct / 100);
            s_rgfHPMPSwap[role] = TRUE;
            ART_NotifyEffect(L"[法寶] HP/MP互換");
            UTIL_LogOutput(LOGLEVEL_DEBUG, "[BATTLE] hpmp-swap role=%d\n", (int)role);
         }
      }

      if (ART_HasFlag(role, ART_AFFIX_RANDOM_BUFF))
      {
         static const WORD rgszBuffStatus[] = { kStatusHaste, kStatusBravery, kStatusProtect, kStatusDualAttack };
         static const LPCWSTR rgszBuffName[] = { L"加速", L"勇氣", L"護體", L"雙攻" };
         int n = RandomLong(0, 3);
         gpGlobals->rgPlayerStatus[role][rgszBuffStatus[n]] += (WORD)RandomLong(3, 5);
         {
            WCHAR szNotice[96];
            PAL_swprintf(szNotice, sizeof(szNotice) / sizeof(WCHAR), L"[法寶] 吉星：%ls", rgszBuffName[n]);
            ART_NotifyEffect(szNotice);
            UTIL_LogOutput(LOGLEVEL_DEBUG, "[BATTLE] random-buff role=%d status=%d\n",
               (int)role, (int)rgszBuffStatus[n]);
         }
      }

      if (bonus != 0)
      {
         FLOAT flBefore = g_Battle.rgPlayer[i].flTimeMeter;
         g_Battle.rgPlayer[i].flTimeMeter += (FLOAT)split * (FLOAT)bonus / 100.0f;
         if (g_Battle.rgPlayer[i].flTimeMeter > (FLOAT)split)
         {
            g_Battle.rgPlayer[i].flTimeMeter = (FLOAT)split;
         }
         UTIL_LogOutput(LOGLEVEL_DEBUG,
            "[BATTLE] start-meter role=%d bonus=%u before=%.1f after=%.1f split=%d\n",
            (int)role, (unsigned)bonus, (double)flBefore,
            (double)g_Battle.rgPlayer[i].flTimeMeter, split);
         ART_NotifyEffect(L"[法寶] 開場先手");
      }
      if (ART_GetSumAffixValue(role, ART_AFFIX_SPEED_MAXHP) > 0)
      {
         ART_NotifyEffect(L"[法寶] 速度提升");
      }
      if (ART_HasFlag(role, ART_AFFIX_ABNORMAL_SPEED))
      {
         ART_NotifyEffect(L"[法寶] 受咒加速");
      }
   }
}

VOID
ART_OnBattleEnd(
   VOID
)
{
   int role;

   for (role = 0; role < MAX_PLAYER_ROLES; role++)
   {
      if (s_rgfMaxHPPenalty[role])
      {
         gpGlobals->g.PlayerRoles.rgwMaxHP[role] = s_rgwOrigMaxHP[role];
         if (gpGlobals->g.PlayerRoles.rgwHP[role] > s_rgwOrigMaxHP[role])
         {
            gpGlobals->g.PlayerRoles.rgwHP[role] = s_rgwOrigMaxHP[role];
         }
         s_rgfMaxHPPenalty[role] = FALSE;
      }
      if (s_rgfHPMPSwap[role])
      {
         gpGlobals->g.PlayerRoles.rgwHP[role] = s_rgwOrigHP[role];
         gpGlobals->g.PlayerRoles.rgwMP[role] = s_rgwOrigMP[role];
         s_rgfHPMPSwap[role] = FALSE;
      }
   }
}


static BOOL
ART_AnyPartyHasAffix(
   WORD wAffix
)
{
   int i;

   for (i = 0; i <= gpGlobals->wMaxPartyMemberIndex; i++)
   {
      if (ART_HasFlag(gpGlobals->rgParty[i].wPlayerRole, wAffix))
      {
         return TRUE;
      }
   }
   return FALSE;
}

VOID
ART_OnPlayerAction(
   VOID
)
{
   if (!ART_AnyPartyHasAffix(ART_AFFIX_ENEMY_SLOW))
   {
      return;
   }

   if (s_iEnemySlowStacks < 10)
   {
      s_iEnemySlowStacks++;
      ART_NotifyEffect(L"[法寶] 敵方遲緩");
   }
}

FLOAT
ART_GetEnemySlowMultiplier(
   VOID
)
{
   return 1.0f - 0.03f * (FLOAT)s_iEnemySlowStacks;
}

BOOL
ART_IsChantUninterruptible(
   WORD wRole
)
{
   return ART_HasFlag(wRole, ART_AFFIX_CHANT_UNBREAK);
}

WORD
ART_GetStartMeterBonus(
   WORD wRole
)
{
   return ART_GetMaxAffixValue(wRole, ART_AFFIX_START_METER);
}

FLOAT
ART_GetSpeedMultiplier(
   WORD wRole
)
{
   WORD value = ART_GetSumAffixValue(wRole, ART_AFFIX_SPEED_MAXHP);
   FLOAT f = 1.0f + (FLOAT)value / 100.0f;

   if (ART_HasFlag(wRole, ART_AFFIX_ABNORMAL_SPEED) &&
      (gpGlobals->rgPlayerStatus[wRole][kStatusConfused] > 0 ||
       gpGlobals->rgPlayerStatus[wRole][kStatusSlow] > 0 ||
       gpGlobals->rgPlayerStatus[wRole][kStatusSleep] > 0 ||
       gpGlobals->rgPlayerStatus[wRole][kStatusSilence] > 0))
   {
      f += 0.20f;
   }

   return f;
}

BYTE
ART_GetComboChance(
   WORD wRole
)
{
   return (BYTE)ART_GetMaxAffixValue(wRole, ART_AFFIX_COMBO);
}

BOOL
ART_ShouldFailSpell(
   WORD wRole
)
{
   return ART_HasFlag(wRole, ART_AFFIX_FAIL_ATTACK) ? (RandomLong(0, 99) < 20) : FALSE;
}

BOOL
ART_HasPoisonHit(
   WORD wRole
)
{
   return ART_HasFlag(wRole, ART_AFFIX_POISON_HIT);
}

BOOL
ART_HasDamageMP(
   WORD wRole
)
{
   return ART_HasFlag(wRole, ART_AFFIX_DAMAGE_MP);
}

BOOL
ART_HasElementAttack(
   WORD wRole
)
{
   return ART_HasFlag(wRole, ART_AFFIX_ELEMENT_ATTACK);
}

VOID
ART_ApplyPoisonHit(
   WORD wEnemyIndex
)
{
   int i, j;
   int best = -1;

   if (wEnemyIndex > g_Battle.wMaxEnemyIndex || g_Battle.rgEnemy[wEnemyIndex].wObjectID == 0)
   {
      return;
   }
   for (i = 1; i < MAX_OBJECTS; i++)
   {
      if (gpGlobals->g.rgObject[i].poison.wPoisonLevel > 0 &&
         gpGlobals->g.rgObject[i].poison.wEnemyScript != 0)
      {
         if (best < 0 ||
            gpGlobals->g.rgObject[i].poison.wPoisonLevel >
            gpGlobals->g.rgObject[best].poison.wPoisonLevel)
         {
            best = i;
         }
      }
   }
   if (best < 0) return;

   for (j = 0; j < MAX_POISONS; j++)
   {
      if (g_Battle.rgEnemy[wEnemyIndex].rgPoisons[j].wPoisonID == 0)
      {
         g_Battle.rgEnemy[wEnemyIndex].rgPoisons[j].wPoisonID = (WORD)best;
         g_Battle.rgEnemy[wEnemyIndex].rgPoisons[j].wPoisonScript =
            PAL_RunTriggerScript(gpGlobals->g.rgObject[best].poison.wEnemyScript, wEnemyIndex);
         ART_NotifyEffect(L"[法寶] 淬毒");
         break;
      }
   }
}

FLOAT
ART_GetPhysicalMultiplier(
   WORD wRole
)
{
   WORD value = ART_GetSumAffixValue(wRole, ART_AFFIX_ELEMENT_ATTACK);
   return 1.0f + (FLOAT)value / 100.0f;
}

WORD
ART_GetMultiHitCount(
   WORD wRole
)
{
   WORD value = ART_GetMaxAffixValue(wRole, ART_AFFIX_MULTI_HIT);
   if (value < 1)
   {
      return 1;
   }
   return value;
}

BOOL
ART_InList(
   WORD wValue,
   const WORD *lpList,
   int iCount
)
{
   int i;
   for (i = 0; i < iCount; i++)
   {
      if (lpList[i] == wValue) return TRUE;
   }
   return FALSE;
}

FLOAT
ART_GetMagicMultiplier(
   WORD wRole,
   WORD wMagicObject
)
{
   WORD value = ART_GetSumAffixValue(wRole, ART_AFFIX_MAGIC_ALL);
   WORD magicNum;
   WORD prof;
   static const WORD dummy[] = { 0 };
   (void)dummy;

   if (ART_HasProficiencyPower(wRole))
   {
      prof = MAGICPROF_Get(wRole, wMagicObject);
      value += (WORD)(prof * 3 / 10);
   }

   if (wMagicObject != 0 && wMagicObject < MAX_OBJECTS)
   {
      magicNum = gpGlobals->g.rgObject[wMagicObject].magic.wMagicNumber;
      if (magicNum < gpGlobals->g.nMagic && gpGlobals->g.lprgMagic != NULL)
      {
         WORD type = gpGlobals->g.lprgMagic[magicNum].wType;
         if (type == kMagicTypeApplyToPlayer || type == kMagicTypeApplyToParty ||
            type == kMagicTypeTrance)
         {
            value += ART_GetSumAffixValue(wRole, ART_AFFIX_MAGIC_SUPPORT);
         }
      }

      if (ART_InList(wMagicObject, s_rgwFiveMagic,
         sizeof(s_rgwFiveMagic) / sizeof(s_rgwFiveMagic[0])))
      {
         value += ART_GetSumAffixValue(wRole, ART_AFFIX_MAGIC_FIVE);
      }
      if (ART_InList(wMagicObject, s_rgwPoisonMagic,
         sizeof(s_rgwPoisonMagic) / sizeof(s_rgwPoisonMagic[0])))
      {
         value += ART_GetSumAffixValue(wRole, ART_AFFIX_MAGIC_POISON);
      }
   }

   return 1.0f + (FLOAT)value / 100.0f;
}

BOOL
ART_HasProficiencyPower(
   WORD wRole
)
{
   return ART_HasFlag(wRole, ART_AFFIX_PROF_POWER);
}

BOOL
ART_ShouldDisableInstant(
   WORD wRole
)
{
   return ART_HasProficiencyPower(wRole);
}

BOOL
ART_ShouldDisableChantSpeed(
   WORD wRole
)
{
   return ART_HasProficiencyPower(wRole);
}

BYTE
ART_GetMagicDamageType(
   WORD wMagicObject
)
{
   WORD magicNum;
   WORD elem;

   if (wMagicObject == 0 || wMagicObject >= MAX_OBJECTS)
   {
      return ART_DMG_OTHER;
   }

   magicNum = gpGlobals->g.rgObject[wMagicObject].magic.wMagicNumber;
   if (magicNum >= gpGlobals->g.nMagic || gpGlobals->g.lprgMagic == NULL)
   {
      return ART_DMG_OTHER;
   }

   elem = gpGlobals->g.lprgMagic[magicNum].wElemental;
   switch (elem)
   {
   case 0: return ART_DMG_OTHER;
   case 1: return ART_DMG_WIND;
   case 2: return ART_DMG_LIGHTNING;
   case 3: return ART_DMG_WATER;
   case 4: return ART_DMG_FIRE;
   case 5: return ART_DMG_EARTH;
   default: return ART_DMG_POISON;
   }
}

BYTE
ART_GetItemSaveChance(
   WORD wRole
)
{
   return (BYTE)ART_GetMaxAffixValue(wRole, ART_AFFIX_ITEM_SAVE);
}

BYTE
ART_GetMagicCritChance(
   WORD wRole,
   WORD wMagicObject
)
{
   (void)wMagicObject;
   return (BYTE)ART_GetSumAffixValue(wRole, ART_AFFIX_MAGIC_CRIT);
}

VOID
ART_OnSuccessfulSpell(
   WORD wRole,
   WORD wMagicObject
)
{
   MAGICPROF_OnSuccessfulCast(wRole, wMagicObject);
   if (ART_HasFlag(wRole, ART_AFFIX_EXTRA_PROF))
   {
      MAGICPROF_OnSuccessfulCast(wRole, wMagicObject);
      ART_NotifyEffect(L"[法寶] 額外熟練");
   }
   if (ART_HasFlag(wRole, ART_AFFIX_PROF_POWER) ||
      ART_GetSumAffixValue(wRole, ART_AFFIX_MAGIC_ALL) > 0 ||
      ART_GetSumAffixValue(wRole, ART_AFFIX_MAGIC_SUPPORT) > 0 ||
      ART_GetSumAffixValue(wRole, ART_AFFIX_MAGIC_FIVE) > 0 ||
      ART_GetSumAffixValue(wRole, ART_AFFIX_MAGIC_POISON) > 0)
   {
      ART_NotifyEffect(L"[法寶] 仙術強化");
   }
}

VOID
ART_OnPlayerDamaged(
   WORD wRole
)
{
   int i;
   WORD value = ART_GetMaxAffixValue(wRole, ART_AFFIX_HIT_METER);
   int split = AB_GetActionSplit();

   if (value == 0) return;

   ART_NotifyEffect(L"[法寶] 受擊回氣");

   for (i = 0; i <= gpGlobals->wMaxPartyMemberIndex; i++)
   {
      if (gpGlobals->rgParty[i].wPlayerRole == wRole)
      {
         FLOAT flBefore = g_Battle.rgPlayer[i].flTimeMeter;
         g_Battle.rgPlayer[i].flTimeMeter += (FLOAT)split * (FLOAT)value / 100.0f;
         UTIL_LogOutput(LOGLEVEL_DEBUG,
            "[BATTLE] hit-meter role=%d value=%u before=%.1f after=%.1f split=%d\n",
            (int)wRole, (unsigned)value, (double)flBefore,
            (double)g_Battle.rgPlayer[i].flTimeMeter, split);
         if (g_Battle.rgPlayer[i].flTimeMeter > (FLOAT)split)
         {
            g_Battle.rgPlayer[i].flTimeMeter = (FLOAT)split;
         }
         break;
      }
   }
}

BOOL ART_IsAffixActive(int iRole, int iSlot, int iAffixIndex);

static BOOL
ART_HasActiveReduction(
   WORD wRole
)
{
   int slot, i;

   for (slot = 0; slot < ARTIFACT_SLOTS; slot++)
   {
      int index = ART_GetEquipped(wRole, slot);
      ARTIFACT_INSTANCE *lpInstance = ART_GetInstance(index);
      if (lpInstance == NULL) continue;
      for (i = 0; i < lpInstance->bAffixCount; i++)
      {
         if (ART_IsReductionAffix(lpInstance->affixes[i].wAffix) &&
            ART_IsAffixActive(wRole, slot, i))
         {
            return TRUE;
         }
      }
   }
   return FALSE;
}

WORD
ART_GetBuffMask(
   WORD wRole
)
{
   WORD mask = 0;

   if (ART_GetSumAffixValue(wRole, ART_AFFIX_SPEED_MAXHP) > 0) mask |= (1u << 0);
   if (ART_HasActiveReduction(wRole)) mask |= (1u << 1);
   if (ART_GetMaxAffixValue(wRole, ART_AFFIX_HIT_METER) > 0) mask |= (1u << 2);
   if (ART_GetMaxAffixValue(wRole, ART_AFFIX_MP_ABSORB) > 0) mask |= (1u << 3);
   if (ART_GetMaxAffixValue(wRole, ART_AFFIX_REFLECT) > 0) mask |= (1u << 4);
   if (ART_HasFlag(wRole, ART_AFFIX_DAMAGE_CAP)) mask |= (1u << 5);
   if (ART_HasFlag(wRole, ART_AFFIX_MP_FIRST)) mask |= (1u << 6);
   if (ART_GetMultiHitCount(wRole) > 1) mask |= (1u << 7);
   if (ART_GetSumAffixValue(wRole, ART_AFFIX_MAGIC_CRIT) > 0) mask |= (1u << 8);
   if (ART_HasFlag(wRole, ART_AFFIX_PROF_POWER) ||
      ART_GetSumAffixValue(wRole, ART_AFFIX_MAGIC_ALL) > 0 ||
      ART_GetSumAffixValue(wRole, ART_AFFIX_MAGIC_SUPPORT) > 0 ||
      ART_GetSumAffixValue(wRole, ART_AFFIX_MAGIC_FIVE) > 0 ||
      ART_GetSumAffixValue(wRole, ART_AFFIX_MAGIC_POISON) > 0) mask |= (1u << 9);
   if (ART_HasFlag(wRole, ART_AFFIX_CHANT_UNBREAK)) mask |= (1u << 10);
   if (ART_GetMaxAffixValue(wRole, ART_AFFIX_START_METER) > 0) mask |= (1u << 11);
   if (ART_HasFlag(wRole, ART_AFFIX_ENEMY_SLOW)) mask |= (1u << 12);
   if (ART_HasFlag(wRole, ART_AFFIX_EXTRA_PROF)) mask |= (1u << 13);
   if (ART_GetMaxAffixValue(wRole, ART_AFFIX_ITEM_SAVE) > 0) mask |= (1u << 14);
   if (ART_GetSumAffixValue(wRole, ART_AFFIX_ELEMENT_ATTACK) > 0) mask |= (1u << 15);

   return mask;
}

LPCWSTR
ART_GetBuffAbbrev(
   int iIndex
)
{
   static LPCWSTR rgsz[] = { L"速", L"減", L"氣", L"吸", L"反", L"限", L"護", L"多",
                             L"暴", L"法", L"吟", L"先", L"緩", L"熟", L"省", L"攻" };
   if (iIndex < 0 || iIndex >= ART_BUFF_COUNT) return L"";
   return rgsz[iIndex];
}

static LPCWSTR
ART_GetReductionTypeName(
   BYTE bType
)
{
   static LPCWSTR rgsz[] = { L"物理", L"火系", L"風系", L"雷系", L"水系", L"土系", L"毒蠱", L"其他" };
   if (bType > ART_DMG_OTHER) return L"傷害";
   return rgsz[bType];
}

BOOL
ART_GetBuffDetail(
   WORD wRole,
   int iIndex,
   LPWSTR lpszBuffer,
   size_t iBufferChars
)
{
   int value;

   if (lpszBuffer == NULL || iBufferChars == 0)
   {
      return FALSE;
   }
   lpszBuffer[0] = 0;

   switch (iIndex)
   {
   case 0:
      value = ART_GetSumAffixValue(wRole, ART_AFFIX_SPEED_MAXHP);
      PAL_swprintf(lpszBuffer, iBufferChars, L"速度 +%d%%", value); break;
   case 1:
      {
         int slot, i;
         lpszBuffer[0] = 0;
         for (slot = 0; slot < ARTIFACT_SLOTS; slot++)
         {
            int index = ART_GetEquipped(wRole, slot);
            ARTIFACT_INSTANCE *lpInstance = ART_GetInstance(index);
            if (lpInstance == NULL) continue;
            for (i = 0; i < lpInstance->bAffixCount; i++)
            {
               WORD a = lpInstance->affixes[i].wAffix;
               if (ART_IsReductionAffix(a) && ART_IsAffixActive(wRole, slot, i))
               {
                  WCHAR szPart[96];
                  PAL_swprintf(szPart, sizeof(szPart) / sizeof(WCHAR), L"%ls·%ls%u%% ",
                     ART_GetAffixName(a), ART_GetReductionTypeName(ART_ReductionType(a)),
                     (unsigned)lpInstance->affixes[i].wValue);
                  wcsncat(lpszBuffer, szPart, iBufferChars - wcslen(lpszBuffer) - 1);
               }
            }
         }
         if (lpszBuffer[0] == 0) PAL_swprintf(lpszBuffer, iBufferChars, L"無");
      }
      break;
   case 2:
      value = ART_GetMaxAffixValue(wRole, ART_AFFIX_HIT_METER);
      PAL_swprintf(lpszBuffer, iBufferChars, L"受擊回氣 +%d%%", value); break;
   case 3:
      value = ART_GetMaxAffixValue(wRole, ART_AFFIX_MP_ABSORB);
      PAL_swprintf(lpszBuffer, iBufferChars, L"真氣吸收 %d%%", value); break;
   case 4:
      PAL_swprintf(lpszBuffer, iBufferChars, L"反彈傷害 30%%"); break;
   case 5:
      PAL_swprintf(lpszBuffer, iBufferChars, L"單次傷害上限 40%%"); break;
   case 6:
      PAL_swprintf(lpszBuffer, iBufferChars, L"真氣護體：先扣 MP"); break;
   case 7:
      value = ART_GetMultiHitCount(wRole);
      PAL_swprintf(lpszBuffer, iBufferChars, L"%d 段普攻", value); break;
   case 8:
      value = ART_GetSumAffixValue(wRole, ART_AFFIX_MAGIC_CRIT);
      PAL_swprintf(lpszBuffer, iBufferChars, L"仙術暴擊 +%d%%", value); break;
   case 9:
      PAL_swprintf(lpszBuffer, iBufferChars, L"仙術威力提升"); break;
   case 10:
      PAL_swprintf(lpszBuffer, iBufferChars, L"吟唱不被傷害打斷"); break;
   case 11:
      value = ART_GetMaxAffixValue(wRole, ART_AFFIX_START_METER);
      PAL_swprintf(lpszBuffer, iBufferChars, L"開場行動 +%d%%", value); break;
   case 12:
      PAL_swprintf(lpszBuffer, iBufferChars, L"每回合敵方遲緩"); break;
   case 13:
      PAL_swprintf(lpszBuffer, iBufferChars, L"施法額外 +1 熟練"); break;
   case 14:
      value = ART_GetMaxAffixValue(wRole, ART_AFFIX_ITEM_SAVE);
      PAL_swprintf(lpszBuffer, iBufferChars, L"物品節省 %d%%", value); break;
   case 15:
      PAL_swprintf(lpszBuffer, iBufferChars, L"物理攻擊 +20%%"); break;
   default:
      return FALSE;
   }
   return TRUE;
}

BOOL
ART_GetMagicBonusText(
   WORD wRole,
   WORD wMagicObject,
   LPWSTR lpszBuffer,
   size_t iBufferChars
)
{
   WCHAR szPart[64];
   WORD magicNum;
   WORD type = 0;
   WORD value;

   if (lpszBuffer == NULL || iBufferChars == 0)
   {
      return FALSE;
   }
   lpszBuffer[0] = 0;

   if (wMagicObject != 0 && wMagicObject < MAX_OBJECTS)
   {
      magicNum = gpGlobals->g.rgObject[wMagicObject].magic.wMagicNumber;
      if (magicNum < gpGlobals->g.nMagic && gpGlobals->g.lprgMagic != NULL)
      {
         type = gpGlobals->g.lprgMagic[magicNum].wType;
      }
   }

   value = ART_GetSumAffixValue(wRole, ART_AFFIX_MAGIC_ALL);
   if (value > 0)
   {
      PAL_swprintf(szPart, sizeof(szPart) / sizeof(WCHAR), L"全系+%u%%", value);
      wcsncat(lpszBuffer, szPart, iBufferChars - wcslen(lpszBuffer) - 1);
   }
   if ((type == kMagicTypeApplyToPlayer || type == kMagicTypeApplyToParty ||
        type == kMagicTypeTrance) &&
       (value = ART_GetSumAffixValue(wRole, ART_AFFIX_MAGIC_SUPPORT)) > 0)
   {
      PAL_swprintf(szPart, sizeof(szPart) / sizeof(WCHAR), L" 輔助+%u%%", value);
      wcsncat(lpszBuffer, szPart, iBufferChars - wcslen(lpszBuffer) - 1);
   }
   if (ART_InList(wMagicObject, s_rgwFiveMagic,
        sizeof(s_rgwFiveMagic) / sizeof(s_rgwFiveMagic[0])) &&
       (value = ART_GetSumAffixValue(wRole, ART_AFFIX_MAGIC_FIVE)) > 0)
   {
      PAL_swprintf(szPart, sizeof(szPart) / sizeof(WCHAR), L" 五行+%u%%", value);
      wcsncat(lpszBuffer, szPart, iBufferChars - wcslen(lpszBuffer) - 1);
   }
   if (ART_InList(wMagicObject, s_rgwPoisonMagic,
        sizeof(s_rgwPoisonMagic) / sizeof(s_rgwPoisonMagic[0])) &&
       (value = ART_GetSumAffixValue(wRole, ART_AFFIX_MAGIC_POISON)) > 0)
   {
      PAL_swprintf(szPart, sizeof(szPart) / sizeof(WCHAR), L" 毒蠱+%u%%", value);
      wcsncat(lpszBuffer, szPart, iBufferChars - wcslen(lpszBuffer) - 1);
   }
   if ((value = ART_GetSumAffixValue(wRole, ART_AFFIX_MAGIC_CRIT)) > 0)
   {
      PAL_swprintf(szPart, sizeof(szPart) / sizeof(WCHAR), L" 暴擊+%u%%", value);
      wcsncat(lpszBuffer, szPart, iBufferChars - wcslen(lpszBuffer) - 1);
   }
   if (ART_HasProficiencyPower(wRole))
   {
      value = (WORD)(MAGICPROF_Get(wRole, wMagicObject) * 3 / 10);
      PAL_swprintf(szPart, sizeof(szPart) / sizeof(WCHAR), L" 熟練+%u%%", value);
      wcsncat(lpszBuffer, szPart, iBufferChars - wcslen(lpszBuffer) - 1);
   }
   if (ART_HasFlag(wRole, ART_AFFIX_EXTRA_PROF))
   {
      PAL_swprintf(szPart, sizeof(szPart) / sizeof(WCHAR), L" 額外熟練+1");
      wcsncat(lpszBuffer, szPart, iBufferChars - wcslen(lpszBuffer) - 1);
   }

   while (lpszBuffer[0] == L' ')
   {
      memmove(lpszBuffer, lpszBuffer + 1, (wcslen(lpszBuffer)) * sizeof(WCHAR));
   }
   return lpszBuffer[0] != 0;
}

WORD
ART_GetIncomingDamage(
   WORD wRole,
   WORD wDamage,
   BYTE bType,
   WORD wAttackerEnemy
)
{
   FLOAT damage = (FLOAT)wDamage;
   FLOAT reduction = 0.0f;
   int slot, i;
   int otherReductions = 0;
   LPCWSTR lpszOtherReduction = NULL;
   WORD absorb;
   DWORD mpGain;
   WORD maxHP;
   WORD cap;

   /* reduce by active reduction of matching type */
   for (slot = 0; slot < ARTIFACT_SLOTS; slot++)
   {
      int index = ART_GetEquipped(wRole, slot);
      ARTIFACT_INSTANCE *lpInstance = ART_GetInstance(index);
      if (lpInstance == NULL) continue;

      for (i = 0; i < lpInstance->bAffixCount; i++)
      {
         WORD affix = lpInstance->affixes[i].wAffix;
         if (ART_IsReductionAffix(affix) && ART_IsAffixActive(wRole, slot, i))
         {
            if (ART_ReductionType(affix) == bType && reduction < 0.8f)
            {
               reduction = 0.8f;
            }
            else if (ART_ReductionType(affix) != bType)
            {
               otherReductions++;
               if (lpszOtherReduction == NULL)
               {
                  lpszOtherReduction = ART_GetAffixName(affix);
               }
            }
         }
      }
   }

   damage *= (1.0f - reduction);
   damage *= (1.0f + 0.2f * (FLOAT)otherReductions);

   if (reduction > 0.0f)
   {
      ART_NotifyEffect(L"[法寶] 傷害減免");
   }
   if (otherReductions > 0)
   {
      WCHAR szNotice[128];
      PAL_swprintf(szNotice, sizeof(szNotice) / sizeof(WCHAR), L"[法寶] %ls·異種增傷",
         (lpszOtherReduction != NULL) ? lpszOtherReduction : L"抗性");
      ART_NotifyEffect(szNotice);
   }

   /* absorb a portion into MP */
   absorb = ART_GetMaxAffixValue(wRole, ART_AFFIX_MP_ABSORB);
   if (absorb > 0 && damage > 0)
   {
      mpGain = (DWORD)(damage * (FLOAT)absorb / 100.0f);
      if (mpGain > 0)
      {
         gpGlobals->g.PlayerRoles.rgwMP[wRole] += (SHORT)mpGain;
         damage -= (FLOAT)mpGain;
         ART_NotifyEffect(L"[法寶] 真氣吸收");
      }
   }

   /* single-hit cap, poison excluded */
   if (bType != ART_DMG_POISON)
   {
      maxHP = gpGlobals->g.PlayerRoles.rgwMaxHP[wRole];
      cap = (WORD)((DWORD)maxHP * 40 / 100);
      if (ART_HasFlag(wRole, ART_AFFIX_DAMAGE_CAP) && damage > (FLOAT)cap)
      {
         damage = (FLOAT)cap;
         ART_NotifyEffect(L"[法寶] 單次傷害上限");
      }
   }

   /* MP first */
   if (ART_HasFlag(wRole, ART_AFFIX_MP_FIRST) && damage > 0)
   {
      WORD mp = gpGlobals->g.PlayerRoles.rgwMP[wRole];
      WORD use = (WORD)((damage < (FLOAT)mp) ? damage : (FLOAT)mp);

      gpGlobals->g.PlayerRoles.rgwMP[wRole] -= use;
      damage -= use;
      if (use > 0)
      {
         ART_NotifyEffect(L"[法寶] 真氣護體");
      }
   }

   if (damage < 0) damage = 0;

   /* reflect, no poison/environment and no chain */
   if (bType != ART_DMG_POISON && bType != ART_DMG_OTHER &&
      wAttackerEnemy <= g_Battle.wMaxEnemyIndex &&
      g_Battle.rgEnemy[wAttackerEnemy].wObjectID != 0)
   {
      WORD reflect = ART_GetMaxAffixValue(wRole, ART_AFFIX_REFLECT);
      if (reflect > 0 && damage > 0)
      {
         WORD reflected = (WORD)(damage * (FLOAT)reflect / 100.0f);
         if (reflected > 0)
         {
            g_Battle.rgEnemy[wAttackerEnemy].e.wHealth -= reflected;
            ART_NotifyEffect(L"[法寶] 反彈傷害");
         }
      }
   }

   UTIL_LogOutput(LOGLEVEL_DEBUG,
      "[BATTLE] art-in role=%d type=%d raw=%u reduction=%.0f other=%d final=%u\n",
      (int)wRole, (int)bType, (unsigned)wDamage,
      (double)(reduction * 100.0f), otherReductions, (unsigned)damage);

   return (WORD)damage;
}

BOOL
ART_IsAffixActive(
   int iRole,
   int iSlot,
   int iAffix
)
{
   int index = ART_GetEquipped(iRole, iSlot);
   ARTIFACT_INSTANCE *lpInstance = ART_GetInstance(index);
   WORD affix;
   BYTE type;
   int slot, i, bestSlot = ARTIFACT_SLOTS;
   WORD bestValue = 0;

   if (lpInstance == NULL || iAffix < 0 || iAffix >= lpInstance->bAffixCount)
   {
      return FALSE;
   }

   affix = lpInstance->affixes[iAffix].wAffix;
   if (!ART_IsReductionAffix(affix))
   {
      return TRUE;
   }

   type = ART_ReductionType(affix);
   for (slot = 0; slot < ARTIFACT_SLOTS; slot++)
   {
      int idx = ART_GetEquipped(iRole, slot);
      ARTIFACT_INSTANCE *lpInst = ART_GetInstance(idx);
      if (lpInst == NULL) continue;

      for (i = 0; i < lpInst->bAffixCount; i++)
      {
         WORD a = lpInst->affixes[i].wAffix;
         if (ART_IsReductionAffix(a) && ART_ReductionType(a) == type)
         {
            if (lpInst->affixes[i].wValue > bestValue ||
               (lpInst->affixes[i].wValue == bestValue && slot < bestSlot))
            {
               bestValue = lpInst->affixes[i].wValue;
               bestSlot = slot;
            }
         }
      }
   }

   return (bestSlot == iSlot) ? TRUE : FALSE;
}

/* Drop generation used by UI. */
VOID
ART_GenerateDrops(
   BOOL fBoss,
   ARTIFACT_DROP *pDrops,
   int *piCount
)
{
   int count, i;

   ART_InitState();
   if (pDrops == NULL || piCount == NULL) return;

   if (fBoss)
   {
      count = 1 + (int)RandomLong(2, 4);
      for (i = 0; i < count; i++)
      {
         BOOL autoDismantled = FALSE;
         ART_GenerateInstance(&pDrops[i].instance,
            (i == 0) ? ARTIFACT_QUALITY_GOLD : ARTIFACT_QUALITY_RED, TRUE);
         pDrops[i].fKept = (ART_AddInstance(&pDrops[i].instance, &autoDismantled) >= 0);
         pDrops[i].fAutoDismantled = autoDismantled;
         pDrops[i].dwLingChen = (i == 0) ? 10 : 4;
      }
   }
   else
   {
      /* Normal monsters: 1/3 chance to drop exactly one artifact. */
      if (RandomLong(1, 3) != 1)
      {
         *piCount = 0;
         return;
      }

      count = 1;
      for (i = 0; i < count; i++)
      {
         BOOL autoDismantled = FALSE;
         ART_GenerateInstance(&pDrops[i].instance, 0, FALSE);
         pDrops[i].fKept = (ART_AddInstance(&pDrops[i].instance, &autoDismantled) >= 0);
         pDrops[i].fAutoDismantled = autoDismantled;
         pDrops[i].dwLingChen = 0;
      }
   }

   *piCount = count;
}
