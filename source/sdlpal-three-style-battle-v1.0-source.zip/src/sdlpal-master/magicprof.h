#ifndef MAGICPROF_H
#define MAGICPROF_H

#include "common.h"

/*
 * Per-character, per-spell proficiency.
 *
 * Stored in an independent sidecar file (magicprof.dat), never inside the
 * original .rpg, so old DOS saves stay byte-compatible.
 */

#define MAGICPROF_MAX                 999
#define MAGICPROF_DEFAULT_THRESHOLD   45
#define MAGICPROF_MAGIC_COUNT         56

PAL_C_LINKAGE_BEGIN

VOID
MAGICPROF_Init(
   VOID
);

VOID
MAGICPROF_Reset(
   VOID
);

VOID
MAGICPROF_Export(
   WORD *pBuffer
);

VOID
MAGICPROF_Import(
   const WORD *pBuffer
);

WORD
MAGICPROF_Get(
   WORD wPlayerRole,
   WORD wMagicObject
);

WORD
MAGICPROF_GetThreshold(
   WORD wMagicObject
);

BOOL
MAGICPROF_IsInstant(
   WORD wPlayerRole,
   WORD wMagicObject
);

FLOAT
MAGICPROF_GetSpeedFactor(
   WORD wPlayerRole,
   WORD wMagicObject
);

WORD
MAGICPROF_GetEnemyProficiency(
   BOOL fBoss
);

VOID
MAGICPROF_OnSuccessfulCast(
   WORD wPlayerRole,
   WORD wMagicObject
);

PAL_C_LINKAGE_END

#endif
