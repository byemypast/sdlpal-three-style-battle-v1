/*
 * Artifact UI: character pages, three slots, bag and battle drop display.
 * All visuals reuse existing FBP/RGM/BALL resources and UI boxes.
 */

#include "main.h"
#include "palcfg.h"
#include "ui.h"
#include "artifacts.h"
#include "battle.h"
#include "fight.h"
#include "battlestatus.h"

#define ART_BAG_PAGE_SIZE 6
#define ART_BACKGROUND_FBPNUM 3   /* FBP 3: in-game forest scene, no empty status frames */
#define ART_DETAIL_COLOR  0x3F

typedef struct tagART_UI_STATE
{
   int  iRoleIndex;
   int  iSlot;
   int  iDetailPage;
   BOOL fBagMode;
   int  iBagCursor;
   int  iBagPage;
} ART_UI_STATE;

static PAL_LARGE BYTE s_bufBackground[320 * 200];
static PAL_LARGE BYTE s_bufImage[PAL_RLEBUFSIZE];
static BOOL s_fBackgroundLoaded = FALSE;

static LPBOX s_uiBoxes[8];
static int   s_iUiBoxCount = 0;

static VOID
ART_ResetUiBoxes(
   VOID
)
{
   int i;

   for (i = 0; i < s_iUiBoxCount; i++)
   {
      PAL_DeleteBox(s_uiBoxes[i]);
      s_uiBoxes[i] = NULL;
   }
   s_iUiBoxCount = 0;
}

static VOID
ART_AddUiBox(
   LPBOX lpBox
)
{
   if (lpBox != NULL && s_iUiBoxCount < 8)
   {
      s_uiBoxes[s_iUiBoxCount++] = lpBox;
   }
}



static VOID
ART_LoadBackground(
   VOID
)
{
   if (s_fBackgroundLoaded)
   {
      return;
   }

   PAL_MKFDecompressChunk(s_bufBackground, sizeof(s_bufBackground),
      3, gpGlobals->f.fpFBP);
   s_fBackgroundLoaded = TRUE;
}

static VOID
ART_DrawAvatar(
   int iRole
)
{
   if (PAL_MKFReadChunk(s_bufImage, sizeof(s_bufImage),
      gpGlobals->g.PlayerRoles.rgwAvatar[iRole], gpGlobals->f.fpRGM) > 0)
   {
      PAL_RLEBlitToSurface(s_bufImage, gpScreen, PAL_XY(18, 40));
   }

   PAL_DrawText(PAL_GetWord(gpGlobals->g.PlayerRoles.rgwName[iRole]),
      PAL_XY(18, 102), MENUITEM_COLOR_CONFIRMED, TRUE, FALSE, FALSE);

}

static VOID
ART_DrawSlot(
   int iRole,
   int iSlot,
   int iY,
   BOOL fSelected
)
{
   int iIndex = ART_GetEquipped(iRole, iSlot);
   ARTIFACT_INSTANCE *lpInstance = ART_GetInstance(iIndex);
   WCHAR szText[64];
   BYTE bColor = fSelected ? MENUITEM_COLOR_SELECTED : MENUITEM_COLOR;

   ART_AddUiBox(PAL_CreateSingleLineBoxWithShadow(PAL_XY(104, iY), 25, FALSE, 0));

   if (lpInstance == NULL)
   {
      BYTE bEmptyColor = MENUITEM_COLOR_INACTIVE;

      if (fSelected && ((SDL_GetTicks() / 300) & 1))
      {
         bEmptyColor = MENUITEM_COLOR_SELECTED;
      }

      PAL_DrawText(L"空", PAL_XY(114, iY + 8), bEmptyColor, TRUE, FALSE, FALSE);
      PAL_DrawText(L"按 Enter 裝備", PAL_XY(140, iY + 8), bEmptyColor, TRUE, FALSE, FALSE);
      return;
   }

   if (PAL_MKFReadChunk(s_bufImage, sizeof(s_bufImage),
      ART_GetTemplateBitmap(lpInstance->wTemplate), gpGlobals->f.fpBALL) > 0)
   {
      PAL_RLEBlitToSurface(s_bufImage, gpScreen, PAL_XY(110, iY + 2));
   }

   PAL_swprintf(szText, sizeof(szText) / sizeof(WCHAR), L"%ls（%ls）",
      ART_GetTemplateName(lpInstance->wTemplate),
      ART_GetQualityName(lpInstance->bQuality));
   PAL_DrawText(szText, PAL_XY(136, iY + 8), bColor, TRUE, FALSE, FALSE);
}


static VOID
ART_DrawWrappedText(
   LPCWSTR lpszText,
   int     x,
   int     y,
   int     iMaxWidth,
   BYTE    color
)
{
   WCHAR szFirst[256];
   WCHAR szRest[256];
   int nLen;
   int nCut;

   wcsncpy(szFirst, lpszText, sizeof(szFirst) / sizeof(WCHAR) - 1);
   szFirst[sizeof(szFirst) / sizeof(WCHAR) - 1] = 0;
   nLen = (int)wcslen(szFirst);
   nCut = nLen;

   while (nCut > 0 && PAL_TextWidth(szFirst) > iMaxWidth)
   {
      szFirst[--nCut] = 0;
   }

   PAL_DrawText(szFirst, PAL_XY(x, y), color, TRUE, FALSE, FALSE);

   if (nCut < nLen)
   {
      wcsncpy(szRest, lpszText + nCut, sizeof(szRest) / sizeof(WCHAR) - 1);
      szRest[sizeof(szRest) / sizeof(WCHAR) - 1] = 0;
      while (wcslen(szRest) > 0 && PAL_TextWidth(szRest) > iMaxWidth)
      {
         szRest[wcslen(szRest) - 1] = 0;
      }
      PAL_DrawText(szRest, PAL_XY(x, y + 16), color, TRUE, FALSE, FALSE);
   }
}

static VOID
ART_DrawDetail(
   int iRole,
   int iSlot,
   int iDetailPage
)
{
   int iIndex = ART_GetEquipped(iRole, iSlot);
   ARTIFACT_INSTANCE *lpInstance = ART_GetInstance(iIndex);
   WCHAR szText[256];
   WCHAR szLine[256];
   int page, pages;

   ART_AddUiBox(PAL_CreateBoxWithShadow(PAL_XY(2, 140), 3, 38, 1, FALSE, 0));

   if (lpInstance == NULL)
   {
      PAL_DrawText(L"空法寶槽", PAL_XY(10, 150), MENUITEM_COLOR_INACTIVE, TRUE, FALSE, FALSE);
      return;
   }

   pages = lpInstance->bAffixCount;
   if (pages < 1) pages = 1;
   page = (iDetailPage % pages);

   PAL_swprintf(szText, sizeof(szText) / sizeof(WCHAR), L"%ls  %ls  [%d/%d]",
      ART_GetTemplateName(lpInstance->wTemplate),
      ART_GetQualityName(lpInstance->bQuality), page + 1, pages);
   PAL_DrawText(szText, PAL_XY(10, 148), ART_GetQualityColor(lpInstance->bQuality), TRUE, FALSE, FALSE);

   if (page < lpInstance->bAffixCount)
   {
      WCHAR szDesc[256];
      BYTE color = ART_IsAffixActive(iRole, iSlot, page) ? ART_DETAIL_COLOR : MENUITEM_COLOR_INACTIVE;

      ART_GetAffixDesc(lpInstance, page, szDesc, sizeof(szDesc) / sizeof(WCHAR));
      PAL_swprintf(szLine, sizeof(szLine) / sizeof(WCHAR), L"%ls：%ls",
         ART_GetAffixName(lpInstance->affixes[page].wAffix), szDesc);
      ART_DrawWrappedText(szLine, 10, 168, 260, color);
   }
}

static VOID
ART_DrawBag(
   ART_UI_STATE *lpState
)
{
   int count = ART_GetUnequippedBagCount();
   int start = lpState->iBagPage * ART_BAG_PAGE_SIZE;
   int i, y = 38;
   WCHAR szText[128];

   ART_AddUiBox(PAL_CreateBoxWithShadow(PAL_XY(6, 16), 8, 38, 1, FALSE, 0));
   PAL_DrawText(L"法寶囊  Enter 裝備  D 分解  Esc 返回",
      PAL_XY(18, 20), MENUITEM_COLOR_CONFIRMED, TRUE, FALSE, FALSE);

   if (count == 0)
   {
      PAL_DrawText(L"空", PAL_XY(18, 48), MENUITEM_COLOR_INACTIVE, TRUE, FALSE, FALSE);
      return;
   }

   for (i = 0; i < ART_BAG_PAGE_SIZE; i++)
   {
      int ordinal = start + i;
      int index;
      ARTIFACT_INSTANCE *lpInstance;

      if (ordinal >= count)
      {
         break;
      }

      index = ART_GetUnequippedBagIndexByOrdinal(ordinal);
      lpInstance = ART_GetInstance(index);
      if (lpInstance == NULL)
      {
         continue;
      }

      PAL_swprintf(szText, sizeof(szText) / sizeof(WCHAR), L"%ls  %ls  %ls",
         (ordinal == lpState->iBagCursor) ? L">" : L" ",
         ART_GetTemplateName(lpInstance->wTemplate),
         ART_GetQualityName(lpInstance->bQuality));

      PAL_DrawText(szText, PAL_XY(18, y),
         (ordinal == lpState->iBagCursor) ? MENUITEM_COLOR_SELECTED :
         ART_GetQualityColor(lpInstance->bQuality), TRUE, FALSE, FALSE);
      y += 18;
   }

   PAL_swprintf(szText, sizeof(szText) / sizeof(WCHAR), L"%d/%d  PgUp/PgDn 翻頁",
      lpState->iBagCursor + 1, count);
   PAL_DrawText(szText, PAL_XY(18, 158), MENUITEM_COLOR_INACTIVE, TRUE, FALSE, FALSE);
}

static VOID
ART_DrawMain(
   ART_UI_STATE *lpState
)
{
   int i;
   int role = gpGlobals->rgParty[lpState->iRoleIndex].wPlayerRole;

   ART_ResetUiBoxes();
   ART_LoadBackground();
   PAL_FBPBlitToSurface(s_bufBackground, gpScreen);
   ART_DrawAvatar(role);

   PAL_DrawText(L"D 卸下  PgUp/PgDn 詞條  Enter 裝備",
      PAL_XY(8, 8), MENUITEM_COLOR_CONFIRMED, TRUE, FALSE, FALSE);

   for (i = 0; i < ARTIFACT_SLOTS; i++)
   {
      ART_DrawSlot(role, i, 44 + i * 32, i == lpState->iSlot);
   }

   ART_DrawDetail(role, lpState->iSlot, lpState->iDetailPage);

   if (lpState->fBagMode)
   {
      ART_DrawBag(lpState);
   }

   VIDEO_UpdateScreen(NULL);
}

static VOID
ART_RoleNext(
   ART_UI_STATE *lpState,
   int iDelta
)
{
   int n = gpGlobals->wMaxPartyMemberIndex + 1;

   lpState->iRoleIndex += iDelta;
   if (lpState->iRoleIndex < 0) lpState->iRoleIndex = n - 1;
   if (lpState->iRoleIndex >= n) lpState->iRoleIndex = 0;
   lpState->iSlot = 0;
   lpState->iDetailPage = 0;
}

static VOID
ART_EquipSelected(
   ART_UI_STATE *lpState
)
{
   int role = gpGlobals->rgParty[lpState->iRoleIndex].wPlayerRole;
   int ordinal = lpState->iBagCursor;
   int index = ART_GetUnequippedBagIndexByOrdinal(ordinal);

   if (index < 0) return;
   ART_Equip(role, lpState->iSlot, index);
   lpState->fBagMode = FALSE;
   lpState->iDetailPage = 0;
}

static VOID
ART_DismantleSelected(
   ART_UI_STATE *lpState
)
{
   int index = ART_GetUnequippedBagIndexByOrdinal(lpState->iBagCursor);

   if (index < 0) return;
   ART_Dismantle(index);
   if (lpState->iBagCursor > 0 && lpState->iBagCursor >= ART_GetUnequippedBagCount())
   {
      lpState->iBagCursor = ART_GetUnequippedBagCount() - 1;
   }
}

VOID
ART_ShowMenu(
   VOID
)
{
   ART_UI_STATE state;
   DWORD dwTime;

   ART_Init();
   memset(&state, 0, sizeof(state));
   state.iRoleIndex = 0;
   state.iSlot = 0;

   PAL_ClearKeyState();
   dwTime = SDL_GetTicks();

   while (TRUE)
   {
      ART_DrawMain(&state);

      PAL_ProcessEvent();
      if (g_InputState.dwKeyPress & kKeyMenu)
      {
         if (state.fBagMode)
         {
            state.fBagMode = FALSE;
         }
         else
         {
            break;
         }
      }
      else if (state.fBagMode)
      {
         int count = ART_GetUnequippedBagCount();

         if (g_InputState.dwKeyPress & kKeyUp)
         {
            if (state.iBagCursor > 0) state.iBagCursor--;
         }
         else if (g_InputState.dwKeyPress & kKeyDown)
         {
            if (state.iBagCursor + 1 < count) state.iBagCursor++;
         }
         else if (g_InputState.dwKeyPress & kKeyPgUp)
         {
            state.iBagCursor -= ART_BAG_PAGE_SIZE;
            if (state.iBagCursor < 0) state.iBagCursor = 0;
         }
         else if (g_InputState.dwKeyPress & kKeyPgDn)
         {
            state.iBagCursor += ART_BAG_PAGE_SIZE;
            if (state.iBagCursor >= count) state.iBagCursor = count - 1;
         }
         else if (g_InputState.dwKeyPress & kKeySearch)
         {
            ART_EquipSelected(&state);
         }
         else if (g_InputState.dwKeyPress & (kKeyLeft | kKeyRight))
         {
            int delta = (g_InputState.dwKeyPress & kKeyRight) ? 1 : -1;
            state.iBagCursor += delta;
            if (state.iBagCursor < 0) state.iBagCursor = 0;
            if (state.iBagCursor >= count) state.iBagCursor = count - 1;
         }
         
         if (g_InputState.dwKeyPress & kKeyDefend)
         {
            ART_DismantleSelected(&state);
         }

         if (count > 0)
         {
            state.iBagPage = state.iBagCursor / ART_BAG_PAGE_SIZE;
         }
      }
      else
      {
         if (g_InputState.dwKeyPress & kKeyLeft)
         {
            ART_RoleNext(&state, -1);
         }
         else if (g_InputState.dwKeyPress & kKeyRight)
         {
            ART_RoleNext(&state, 1);
         }
         else if (g_InputState.dwKeyPress & kKeyUp)
         {
            if (state.iSlot > 0) state.iSlot--;
            state.iDetailPage = 0;
         }
         else if (g_InputState.dwKeyPress & kKeyDown)
         {
            if (state.iSlot + 1 < ARTIFACT_SLOTS) state.iSlot++;
            state.iDetailPage = 0;
         }
         else if (g_InputState.dwKeyPress & kKeyPgUp)
         {
            if (state.iDetailPage > 0) state.iDetailPage--;
         }
         else if (g_InputState.dwKeyPress & kKeyPgDn)
         {
            state.iDetailPage++;
         }
         else if (g_InputState.dwKeyPress & kKeySearch)
         {
            int role = gpGlobals->rgParty[state.iRoleIndex].wPlayerRole;
            if (ART_GetEquipped(role, state.iSlot) < 0)
            {
               state.fBagMode = TRUE;
               state.iBagCursor = 0;
               state.iBagPage = 0;
            }
         }
         else if (g_InputState.dwKeyPress & kKeyDefend)
         {
            int role = gpGlobals->rgParty[state.iRoleIndex].wPlayerRole;
            ART_Unequip(role, state.iSlot);
         }
      }

      PAL_ClearKeyState();

      {
         DWORD now = SDL_GetTicks();
         if (now < dwTime)
         {
            SDL_Delay(dwTime - now);
         }
         dwTime = SDL_GetTicks() + FRAME_TIME;
      }
   }

   ART_ResetUiBoxes();
}

/* ---------------------------------------------------------------- */
/* Battle drop display                                              */
/* ---------------------------------------------------------------- */

static VOID
ART_DrawDrop(
   ARTIFACT_DROP *lpDrops,
   int iCount,
   int iCurrent,
   int iPage
)
{
   ARTIFACT_INSTANCE *lpInstance;
   WCHAR szText[256];
   WCHAR szLine[256];
   int pages;
   static PAL_LARGE BYTE buf[320 * 200];

   lpInstance = &lpDrops[iCurrent].instance;
   pages = lpInstance->bAffixCount;
   if (pages < 1) pages = 1;
   if (iPage >= pages) iPage = pages - 1;

   ART_ResetUiBoxes();
   ART_LoadBackground();
   PAL_FBPBlitToSurface(s_bufBackground, gpScreen);

   ART_AddUiBox(PAL_CreateBoxWithShadow(PAL_XY(10, 16), 9, 38, 1, FALSE, 0));
   PAL_swprintf(szText, sizeof(szText) / sizeof(WCHAR), L"獲得法寶 %d/%d", iCurrent + 1, iCount);
   PAL_DrawText(szText, PAL_XY(26, 26), MENUITEM_COLOR_CONFIRMED, TRUE, FALSE, FALSE);

   PAL_swprintf(szText, sizeof(szText) / sizeof(WCHAR), L"%ls（%ls）",
      ART_GetTemplateName(lpInstance->wTemplate),
      ART_GetQualityName(lpInstance->bQuality));
   PAL_DrawText(szText, PAL_XY(26, 48), ART_GetQualityColor(lpInstance->bQuality), TRUE, FALSE, FALSE);

   if (iPage < lpInstance->bAffixCount)
   {
      ART_GetAffixDesc(lpInstance, iPage, szLine, sizeof(szLine) / sizeof(WCHAR));
      PAL_swprintf(szText, sizeof(szText) / sizeof(WCHAR), L"%ls：%ls",
         ART_GetAffixName(lpInstance->affixes[iPage].wAffix), szLine);
      ART_DrawWrappedText(szText, 26, 74, 260, ART_DETAIL_COLOR);
   }

   if (lpDrops[iCurrent].fAutoDismantled)
   {
      PAL_DrawText(L"法寶囊已滿：自動分解為靈塵", PAL_XY(26, 120),
         MENUITEM_COLOR_INACTIVE, TRUE, FALSE, FALSE);
   }

   PAL_swprintf(szText, sizeof(szText) / sizeof(WCHAR), L"詞條 %d/%d  PgUp/PgDn  Enter 下一個",
      iPage + 1, pages);
   PAL_DrawText(szText, PAL_XY(26, 158), MENUITEM_COLOR_INACTIVE, TRUE, FALSE, FALSE);

   VIDEO_UpdateScreen(NULL);
}


static VOID
ART_DrawNoticeLine(
   LPCWSTR lpszText,
   int iY,
   int iMaxWidth
)
{
   WCHAR szFirst[256];
   WCHAR szRest[256];
   int nLen, nCut;

   wcsncpy(szFirst, lpszText, sizeof(szFirst) / sizeof(WCHAR) - 1);
   szFirst[sizeof(szFirst) / sizeof(WCHAR) - 1] = 0;
   nLen = (int)wcslen(szFirst);
   nCut = nLen;
   while (nCut > 0 && PAL_TextWidth(szFirst) > iMaxWidth)
   {
      szFirst[--nCut] = 0;
   }
   PAL_DrawText(szFirst, PAL_XY((320 - PAL_TextWidth(szFirst)) / 2 + 1, iY + 1), 0x00, TRUE, FALSE, FALSE);
   PAL_DrawText(szFirst, PAL_XY((320 - PAL_TextWidth(szFirst)) / 2, iY), 0x0F, TRUE, FALSE, FALSE);

   if (nCut < nLen)
   {
      wcsncpy(szRest, lpszText + nCut, sizeof(szRest) / sizeof(WCHAR) - 1);
      szRest[sizeof(szRest) / sizeof(WCHAR) - 1] = 0;
      while (wcslen(szRest) > 0 && PAL_TextWidth(szRest) > iMaxWidth)
      {
         szRest[wcslen(szRest) - 1] = 0;
      }
      PAL_DrawText(szRest, PAL_XY((320 - PAL_TextWidth(szRest)) / 2 + 1, iY + 17), 0x00, TRUE, FALSE, FALSE);
      PAL_DrawText(szRest, PAL_XY((320 - PAL_TextWidth(szRest)) / 2, iY + 16), 0x0F, TRUE, FALSE, FALSE);
   }
}

VOID
ART_DrawBattleNotices(
   VOID
)
{
   WCHAR szText[128];

   if (ART_GetBattleNotice(szText, sizeof(szText) / sizeof(WCHAR)))
   {
      ART_DrawNoticeLine(szText, 92, 300);
   }
}


VOID
ART_ShowBattleStatus(
   VOID
)
{
   static const WCHAR *rgszStatus[][2] =
   {
      { L"混亂", L"negative" },
      { L"遲緩", L"negative" },
      { L"睡眠", L"negative" },
      { L"沉默", L"negative" },
      { L"傀儡", L"negative" },
      { L"勇氣", L"buff" },
      { L"護體", L"buff" },
      { L"加速", L"buff" },
      { L"雙攻", L"buff" },
   };
   int iRole = 0;
   int iPage = 0;
   BOOL fExit = FALSE;
   int i;

   PAL_ClearKeyState();

   while (!fExit)
   {
      WORD wRole = gpGlobals->rgParty[iRole].wPlayerRole;
      WORD wMask = ART_GetBuffMask(wRole);
      WCHAR szText[256];
      WCHAR szDetail[128];
      int iBuffCount = 0;
      int iStatusCount = 0;
      int iStatusBuff = 0;
      int iStatusDebuff = 0;
      int iTotal;
      int iRow;
      int iMaxRows = 7;
      int iStart;

      for (i = 0; i < ART_BUFF_COUNT; i++)
      {
         if (wMask & (1u << i)) iBuffCount++;
      }
      for (i = 0; i < kStatusAll; i++)
      {
         if (gpGlobals->rgPlayerStatus[wRole][i] > 0)
         {
            iStatusCount++;
            if (i < kStatusPuppet) iStatusDebuff++;
            else iStatusBuff++;
         }
      }
      iTotal = iBuffCount + iStatusCount;
      if (iTotal == 0) iTotal = 1;
      if (iPage * iMaxRows >= iTotal) iPage = (iTotal - 1) / iMaxRows;

      ART_ResetUiBoxes();
      ART_LoadBackground();
      PAL_FBPBlitToSurface(s_bufBackground, gpScreen);
      ART_AddUiBox(PAL_CreateBoxWithShadow(PAL_XY(4, 4), 11, 38, 1, FALSE, 0));

      PAL_swprintf(szText, sizeof(szText) / sizeof(WCHAR),
         L"戰鬥狀態  %ls", PAL_GetWord(gpGlobals->g.PlayerRoles.rgwName[wRole]));
      PAL_DrawText(szText, PAL_XY(12, 10), MENUITEM_COLOR_CONFIRMED, TRUE, FALSE, FALSE);
      PAL_DrawText(L"←/→ 角色  PgUp/PgDn 翻頁",
         PAL_XY(12, 26), MENUITEM_COLOR_INACTIVE, TRUE, FALSE, FALSE);
      PAL_DrawText(L"5/Esc 關閉", PAL_XY(12, 42), MENUITEM_COLOR_INACTIVE, TRUE, FALSE, FALSE);

      PAL_swprintf(szText, sizeof(szText) / sizeof(WCHAR),
         L"普攻 %d→%d  法寶+%d%%",
         (int)PAL_GetPlayerAttackStrength(wRole),
         (int)(PAL_GetPlayerAttackStrength(wRole) * ART_GetPhysicalMultiplier(wRole)),
         (int)((ART_GetPhysicalMultiplier(wRole) - 1.0f) * 100.0f));
      PAL_DrawText(szText, PAL_XY(12, 58), ART_DETAIL_COLOR, TRUE, FALSE, FALSE);

      PAL_swprintf(szText, sizeof(szText) / sizeof(WCHAR),
         L"增益%d 減益%d 第%d頁", iBuffCount + iStatusBuff, iStatusDebuff, iPage + 1);
      PAL_DrawText(szText, PAL_XY(12, 74), MENUITEM_COLOR_INACTIVE, TRUE, FALSE, FALSE);

      iStart = iPage * iMaxRows;
      iRow = 0;
      /* Buffs first. */
      for (i = 0; i < ART_BUFF_COUNT; i++)
      {
         if (wMask & (1u << i))
         {
            if (iRow >= iStart && iRow < iStart + iMaxRows)
            {
               ART_GetBuffDetail(wRole, i, szDetail, sizeof(szDetail) / sizeof(WCHAR));
               PAL_swprintf(szText, sizeof(szText) / sizeof(WCHAR),
                  L"%ls  %ls   被動", ART_GetBuffAbbrev(i), szDetail);
               PAL_DrawText(szText, PAL_XY(20, 90 + (iRow - iStart) * 16),
                  0x0F, TRUE, FALSE, FALSE);
            }
            iRow++;
         }
      }
      /* Then normal statuses. */
      for (i = 0; i < kStatusAll; i++)
      {
         WORD dur = gpGlobals->rgPlayerStatus[wRole][i];
         if (dur > 0)
         {
            if (iRow >= iStart && iRow < iStart + iMaxRows)
            {
               PAL_swprintf(szText, sizeof(szText) / sizeof(WCHAR),
                  L"%ls   剩餘 %u 回合",
                  rgszStatus[i][0], (unsigned)dur);
               PAL_DrawText(szText, PAL_XY(20, 90 + (iRow - iStart) * 16),
                  (i < kStatusPuppet) ? 0x5F : 0x1B, TRUE, FALSE, FALSE);
            }
            iRow++;
         }
      }

      if (iBuffCount + iStatusCount == 0)
      {
         PAL_DrawText(L"目前沒有增益或減益", PAL_XY(20, 66), MENUITEM_COLOR_INACTIVE, TRUE, FALSE, FALSE);
      }

      VIDEO_UpdateScreen(NULL);
      PAL_ProcessEvent();

      if (g_InputState.dwKeyPress & (kKeyMenu | kKeyNum5))
      {
         fExit = TRUE;
      }
      else if (g_InputState.dwKeyPress & kKeyLeft)
      {
         if (iRole > 0) iRole--;
         iPage = 0;
      }
      else if (g_InputState.dwKeyPress & kKeyRight)
      {
         if (iRole + 1 <= gpGlobals->wMaxPartyMemberIndex) iRole++;
         iPage = 0;
      }
      else if (g_InputState.dwKeyPress & kKeyPgUp)
      {
         if (iPage > 0) iPage--;
      }
      else if (g_InputState.dwKeyPress & kKeyPgDn)
      {
         iPage++;
      }

      PAL_ClearKeyState();
      SDL_Delay(FRAME_TIME);
   }

   ART_ResetUiBoxes();
   PAL_ClearKeyState();
}


VOID
ART_ShowBattleDrops(
   BOOL fBoss
)
{
   ARTIFACT_DROP drops[8];
   int count = 0;
   int current = 0;
   int page = 0;
   DWORD dwTime;
   BOOL fExit = FALSE;

   ART_GenerateDrops(fBoss, drops, &count);
   if (count <= 0) return;

   PAL_ClearKeyState();
   dwTime = SDL_GetTicks();

   while (!fExit)
   {
      ART_DrawDrop(drops, count, current, page);

      PAL_ProcessEvent();
      if (g_InputState.dwKeyPress & (kKeyMenu | kKeySearch))
      {
         if (g_InputState.dwKeyPress & kKeySearch)
         {
            page++;
            if (page >= drops[current].instance.bAffixCount)
            {
               page = 0;
               current++;
               if (current >= count)
               {
                  fExit = TRUE;
               }
            }
         }
         else
         {
            fExit = TRUE;
         }
      }
      else if (g_InputState.dwKeyPress & kKeyPgUp)
      {
         if (page > 0) page--;
      }
      else if (g_InputState.dwKeyPress & kKeyPgDn)
      {
         page++;
      }
      else if (g_InputState.dwKeyPress & kKeyLeft)
      {
         if (current > 0) current--;
         page = 0;
      }
      else if (g_InputState.dwKeyPress & kKeyRight)
      {
         if (current + 1 < count) current++;
         page = 0;
      }

      PAL_ClearKeyState();
      {
         DWORD now = SDL_GetTicks();
         if (now < dwTime) SDL_Delay(dwTime - now);
         dwTime = SDL_GetTicks() + FRAME_TIME;
      }
   }

   ART_ResetUiBoxes();
}
