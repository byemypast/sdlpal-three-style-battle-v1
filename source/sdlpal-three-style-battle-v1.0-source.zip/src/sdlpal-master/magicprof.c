/*
 * Magic proficiency runtime state.
 *
 * The data is persisted by artifacts.c in the per-save sidecar; this module
 * only owns the in-memory table, thresholds and combat helpers.
 */

#include "main.h"
#include "palcfg.h"
#include "magicprof.h"
#include "customspell.h"

static const WORD s_rgwMagicIds[MAGICPROF_MAGIC_COUNT] =
{
   297, 298, 299, 300, 301, 302, 306, 307, 308, 309, 310, 311, 392,
   337, 340, 341, 342, 344, 345, 346, 348, 351, 363, 349, 394,
   313, 314, 315, 316, 317, 318, 319, 320, 321, 322, 323, 325,
   327, 328, 329, 330, 389, 332, 333, 334, 335, 336,
   303, 304, 305, 352, 354, 372, 374,
   377, CUSTOMSPELL_OBJECT_ID
};

static WORD  s_rgwProf[MAX_PLAYER_ROLES][MAGICPROF_MAGIC_COUNT];
static WORD  s_rgwThreshold[MAGICPROF_MAGIC_COUNT];
static BOOL  s_fInitialized = FALSE;

static INT
MAGICPROF_Index(
   WORD wMagicObject
)
{
   int i;

   for (i = 0; i < MAGICPROF_MAGIC_COUNT; i++)
   {
      if (s_rgwMagicIds[i] == wMagicObject)
      {
         return i;
      }
   }

   return -1;
}

static VOID
MAGICPROF_LoadThresholds(
   VOID
)
{
   FILE *fp;
   char line[128];
   int i;

   for (i = 0; i < MAGICPROF_MAGIC_COUNT; i++)
   {
      s_rgwThreshold[i] = MAGICPROF_DEFAULT_THRESHOLD;
   }

   fp = UTIL_OpenFileAtPath(gConfig.pszGamePath, "magicprof.cfg");
   if (fp == NULL)
   {
      return;
   }

   while (fgets(line, sizeof(line), fp) != NULL)
   {
      unsigned int id, threshold;
      int index;

      if (line[0] == '#' || line[0] == ';' || line[0] == '\n' || line[0] == '\r')
      {
         continue;
      }

      if (sscanf(line, "%u=%u", &id, &threshold) != 2)
      {
         continue;
      }

      index = MAGICPROF_Index((WORD)id);
      if (index >= 0 && threshold >= 1 && threshold <= MAGICPROF_MAX)
      {
         s_rgwThreshold[index] = (WORD)threshold;
      }
   }

   fclose(fp);
}

VOID
MAGICPROF_Init(
   VOID
)
{
   if (s_fInitialized)
   {
      return;
   }

   memset(s_rgwProf, 0, sizeof(s_rgwProf));
   MAGICPROF_LoadThresholds();
   s_fInitialized = TRUE;
}

VOID
MAGICPROF_Reset(
   VOID
)
{
   memset(s_rgwProf, 0, sizeof(s_rgwProf));
   MAGICPROF_LoadThresholds();
   s_fInitialized = TRUE;
}

VOID
MAGICPROF_Export(
   WORD *pBuffer
)
{
   MAGICPROF_Init();
   memcpy(pBuffer, s_rgwProf, sizeof(s_rgwProf));
}

VOID
MAGICPROF_Import(
   const WORD *pBuffer
)
{
   MAGICPROF_Init();
   memcpy(s_rgwProf, pBuffer, sizeof(s_rgwProf));
}

WORD
MAGICPROF_Get(
   WORD wPlayerRole,
   WORD wMagicObject
)
{
   INT index;

   MAGICPROF_Init();

   if (wPlayerRole >= MAX_PLAYER_ROLES)
   {
      return 0;
   }

   index = MAGICPROF_Index(wMagicObject);
   if (index < 0)
   {
      return 0;
   }

   return s_rgwProf[wPlayerRole][index];
}

WORD
MAGICPROF_GetThreshold(
   WORD wMagicObject
)
{
   INT index;

   MAGICPROF_Init();

   index = MAGICPROF_Index(wMagicObject);
   if (index < 0)
   {
      return MAGICPROF_DEFAULT_THRESHOLD;
   }

   return s_rgwThreshold[index];
}

BOOL
MAGICPROF_IsInstant(
   WORD wPlayerRole,
   WORD wMagicObject
)
{
   WORD prof = MAGICPROF_Get(wPlayerRole, wMagicObject);
   WORD threshold = MAGICPROF_GetThreshold(wMagicObject);

   if (threshold < 1)
   {
      threshold = MAGICPROF_DEFAULT_THRESHOLD;
   }

   return (prof >= threshold) ? TRUE : FALSE;
}

FLOAT
MAGICPROF_GetSpeedFactor(
   WORD wPlayerRole,
   WORD wMagicObject
)
{
   WORD prof = MAGICPROF_Get(wPlayerRole, wMagicObject);
   WORD threshold = MAGICPROF_GetThreshold(wMagicObject);
   FLOAT factor;

   if (threshold < 1)
   {
      threshold = MAGICPROF_DEFAULT_THRESHOLD;
   }

   if (prof >= threshold)
   {
      return 1.0f;
   }

   factor = 1.0f - 0.5f * (FLOAT)prof / (FLOAT)threshold;
   if (factor < 0.1f)
   {
      factor = 0.1f;
   }

   return factor;
}

WORD
MAGICPROF_GetEnemyProficiency(
   BOOL fBoss
)
{
   return fBoss ? MAGICPROF_DEFAULT_THRESHOLD : 0;
}

VOID
MAGICPROF_OnSuccessfulCast(
   WORD wPlayerRole,
   WORD wMagicObject
)
{
   INT index;

   MAGICPROF_Init();

   if (wPlayerRole >= MAX_PLAYER_ROLES)
   {
      return;
   }

   index = MAGICPROF_Index(wMagicObject);
   if (index < 0)
   {
      return;
   }

   if (wMagicObject == CUSTOMSPELL_OBJECT_ID)
   {
      UTIL_LogOutput(LOGLEVEL_DEBUG, "[MAGICPROF] custom role=%d before=%u index=%d\n",
         (int)wPlayerRole, (unsigned)s_rgwProf[wPlayerRole][index], index);
   }

   if (s_rgwProf[wPlayerRole][index] < MAGICPROF_MAX)
   {
      s_rgwProf[wPlayerRole][index]++;
   }
   if (wMagicObject == CUSTOMSPELL_OBJECT_ID)
   {
      UTIL_LogOutput(LOGLEVEL_DEBUG, "[MAGICPROF] custom role=%d after=%u\n",
         (int)wPlayerRole, (unsigned)s_rgwProf[wPlayerRole][index]);
   }
}
