#!/usr/bin/env python3
"""
Batch-predict the melody channel for MIDI 1-87.

Output format:
    { 1, 3 },
    { 2, 0 },
    ...

Results are displayed in groups of ten, with a blank line between groups.

A tqdm progress bar is used to show prediction progress.

Usage:
    python batch_predict.py [--midi_dir <dir>] [--model <model_path>]

Example:
    python batch_predict.py --midi_dir ./midis --model melody_model.pkl
"""

import os
import sys
import argparse
from contextlib import redirect_stdout

from tqdm import tqdm

# Import the prediction function.
# The function produces detailed output, so stdout is redirected
# during batch prediction.
from predict import predict_channel


DEFAULT_MODEL_PATH = "melody_model.pkl"
MIDI_PREFIX = "MIDI"
START = 1
END = 87


def main():

    parser = argparse.ArgumentParser(
        description=(
            "Batch-predict MIDI melody channels "
            "and output them in C/C++ array format"
        )
    )

    parser.add_argument(
        "--midi_dir",
        default=".",
        help=(
            "Directory containing MIDI files "
            "(default: current directory)"
        ),
    )

    parser.add_argument(
        "--model",
        default=DEFAULT_MODEL_PATH,
        help=(
            "Path to the trained model file "
            "(default: melody_model.pkl)"
        ),
    )

    args = parser.parse_args()

    if not os.path.exists(args.model):

        print(
            f"Error: Model file '{args.model}' does not exist",
            file=sys.stderr,
        )

        sys.exit(1)

    if not os.path.isdir(args.midi_dir):

        print(
            f"Error: MIDI directory '{args.midi_dir}' "
            f"does not exist or is not a directory",
            file=sys.stderr,
        )

        sys.exit(1)

    results = []  # Store (MIDI number, channel)
    errors = []   # Store (MIDI number, error message)

    # Display prediction progress using tqdm.
    for num in tqdm(
        range(START, END + 1),
        desc="Predicting MIDI",
        unit="file",
        ncols=80,
    ):

        filename = (
            f"{MIDI_PREFIX}{num}.mid"
        )

        file_path = os.path.join(
            args.midi_dir,
            filename,
        )

        if not os.path.exists(file_path):

            errors.append(
                (
                    num,
                    "File does not exist",
                )
            )

            results.append(
                (
                    num,
                    -1,
                )
            )

            continue

        ch = -1

        try:

            # Redirect all output produced by predict_channel()
            # to /dev/null and keep only the return value.
            with open(
                os.devnull,
                "w",
            ) as devnull:

                with redirect_stdout(devnull):

                    ch = predict_channel(
                        args.model,
                        file_path,
                        top_k=3,
                    )

        except KeyboardInterrupt:

            print(
                "\nInterrupted by user",
                file=sys.stderr,
            )

            sys.exit(130)

        except Exception as e:

            errors.append(
                (
                    num,
                    str(e),
                )
            )

            # Keep ch as -1 on prediction failure.

        results.append(
            (
                num,
                ch,
            )
        )

    # Print an error summary to stderr if any errors occurred.
    if errors:

        print(
            "\nError Summary:",
            file=sys.stderr,
        )

        for num, err in errors:

            print(
                f"  MIDI{num}.mid: {err}",
                file=sys.stderr,
            )

    # Print a blank line before the result list
    # to separate it from the progress bar.
    print()

    group_size = 10

    # Output results in groups of ten.
    for i in range(
        0,
        len(results),
        group_size,
    ):

        group = results[
            i:i + group_size
        ]

        for num, ch in group:

            # Use decimal integers and right-align the
            # MIDI number for consistent formatting.
            print(
                f"{{ {num:>2d}, {ch} }},"
            )

        # Add a blank line between groups,
        # but not after the final group.
        if (
            i + group_size
            < len(results)
        ):

            print()


if __name__ == "__main__":
    main()