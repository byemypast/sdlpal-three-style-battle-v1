#!/usr/bin/env python3
"""
train.py - MIDI Melody Channel Detection Model Training

Usage:
    python train.py <midi_dir> <labels_csv> [--model melody_model.pkl]

Example:
    python train.py ./midis labels.csv --model melody_model.pkl

labels.csv:
    filename,channel
    song01.mid,3
    song02.mid,1

Description:
    Each MIDI file should have one labeled melody channel.
    The model is trained at the channel level, while cross-validation
    is strictly grouped by MIDI file to prevent channels from the same
    MIDI file from appearing in both training and test sets.

Output:
    - Channel-level Precision / Recall / F1 / ROC-AUC
    - MIDI-level Top-1 / Top-3 accuracy
    - Trained model pickle file
    - Top 20 feature importances
"""

import os
import sys
import argparse
import pickle
import collections
from typing import Dict, List, Tuple

import numpy as np
import pandas as pd
import mido

from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import StratifiedGroupKFold
from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    roc_auc_score,
)


# ============================================================
# Constants
# ============================================================

DEFAULT_TEMPO = 500000  # 120 BPM, microseconds per beat
DRUM_CHANNEL = 9        # MIDI channel 10, zero-based index


# ============================================================
# MIDI parsing
# ============================================================

def build_tempo_map(mid: mido.MidiFile):
    """
    Build a tempo map.

    Returns:
        tempo_events:
            [(tick, tempo), ...]
            tick is the absolute tick position.
            tempo is microseconds per beat.

    MIDI default tempo = 500000 (120 BPM).
    """

    events = [(0, DEFAULT_TEMPO)]

    tick = 0

    for msg in mido.merge_tracks(mid.tracks):
        tick += msg.time

        if msg.is_meta and msg.type == "set_tempo":
            events.append((tick, msg.tempo))

    # If multiple tempo changes occur at the same tick,
    # keep the last one.
    tempo_map = {}

    for t, tempo in events:
        tempo_map[t] = tempo

    result = sorted(
        tempo_map.items(),
        key=lambda x: x[0],
    )

    return result


def ticks_to_seconds(
    tick: int,
    tempo_events: List[Tuple[int, int]],
    ticks_per_beat: int,
) -> float:
    """
    Convert an absolute tick position to seconds.
    Supports tempo changes.
    """

    if tick <= 0:
        return 0.0

    seconds = 0.0

    prev_tick = tempo_events[0][0]
    current_tempo = tempo_events[0][1]

    for event_tick, event_tempo in tempo_events[1:]:

        if event_tick >= tick:
            break

        delta_ticks = event_tick - prev_tick

        seconds += (
            delta_ticks
            / ticks_per_beat
            * current_tempo
            / 1_000_000.0
        )

        prev_tick = event_tick
        current_tempo = event_tempo

    delta_ticks = tick - prev_tick

    seconds += (
        delta_ticks
        / ticks_per_beat
        * current_tempo
        / 1_000_000.0
    )

    return seconds


def extract_channel_notes(midi_path: str):
    """
    Parse a MIDI file.

    Returns:
        {
            channel: {
                "notes": [
                    (start_tick, end_tick, pitch, velocity),
                    ...
                ],
                "program": int,
                "volume": int,
                "pan": int,
                "is_drum": bool,
            }
        }
    """

    try:
        mid = mido.MidiFile(midi_path)

    except Exception as e:

        print(f"[ERROR] Failed to read MIDI: {midi_path}")
        print(f"        {type(e).__name__}: {e}")

        return {}, None, None

    ticks_per_beat = mid.ticks_per_beat

    tempo_events = build_tempo_map(mid)

    # Active notes per channel and pitch.
    #
    # The same pitch may overlap, so use a queue.
    active_notes = collections.defaultdict(
        lambda: collections.defaultdict(collections.deque)
    )

    notes = collections.defaultdict(list)

    programs = {}
    volumes = {}
    pans = {}

    tick = 0

    try:

        for msg in mido.merge_tracks(mid.tracks):

            tick += msg.time

            if msg.is_meta:
                continue

            ch = msg.channel

            if msg.type == "program_change":

                # Record the latest program number.
                programs[ch] = msg.program

            elif msg.type == "control_change":

                if msg.control == 7:
                    volumes[ch] = msg.value

                elif msg.control == 10:
                    pans[ch] = msg.value

            elif msg.type == "note_on":

                if msg.velocity > 0:

                    active_notes[ch][msg.note].append(
                        (tick, msg.velocity)
                    )

                else:

                    # A note_on event with velocity=0
                    # is equivalent to note_off.
                    if active_notes[ch][msg.note]:

                        start_tick, velocity = (
                            active_notes[ch][msg.note].popleft()
                        )

                        if tick > start_tick:

                            notes[ch].append(
                                (
                                    start_tick,
                                    tick,
                                    msg.note,
                                    velocity,
                                )
                            )

            elif msg.type == "note_off":

                if active_notes[ch][msg.note]:

                    start_tick, velocity = (
                        active_notes[ch][msg.note].popleft()
                    )

                    if tick > start_tick:

                        notes[ch].append(
                            (
                                start_tick,
                                tick,
                                msg.note,
                                velocity,
                            )
                        )

    except Exception as e:

        print(
            f"[ERROR] Failed to parse MIDI events: "
            f"{midi_path}"
        )

        print(
            f"        {type(e).__name__}: {e}"
        )

        return {}, None, None

    if not notes:
        return {}, None, None

    # Set default values for channels without
    # program, volume, or pan information.
    channel_data = {}

    for ch, ch_notes in notes.items():

        if not ch_notes:
            continue

        channel_data[ch] = {
            "notes": sorted(
                ch_notes,
                key=lambda x: (x[0], x[2]),
            ),
            "program": programs.get(ch, -1),
            "volume": volumes.get(ch, 64),
            "pan": pans.get(ch, 64),
            "is_drum": ch == DRUM_CHANNEL,
        }

    return (
        channel_data,
        tempo_events,
        ticks_per_beat,
    )


# ============================================================
# Feature extraction
# ============================================================

def safe_entropy(values: np.ndarray) -> float:
    """
    Calculate Shannon entropy.
    """

    if len(values) == 0:
        return 0.0

    counts = np.bincount(values)

    counts = counts[counts > 0]

    if len(counts) <= 1:
        return 0.0

    probs = counts / counts.sum()

    return float(
        -np.sum(
            probs * np.log2(probs)
        )
    )


def coefficient_of_variation(
    values: np.ndarray,
) -> float:

    if len(values) == 0:
        return 0.0

    mean = float(
        np.mean(values)
    )

    if abs(mean) < 1e-8:
        return 0.0

    return float(
        np.std(values)
        / abs(mean)
    )


def extract_features_for_channel(
    channel_data,
    tempo_events,
    ticks_per_beat,
    total_ticks,
):
    """
    Extract melody-oriented features for one MIDI channel.
    """

    notes = channel_data["notes"]

    if not notes:
        return None

    starts = np.array(
        [n[0] for n in notes],
        dtype=np.float64,
    )

    ends = np.array(
        [n[1] for n in notes],
        dtype=np.float64,
    )

    pitches = np.array(
        [n[2] for n in notes],
        dtype=np.float64,
    )

    velocities = np.array(
        [n[3] for n in notes],
        dtype=np.float64,
    )

    durations_ticks = ends - starts

    # --------------------------------------------------------
    # Time conversion
    # --------------------------------------------------------

    start_seconds = np.array([
        ticks_to_seconds(
            int(x),
            tempo_events,
            ticks_per_beat,
        )
        for x in starts
    ])

    end_seconds = np.array([
        ticks_to_seconds(
            int(x),
            tempo_events,
            ticks_per_beat,
        )
        for x in ends
    ])

    durations_seconds = (
        end_seconds - start_seconds
    )

    total_seconds = ticks_to_seconds(
        int(total_ticks),
        tempo_events,
        ticks_per_beat,
    )

    total_seconds = max(
        total_seconds,
        1e-6,
    )

    # --------------------------------------------------------
    # Basic note statistics
    # --------------------------------------------------------

    n_notes = len(notes)

    note_density = (
        n_notes / total_seconds
    )

    mean_pitch = float(
        np.mean(pitches)
    )

    std_pitch = float(
        np.std(pitches)
    )

    min_pitch = float(
        np.min(pitches)
    )

    max_pitch = float(
        np.max(pitches)
    )

    pitch_range = (
        max_pitch - min_pitch
    )

    mean_velocity = float(
        np.mean(velocities)
    )

    std_velocity = float(
        np.std(velocities)
    )

    mean_duration = float(
        np.mean(durations_seconds)
    )

    std_duration = float(
        np.std(durations_seconds)
    )

    cv_duration = coefficient_of_variation(
        durations_seconds
    )

    # --------------------------------------------------------
    # Pitch interval / melodic contour
    # --------------------------------------------------------

    sorted_indices = np.argsort(
        starts
    )

    ordered_pitches = (
        pitches[sorted_indices]
    )

    ordered_starts = (
        starts[sorted_indices]
    )

    ordered_ends = (
        ends[sorted_indices]
    )

    if len(ordered_pitches) > 1:

        pitch_intervals = np.diff(
            ordered_pitches
        )

        abs_pitch_intervals = np.abs(
            pitch_intervals
        )

        mean_pitch_interval = float(
            np.mean(pitch_intervals)
        )

        std_pitch_interval = float(
            np.std(pitch_intervals)
        )

        mean_abs_pitch_interval = float(
            np.mean(abs_pitch_intervals)
        )

        max_pitch_jump = float(
            np.max(abs_pitch_intervals)
        )

        # Ratio of intervals within one or two semitones.
        stepwise_ratio = float(
            np.mean(
                abs_pitch_intervals <= 2
            )
        )

        # Ascending / descending ratio.
        ascending_ratio = float(
            np.mean(
                pitch_intervals > 0
            )
        )

        descending_ratio = float(
            np.mean(
                pitch_intervals < 0
            )
        )

        # Count changes in melodic direction.
        signs = np.sign(
            pitch_intervals
        )

        nonzero_signs = signs[
            signs != 0
        ]

        if len(nonzero_signs) > 1:

            direction_changes = np.sum(
                nonzero_signs[1:]
                != nonzero_signs[:-1]
            )

            direction_change_ratio = (
                direction_changes
                / (len(nonzero_signs) - 1)
            )

        else:

            direction_change_ratio = 0.0

    else:

        mean_pitch_interval = 0.0
        std_pitch_interval = 0.0
        mean_abs_pitch_interval = 0.0
        max_pitch_jump = 0.0
        stepwise_ratio = 0.0
        ascending_ratio = 0.0
        descending_ratio = 0.0
        direction_change_ratio = 0.0

    # --------------------------------------------------------
    # Onset / rhythm
    # --------------------------------------------------------

    unique_starts = np.unique(
        ordered_starts
    )

    if len(unique_starts) > 1:

        onset_intervals_ticks = (
            np.diff(unique_starts)
        )

        onset_intervals_seconds = np.array([

            ticks_to_seconds(
                int(unique_starts[i + 1]),
                tempo_events,
                ticks_per_beat,
            )
            -
            ticks_to_seconds(
                int(unique_starts[i]),
                tempo_events,
                ticks_per_beat,
            )

            for i in range(
                len(unique_starts) - 1
            )
        ])

        mean_onset_interval = float(
            np.mean(
                onset_intervals_seconds
            )
        )

        std_onset_interval = float(
            np.std(
                onset_intervals_seconds
            )
        )

        cv_onset_interval = (
            coefficient_of_variation(
                onset_intervals_seconds
            )
        )

    else:

        mean_onset_interval = 0.0
        std_onset_interval = 0.0
        cv_onset_interval = 0.0

    # --------------------------------------------------------
    # Polyphony
    # --------------------------------------------------------

    # Sweep line:
    # +1 for each note start.
    # -1 for each note end.
    timeline = []

    for start, end in zip(
        starts,
        ends,
    ):

        timeline.append(
            (start, 1)
        )

        timeline.append(
            (end, -1)
        )

    timeline.sort(
        key=lambda x: (
            x[0],
            x[1],
        )
    )

    active = 0
    max_polyphony = 0
    polyphony_time = 0.0
    total_active_time = 0.0

    prev_tick = None

    for current_tick, delta in timeline:

        if prev_tick is not None:

            dt = (
                current_tick - prev_tick
            )

            if active > 0:
                total_active_time += dt

            if active > 1:
                polyphony_time += dt

        active += delta

        max_polyphony = max(
            max_polyphony,
            active,
        )

        prev_tick = current_tick

    if total_active_time > 0:

        polyphony_ratio = (
            polyphony_time
            / total_active_time
        )

    else:

        polyphony_ratio = 0.0

    # --------------------------------------------------------
    # Onset polyphony
    # --------------------------------------------------------

    onset_groups = (
        collections.defaultdict(int)
    )

    for s in starts:
        onset_groups[int(s)] += 1

    onset_counts = np.array(
        list(onset_groups.values()),
        dtype=np.float64,
    )

    if len(onset_counts) > 0:

        mean_notes_per_onset = float(
            np.mean(onset_counts)
        )

        chord_onset_ratio = float(
            np.mean(
                onset_counts > 1
            )
        )

        max_notes_per_onset = float(
            np.max(onset_counts)
        )

    else:

        mean_notes_per_onset = 0.0
        chord_onset_ratio = 0.0
        max_notes_per_onset = 0.0

    # --------------------------------------------------------
    # Overlap ratio
    # --------------------------------------------------------

    overlap_count = 0

    for i in range(
        len(notes)
    ):

        if i == 0:
            continue

        if starts[i] < np.max(
            ends[:i]
        ):

            overlap_count += 1

    overlap_ratio = (
        overlap_count
        / max(
            n_notes - 1,
            1,
        )
    )

    # --------------------------------------------------------
    # Rest ratio
    # --------------------------------------------------------

    if len(unique_starts) > 1:

        first_start = float(
            np.min(starts)
        )

        last_end = float(
            np.max(ends)
        )

        active_span = max(
            last_end - first_start,
            1e-6,
        )

        onset_span = (
            unique_starts[-1]
            - unique_starts[0]
        )

        if onset_span > 0:

            # Approximate rest time using note activity.
            note_activity = np.sum(
                durations_ticks
            )

            rest_ratio = max(
                0.0,
                1.0
                - note_activity
                / active_span,
            )

        else:

            rest_ratio = 0.0

    else:

        rest_ratio = 0.0

    # --------------------------------------------------------
    # Pitch class distribution
    # --------------------------------------------------------

    pitch_classes = (
        pitches.astype(int) % 12
    )

    pitch_class_counts = np.bincount(
        pitch_classes,
        minlength=12,
    ).astype(np.float64)

    pitch_class_dist = (
        pitch_class_counts
        / max(n_notes, 1)
    )

    pitch_class_entropy = safe_entropy(
        pitch_classes
    )

    # --------------------------------------------------------
    # Octave distribution
    # --------------------------------------------------------

    octave_counts = np.zeros(
        11,
        dtype=np.float64,
    )

    for pitch in pitches.astype(int):

        octave = pitch // 12

        if (
            0 <= octave
            < len(octave_counts)
        ):

            octave_counts[octave] += 1

    octave_dist = (
        octave_counts
        / max(n_notes, 1)
    )

    # --------------------------------------------------------
    # Pitch entropy
    # --------------------------------------------------------

    pitch_entropy = safe_entropy(
        pitches.astype(int)
    )

    # --------------------------------------------------------
    # Duration distribution
    # --------------------------------------------------------

    duration_entropy = safe_entropy(
        np.round(
            durations_seconds,
            decimals=3,
        ).astype(int)
    )

    # --------------------------------------------------------
    # Velocity coefficient of variation
    # --------------------------------------------------------

    velocity_cv = coefficient_of_variation(
        velocities
    )

    # --------------------------------------------------------
    # Activity ratio
    # --------------------------------------------------------

    if total_seconds > 0:

        first_second = float(
            np.min(start_seconds)
        )

        last_second = float(
            np.max(end_seconds)
        )

        span_seconds = max(
            last_second - first_second,
            1e-6,
        )

        active_ratio = min(
            np.sum(durations_seconds)
            / span_seconds,
            1.0,
        )

    else:

        active_ratio = 0.0

    # --------------------------------------------------------
    # MIDI metadata
    # --------------------------------------------------------

    program = channel_data["program"]
    volume = channel_data["volume"]
    pan = channel_data["pan"]

    is_drum = float(
        channel_data["is_drum"]
    )

    # --------------------------------------------------------
    # Final feature vector
    # --------------------------------------------------------

    feature_values = [

        # Basic
        n_notes,
        note_density,
        mean_pitch,
        std_pitch,
        pitch_range,
        min_pitch,
        max_pitch,

        # Velocity
        mean_velocity,
        std_velocity,
        velocity_cv,

        # Duration
        mean_duration,
        std_duration,
        cv_duration,
        duration_entropy,

        # Pitch contour
        mean_pitch_interval,
        std_pitch_interval,
        mean_abs_pitch_interval,
        max_pitch_jump,
        stepwise_ratio,
        ascending_ratio,
        descending_ratio,
        direction_change_ratio,

        # Rhythm
        mean_onset_interval,
        std_onset_interval,
        cv_onset_interval,

        # Polyphony
        polyphony_ratio,
        max_polyphony,
        mean_notes_per_onset,
        chord_onset_ratio,
        max_notes_per_onset,
        overlap_ratio,

        # Activity / rest
        active_ratio,
        rest_ratio,

        # Pitch entropy
        pitch_entropy,
        pitch_class_entropy,

        # MIDI metadata
        program,
        volume,
        pan,
        is_drum,
    ]

    feature_values.extend(
        pitch_class_dist.tolist()
    )

    feature_values.extend(
        octave_dist.tolist()
    )

    return np.asarray(
        feature_values,
        dtype=np.float32,
    )


# ============================================================
# Feature names
# ============================================================

def get_feature_names():

    names = [

        # Basic
        "n_notes",
        "note_density",
        "mean_pitch",
        "std_pitch",
        "pitch_range",
        "min_pitch",
        "max_pitch",

        # Velocity
        "mean_velocity",
        "std_velocity",
        "velocity_cv",

        # Duration
        "mean_duration",
        "std_duration",
        "cv_duration",
        "duration_entropy",

        # Pitch contour
        "mean_pitch_interval",
        "std_pitch_interval",
        "mean_abs_pitch_interval",
        "max_pitch_jump",
        "stepwise_ratio",
        "ascending_ratio",
        "descending_ratio",
        "direction_change_ratio",

        # Rhythm
        "mean_onset_interval",
        "std_onset_interval",
        "cv_onset_interval",

        # Polyphony
        "polyphony_ratio",
        "max_polyphony",
        "mean_notes_per_onset",
        "chord_onset_ratio",
        "max_notes_per_onset",
        "overlap_ratio",

        # Activity
        "active_ratio",
        "rest_ratio",

        # Entropy
        "pitch_entropy",
        "pitch_class_entropy",

        # MIDI
        "program",
        "volume",
        "pan",
        "is_drum",
    ]

    names.extend(
        [
            f"pitch_class_{i}"
            for i in range(12)
        ]
    )

    names.extend(
        [
            f"octave_{i}"
            for i in range(11)
        ]
    )

    return names


# ============================================================
# Dataset loading
# ============================================================

def load_data(
    midi_dir: str,
    labels_csv: str,
):
    """
    Load training data.

    Returns:
        X
        y
        groups
        sample_info
        midi_groups

    midi_groups:
        {
            filename: {
                "channels": [...],
                "true_channel": int
            }
        }
    """

    df = pd.read_csv(
        labels_csv,
        skipinitialspace=True,
    )

    required_columns = {
        "filename",
        "channel",
    }

    missing = (
        required_columns
        - set(df.columns)
    )

    if missing:

        raise ValueError(
            f"labels.csv is missing fields: "
            f"{sorted(missing)}"
        )

    X_list = []
    y_list = []

    groups = []
    sample_info = []

    midi_groups = {}

    for _, row in df.iterrows():

        fname = str(
            row["filename"]
        ).strip()

        try:

            true_channel = int(
                row["channel"]
            )

        except Exception:

            print(
                f"[WARN] Invalid channel, "
                f"skipping: {fname}"
            )

            continue

        midi_path = os.path.join(
            midi_dir,
            fname,
        )

        if not os.path.exists(
            midi_path
        ):

            print(
                f"[WARN] File not found, "
                f"skipping: {midi_path}"
            )

            continue

        (
            channel_data,
            tempo_events,
            ticks_per_beat,
        ) = extract_channel_notes(
            midi_path
        )

        if not channel_data:

            print(
                f"[WARN] No valid notes found, "
                f"skipping: {fname}"
            )

            continue

        # Get total MIDI ticks.
        try:

            mid = mido.MidiFile(
                midi_path
            )

            total_ticks = 0

            for track in mid.tracks:

                track_tick = 0

                for msg in track:
                    track_tick += msg.time

                total_ticks = max(
                    total_ticks,
                    track_tick,
                )

        except Exception as e:

            print(
                f"[WARN] Failed to get MIDI duration: "
                f"{fname}: {e}"
            )

            continue

        valid_channels = []

        for ch, data in (
            channel_data.items()
        ):

            # There is no need to explicitly filter drum
            # channels as melody candidates.
            # The is_drum feature is retained.
            #
            # If the label explicitly marks a drum channel
            # as the melody, keep it instead of filtering it.
            feat = extract_features_for_channel(
                data,
                tempo_events,
                ticks_per_beat,
                total_ticks,
            )

            if feat is None:
                continue

            label = int(
                ch == true_channel
            )

            X_list.append(feat)

            y_list.append(label)

            groups.append(fname)

            sample_info.append(
                (
                    fname,
                    ch,
                )
            )

            valid_channels.append(ch)

        if valid_channels:

            midi_groups[fname] = {
                "channels": valid_channels,
                "true_channel": true_channel,
            }

    if not X_list:

        raise RuntimeError(
            "No training samples were successfully extracted."
        )

    X = np.asarray(
        X_list,
        dtype=np.float32,
    )

    y = np.asarray(
        y_list,
        dtype=np.int32,
    )

    groups = np.asarray(
        groups
    )

    return (
        X,
        y,
        groups,
        sample_info,
        midi_groups,
    )


# ============================================================
# MIDI-level evaluation
# ============================================================

def evaluate_midi_ranking(
    model,
    X,
    y,
    sample_info,
):
    """
    Rank channels within each MIDI file using model
    probabilities.

    Returns:
        top1_accuracy
        top3_accuracy
        details
    """

    probabilities = (
        model.predict_proba(X)[:, 1]
    )

    grouped = collections.defaultdict(
        list
    )

    for i, (
        fname,
        ch,
    ) in enumerate(sample_info):

        grouped[fname].append(
            (
                ch,
                probabilities[i],
                int(y[i]),
            )
        )

    top1_correct = 0
    top3_correct = 0

    details = []

    for fname, items in grouped.items():

        items = sorted(
            items,
            key=lambda x: x[1],
            reverse=True,
        )

        true_channels = [
            ch
            for ch, _, label in items
            if label == 1
        ]

        if not true_channels:
            continue

        true_channel = true_channels[0]

        ranked_channels = [
            ch
            for ch, _, _ in items
        ]

        top1 = ranked_channels[0]

        top3 = ranked_channels[:3]

        top1_ok = (
            top1 == true_channel
        )

        top3_ok = (
            true_channel in top3
        )

        top1_correct += int(
            top1_ok
        )

        top3_correct += int(
            top3_ok
        )

        details.append(
            {
                "filename": fname,
                "true_channel": true_channel,
                "predicted_channel": top1,
                "top3_channels": top3,
                "top1_correct": top1_ok,
                "top3_correct": top3_ok,
            }
        )

    n = len(details)

    if n == 0:

        return (
            0.0,
            0.0,
            details,
        )

    return (
        top1_correct / n,
        top3_correct / n,
        details,
    )


# ============================================================
# Main
# ============================================================

def main():

    parser = argparse.ArgumentParser(
        description=(
            "Train a MIDI melody channel "
            "detection model"
        )
    )

    parser.add_argument(
        "midi_dir",
        help="Directory containing MIDI files",
    )

    parser.add_argument(
        "labels_csv",
        help=(
            "Label CSV in the format "
            "filename,channel"
        ),
    )

    parser.add_argument(
        "--model",
        default="melody_model.pkl",
        help="Output model file",
    )

    parser.add_argument(
        "--n-estimators",
        type=int,
        default=300,
        help=(
            "Number of Random Forest trees, "
            "default: 300"
        ),
    )

    parser.add_argument(
        "--seed",
        type=int,
        default=42,
        help="Random seed",
    )

    args = parser.parse_args()

    print("=" * 60)
    print("MIDI Melody Channel Detector")
    print("=" * 60)

    # --------------------------------------------------------
    # Load data
    # --------------------------------------------------------

    print(
        "\n[1/5] "
        "Loading MIDI files and extracting features..."
    )

    (
        X,
        y,
        groups,
        sample_info,
        midi_groups,
    ) = load_data(
        args.midi_dir,
        args.labels_csv,
    )

    feature_names = get_feature_names()

    print(
        f"Channel samples: {len(X)}"
    )

    print(
        f"MIDI files: "
        f"{len(midi_groups)}"
    )

    print(
        f"Features: {X.shape[1]}"
    )

    print(
        f"Positive samples: "
        f"{int(np.sum(y))}"
    )

    print(
        f"Negative samples: "
        f"{int(len(y) - np.sum(y))}"
    )

    print(
        f"Positive ratio: "
        f"{np.mean(y):.4f}"
    )

    # --------------------------------------------------------
    # Sanity checks
    # --------------------------------------------------------

    if len(np.unique(y)) < 2:

        raise RuntimeError(
            "The training data contains only one class. "
            "Binary classification cannot be performed."
        )

    n_groups = len(
        np.unique(groups)
    )

    if n_groups < 5:

        raise RuntimeError(
            f"Only {n_groups} MIDI files are available. "
            f"At least 5 files are required for 5-fold "
            f"Group CV."
        )

    # --------------------------------------------------------
    # Model
    # --------------------------------------------------------

    clf = RandomForestClassifier(
        n_estimators=args.n_estimators,
        class_weight="balanced",
        random_state=args.seed,
        n_jobs=-1,
        min_samples_leaf=2,
        max_features="sqrt",
    )

    # --------------------------------------------------------
    # Group CV
    # --------------------------------------------------------

    print(
        "\n[2/5] "
        "Running 5-fold MIDI-level Group CV..."
    )

    cv = StratifiedGroupKFold(
        n_splits=5,
        shuffle=True,
        random_state=args.seed,
    )

    channel_metrics = []

    midi_top1_scores = []
    midi_top3_scores = []

    fold = 0

    for train_idx, test_idx in cv.split(
        X,
        y,
        groups,
    ):

        fold += 1

        X_train = X[train_idx]
        y_train = y[train_idx]

        X_test = X[test_idx]
        y_test = y[test_idx]

        train_groups = set(
            groups[train_idx]
        )

        test_groups = set(
            groups[test_idx]
        )

        # Safety check:
        # The same MIDI file must never appear
        # in both training and test sets.
        intersection = (
            train_groups
            & test_groups
        )

        if intersection:

            raise RuntimeError(
                "MIDI leakage detected between "
                "training and test sets: "
                f"{intersection}"
            )

        model = RandomForestClassifier(
            n_estimators=args.n_estimators,
            class_weight="balanced",
            random_state=args.seed,
            n_jobs=-1,
            min_samples_leaf=2,
            max_features="sqrt",
        )

        model.fit(
            X_train,
            y_train,
        )

        pred = model.predict(
            X_test
        )

        prob = model.predict_proba(
            X_test
        )[:, 1]

        precision = precision_score(
            y_test,
            pred,
            zero_division=0,
        )

        recall = recall_score(
            y_test,
            pred,
            zero_division=0,
        )

        f1 = f1_score(
            y_test,
            pred,
            zero_division=0,
        )

        accuracy = accuracy_score(
            y_test,
            pred,
        )

        try:

            auc = roc_auc_score(
                y_test,
                prob,
            )

        except ValueError:

            auc = float("nan")

        fold_sample_info = [
            sample_info[i]
            for i in test_idx
        ]

        (
            top1,
            top3,
            _,
        ) = evaluate_midi_ranking(
            model,
            X_test,
            y_test,
            fold_sample_info,
        )

        channel_metrics.append(
            (
                accuracy,
                precision,
                recall,
                f1,
                auc,
            )
        )

        midi_top1_scores.append(
            top1
        )

        midi_top3_scores.append(
            top3
        )

        print(
            f"\nFold {fold}"
        )

        print(
            f"  MIDI train/test: "
            f"{len(train_groups)} / "
            f"{len(test_groups)}"
        )

        print(
            f"  Channel Accuracy: "
            f"{accuracy:.4f}"
        )

        print(
            f"  Precision: "
            f"{precision:.4f}"
        )

        print(
            f"  Recall: "
            f"{recall:.4f}"
        )

        print(
            f"  F1: "
            f"{f1:.4f}"
        )

        print(
            f"  ROC-AUC: "
            f"{auc:.4f}"
        )

        print(
            f"  MIDI Top-1: "
            f"{top1:.4f}"
        )

        print(
            f"  MIDI Top-3: "
            f"{top3:.4f}"
        )

    # --------------------------------------------------------
    # CV summary
    # --------------------------------------------------------

    metrics = np.asarray(
        channel_metrics,
        dtype=np.float64,
    )

    print(
        "\n" + "=" * 60
    )

    print(
        "Cross Validation Summary"
    )

    print(
        "=" * 60
    )

    metric_names = [
        "Accuracy",
        "Precision",
        "Recall",
        "F1",
        "ROC-AUC",
    ]

    for i, name in enumerate(
        metric_names
    ):

        values = metrics[:, i]

        print(
            f"{name:10s}: "
            f"{np.nanmean(values):.4f} "
            f"± {np.nanstd(values):.4f}"
        )

    print(
        f"MIDI Top-1 : "
        f"{np.mean(midi_top1_scores):.4f} "
        f"± {np.std(midi_top1_scores):.4f}"
    )

    print(
        f"MIDI Top-3 : "
        f"{np.mean(midi_top3_scores):.4f} "
        f"± {np.std(midi_top3_scores):.4f}"
    )

    # --------------------------------------------------------
    # Train final model
    # --------------------------------------------------------

    print(
        "\n[3/5] "
        "Training final model using all training data..."
    )

    clf.fit(
        X,
        y,
    )

    # --------------------------------------------------------
    # Feature importance
    # --------------------------------------------------------

    print(
        "\n[4/5] "
        "Feature importance..."
    )

    importances = (
        clf.feature_importances_
    )

    sorted_idx = np.argsort(
        importances
    )[::-1]

    print(
        "\nTop 20:"
    )

    for rank, idx in enumerate(
        sorted_idx[:20],
        start=1,
    ):

        print(
            f"{rank:2d}. "
            f"{feature_names[idx]:30s} "
            f"{importances[idx]:.6f}"
        )

    # --------------------------------------------------------
    # Save model
    # --------------------------------------------------------

    print(
        "\n[5/5] "
        "Saving model..."
    )

    model_bundle = {

        "model": clf,

        "feature_names": feature_names,

        "feature_version": 2,

        "model_type": (
            "RandomForestClassifier"
        ),

        "config": {
            "n_estimators": args.n_estimators,
            "class_weight": "balanced",
            "min_samples_leaf": 2,
            "max_features": "sqrt",
            "random_state": args.seed,
        },

        "training_info": {
            "n_samples": int(
                len(X)
            ),

            "n_midi": int(
                len(midi_groups)
            ),

            "n_features": int(
                X.shape[1]
            ),

            "positive_samples": int(
                np.sum(y)
            ),

            "negative_samples": int(
                len(y) - np.sum(y)
            ),
        },

        "cv_metrics": {

            "channel_accuracy_mean": float(
                np.nanmean(
                    metrics[:, 0]
                )
            ),

            "channel_accuracy_std": float(
                np.nanstd(
                    metrics[:, 0]
                )
            ),

            "precision_mean": float(
                np.nanmean(
                    metrics[:, 1]
                )
            ),

            "precision_std": float(
                np.nanstd(
                    metrics[:, 1]
                )
            ),

            "recall_mean": float(
                np.nanmean(
                    metrics[:, 2]
                )
            ),

            "recall_std": float(
                np.nanstd(
                    metrics[:, 2]
                )
            ),

            "f1_mean": float(
                np.nanmean(
                    metrics[:, 3]
                )
            ),

            "f1_std": float(
                np.nanstd(
                    metrics[:, 3]
                )
            ),

            "roc_auc_mean": float(
                np.nanmean(
                    metrics[:, 4]
                )
            ),

            "roc_auc_std": float(
                np.nanstd(
                    metrics[:, 4]
                )
            ),

            "midi_top1_mean": float(
                np.mean(
                    midi_top1_scores
                )
            ),

            "midi_top1_std": float(
                np.std(
                    midi_top1_scores
                )
            ),

            "midi_top3_mean": float(
                np.mean(
                    midi_top3_scores
                )
            ),

            "midi_top3_std": float(
                np.std(
                    midi_top3_scores
                )
            ),
        },
    }

    with open(
        args.model,
        "wb",
    ) as f:

        pickle.dump(
            model_bundle,
            f,
            protocol=pickle.HIGHEST_PROTOCOL,
        )

    print(
        f"\nModel saved: {args.model}"
    )

    print(
        "\n" + "=" * 60
    )

    print(
        "Training completed"
    )

    print(
        "=" * 60
    )


if __name__ == "__main__":
    main()