#!/usr/bin/env python3
"""
predict.py - Predict the melody channel of a MIDI file using a trained model

Usage:
    python predict.py <model.pkl> <midi_file>

Example:
    python predict.py melody_model.pkl new_song.mid

Description:
    This file must be used together with the new train.py.

    New model format:
        {
            "model": RandomForestClassifier,
            "feature_names": [...],
            "feature_version": 2,
            ...
        }

    Prediction pipeline:
        MIDI
          ↓
        Same MIDI parsing as train.py
          ↓
        Same feature extraction as train.py
          ↓
        Random Forest
          ↓
        Melody probability for each channel
          ↓
        Top-1 / Top-3 ranking
"""

import os
import sys
import argparse
import pickle
import collections

import numpy as np
import mido

from train import (
    extract_channel_notes,
    extract_features_for_channel,
    get_feature_names,
    ticks_to_seconds,
    build_tempo_map,
)


def get_midi_total_ticks(mid):
    """
    Get the total tick length of a MIDI file.

    We do not use mid.length directly because:
    - mid.length is measured in seconds.
    - Our feature extraction uses ticks and the tempo map.
    """

    total_ticks = 0

    for track in mid.tracks:

        track_tick = 0

        for msg in track:
            track_tick += msg.time

        total_ticks = max(
            total_ticks,
            track_tick,
        )

    return total_ticks


def load_model(model_path):
    """
    Load the new model bundle.

    Returns:
        model_bundle
    """

    if not os.path.exists(model_path):

        raise FileNotFoundError(
            f"Model file does not exist: {model_path}"
        )

    with open(
        model_path,
        "rb",
    ) as f:

        bundle = pickle.load(f)

    # --------------------------------------------------------
    # Check whether this is the new model format.
    # --------------------------------------------------------

    if not isinstance(bundle, dict):

        raise ValueError(
            "The model file is not a valid model bundle.\n"
            "Please retrain the model using the new train.py."
        )

    required_keys = {
        "model",
        "feature_names",
        "feature_version",
    }

    missing = (
        required_keys
        - set(bundle.keys())
    )

    if missing:

        raise ValueError(
            "The model file is missing required fields: "
            f"{sorted(missing)}\n"
            "Please retrain the model using the new train.py."
        )

    if bundle["feature_version"] != 2:

        raise ValueError(
            "Model feature_version mismatch: "
            f"{bundle['feature_version']}\n"
            "This predict.py requires feature_version=2."
        )

    model = bundle["model"]

    if not hasattr(
        model,
        "predict_proba",
    ):

        raise ValueError(
            "The model does not support predict_proba()."
        )

    return bundle


def extract_features_for_midi(
    midi_path,
):
    """
    Extract features for all channels in a MIDI file
    using exactly the same process as train.py.

    Returns:
        {
            channel: feature_vector
        }

    And:
        channel_metadata
    """

    if not os.path.exists(
        midi_path
    ):

        raise FileNotFoundError(
            f"MIDI file does not exist: {midi_path}"
        )

    # --------------------------------------------------------
    # MIDI parsing
    # --------------------------------------------------------

    (
        channel_data,
        tempo_events,
        ticks_per_beat,
    ) = extract_channel_notes(
        midi_path
    )

    if not channel_data:
        return {}, {}

    # --------------------------------------------------------
    # Get total ticks
    # --------------------------------------------------------

    try:

        mid = mido.MidiFile(
            midi_path
        )

    except Exception as e:

        raise RuntimeError(
            f"Failed to read MIDI: "
            f"{midi_path}: {e}"
        )

    total_ticks = get_midi_total_ticks(
        mid
    )

    # --------------------------------------------------------
    # Feature extraction
    # --------------------------------------------------------

    features = {}
    metadata = {}

    for ch, data in channel_data.items():

        feat = extract_features_for_channel(
            data,
            tempo_events,
            ticks_per_beat,
            total_ticks,
        )

        if feat is None:
            continue

        features[ch] = feat

        metadata[ch] = {
            "program": data["program"],
            "volume": data["volume"],
            "pan": data["pan"],
            "is_drum": data["is_drum"],
            "n_notes": len(
                data["notes"]
            ),
        }

    return (
        features,
        metadata,
    )


def predict_channel(
    model_path,
    midi_path,
    top_k=3,
):
    """
    Predict the melody channel of a MIDI file.

    Returns:
        best_channel

    Also prints:
        - Melody probability for each channel
        - Top-K ranking
        - Channel metadata
    """

    print("=" * 60)
    print("MIDI Melody Channel Predictor")
    print("=" * 60)

    print(
        f"\nModel: {model_path}"
    )

    print(
        f"MIDI: {midi_path}"
    )

    # --------------------------------------------------------
    # Load model
    # --------------------------------------------------------

    print(
        "\n[1/3] Loading model..."
    )

    bundle = load_model(
        model_path
    )

    clf = bundle["model"]

    model_feature_names = (
        bundle["feature_names"]
    )

    current_feature_names = (
        get_feature_names()
    )

    # --------------------------------------------------------
    # Strict feature schema validation
    # --------------------------------------------------------

    if (
        model_feature_names
        != current_feature_names
    ):

        print(
            "\n[ERROR] Model feature schema "
            "does not match the current feature extractor."
        )

        print(
            f"Model feature count: "
            f"{len(model_feature_names)}"
        )

        print(
            f"Current feature count: "
            f"{len(current_feature_names)}"
        )

        # Find the exact differences.
        max_len = max(
            len(model_feature_names),
            len(current_feature_names),
        )

        differences = []

        for i in range(max_len):

            model_name = (
                model_feature_names[i]
                if i < len(
                    model_feature_names
                )
                else "<missing>"
            )

            current_name = (
                current_feature_names[i]
                if i < len(
                    current_feature_names
                )
                else "<missing>"
            )

            if model_name != current_name:

                differences.append(
                    (
                        i,
                        model_name,
                        current_name,
                    )
                )

        print(
            "\nFirst 20 mismatched positions:"
        )

        for (
            index,
            model_name,
            current_name,
        ) in differences[:20]:

            print(
                f"  [{index}] "
                f"model={model_name}, "
                f"current={current_name}"
            )

        raise RuntimeError(
            "\nFeature schema mismatch.\n"
            "Do not force prediction. "
            "Use the train.py/predict.py pair "
            "that corresponds to the model."
        )

    # --------------------------------------------------------
    # Extract features
    # --------------------------------------------------------

    print(
        "\n[2/3] Extracting MIDI features..."
    )

    (
        ch_features,
        metadata,
    ) = extract_features_for_midi(
        midi_path
    )

    if not ch_features:

        print(
            "Error: Could not extract valid "
            "channel features from this MIDI."
        )

        return None

    print(
        f"Detected {len(ch_features)} channels."
    )

    # --------------------------------------------------------
    # Prediction
    # --------------------------------------------------------

    channels = []
    probabilities = []

    for ch in sorted(
        ch_features.keys()
    ):

        feat = ch_features[ch]

        # ----------------------------------------------------
        # Validate feature dimension again.
        # ----------------------------------------------------

        if len(feat) != len(
            model_feature_names
        ):

            raise RuntimeError(
                f"Invalid feature dimension for "
                f"channel {ch}: "
                f"{len(feat)} != "
                f"{len(model_feature_names)}"
            )

        # Get the Random Forest melody probability.
        prob = clf.predict_proba(
            [feat]
        )[0][1]

        channels.append(ch)

        probabilities.append(
            float(prob)
        )

    # --------------------------------------------------------
    # Sort
    # --------------------------------------------------------

    ranking = sorted(
        zip(
            channels,
            probabilities,
        ),
        key=lambda x: x[1],
        reverse=True,
    )

    if not ranking:

        print(
            "Error: No channels available for prediction."
        )

        return None

    # --------------------------------------------------------
    # Output ranking
    # --------------------------------------------------------

    print(
        "\nMelody Probability by Channel:"
    )

    print(
        "-" * 60
    )

    for rank, (
        ch,
        prob,
    ) in enumerate(
        ranking,
        start=1,
    ):

        info = metadata.get(
            ch,
            {},
        )

        program = info.get(
            "program",
            -1,
        )

        n_notes = info.get(
            "n_notes",
            0,
        )

        is_drum = info.get(
            "is_drum",
            False,
        )

        drum_text = (
            " [DRUM]"
            if is_drum
            else ""
        )

        print(
            f"  #{rank:<2d} "
            f"Channel {ch:<2d}  "
            f"prob={prob:.4f}  "
            f"program={program:<3d}  "
            f"notes={n_notes:<6d}"
            f"{drum_text}"
        )

    # --------------------------------------------------------
    # Top-1
    # --------------------------------------------------------

    best_channel = ranking[0][0]
    best_prob = ranking[0][1]

    # --------------------------------------------------------
    # Top-K
    # --------------------------------------------------------

    top_k = max(
        1,
        min(
            top_k,
            len(ranking),
        ),
    )

    top_channels = [
        ch
        for ch, _ in ranking[:top_k]
    ]

    print(
        "\n" + "=" * 60
    )

    print(
        f"Predicted Melody Channel: "
        f"{best_channel}"
    )

    print(
        f"Melody Probability: "
        f"{best_prob:.4f}"
    )

    print(
        f"Top-{top_k}: "
        f"{top_channels}"
    )

    print(
        "=" * 60
    )

    return best_channel


def main():

    parser = argparse.ArgumentParser(
        description=(
            "Predict the melody channel of a MIDI "
            "file using a trained model"
        )
    )

    parser.add_argument(
        "model",
        help=(
            "Model file (.pkl) generated by "
            "the new train.py"
        ),
    )

    parser.add_argument(
        "midi_file",
        help="MIDI file to predict",
    )

    parser.add_argument(
        "--top-k",
        type=int,
        default=3,
        help=(
            "Number of top candidates to display, "
            "default: 3"
        ),
    )

    args = parser.parse_args()

    try:

        predict_channel(
            args.model,
            args.midi_file,
            top_k=args.top_k,
        )

    except KeyboardInterrupt:

        print(
            "\nInterrupted by user."
        )

        sys.exit(130)

    except Exception as e:

        print(
            f"\n[ERROR] {e}",
            file=sys.stderr,
        )

        sys.exit(1)


if __name__ == "__main__":
    main()