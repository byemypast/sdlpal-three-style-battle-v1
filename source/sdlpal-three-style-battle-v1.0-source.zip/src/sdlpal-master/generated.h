#ifndef SDLPAL_GENERATED_H
#define SDLPAL_GENERATED_H

#define PAL_GIT_REVISION "dsh-build-master"

#endif
