#include "main.h"
#include "battle.h"
#include "battlestatus.h"

static WORD s_rgwEnemyTurns[MAX_ENEMIES_IN_TEAM];
static WORD s_rgwOrigAttack[MAX_ENEMIES_IN_TEAM];
static WORD s_rgwOrigDefense[MAX_ENEMIES_IN_TEAM];
static WORD s_rgwOrigDexterity[MAX_ENEMIES_IN_TEAM];
static WORD s_rgwOrigMagicStrength[MAX_ENEMIES_IN_TEAM];
static WORD s_rgwOrigFleeRate[MAX_ENEMIES_IN_TEAM];

static WORD
BTLSTAT_Scale80(
   WORD wValue
)
{
   return (WORD)((DWORD)wValue * 80 / 100);
}

static VOID
BTLSTAT_RestoreEnemy(
   WORD wEnemyIndex
)
{
   if (wEnemyIndex >= MAX_ENEMIES_IN_TEAM)
   {
      return;
   }

   g_Battle.rgEnemy[wEnemyIndex].e.wAttackStrength = s_rgwOrigAttack[wEnemyIndex];
   g_Battle.rgEnemy[wEnemyIndex].e.wDefense = s_rgwOrigDefense[wEnemyIndex];
   g_Battle.rgEnemy[wEnemyIndex].e.wDexterity = s_rgwOrigDexterity[wEnemyIndex];
   g_Battle.rgEnemy[wEnemyIndex].e.wMagicStrength = s_rgwOrigMagicStrength[wEnemyIndex];
   g_Battle.rgEnemy[wEnemyIndex].e.wFleeRate = s_rgwOrigFleeRate[wEnemyIndex];
   s_rgwEnemyTurns[wEnemyIndex] = 0;
}

VOID
BTLSTAT_Reset(
   VOID
)
{
   int i;

   for (i = 0; i < MAX_ENEMIES_IN_TEAM; i++)
   {
      if (s_rgwEnemyTurns[i] > 0)
      {
         BTLSTAT_RestoreEnemy((WORD)i);
      }
      s_rgwEnemyTurns[i] = 0;
   }
}

VOID
BTLSTAT_ApplyEnemyDebuff(
   WORD wEnemyIndex,
   WORD wTurns
)
{
   BATTLEENEMY *lpEnemy;

   if (wEnemyIndex >= MAX_ENEMIES_IN_TEAM || wTurns == 0)
   {
      return;
   }

   lpEnemy = &g_Battle.rgEnemy[wEnemyIndex];
   if (lpEnemy->wObjectID == 0 || lpEnemy->e.wHealth == 0)
   {
      return;
   }

   if (s_rgwEnemyTurns[wEnemyIndex] == 0)
   {
      s_rgwOrigAttack[wEnemyIndex] = lpEnemy->e.wAttackStrength;
      s_rgwOrigDefense[wEnemyIndex] = lpEnemy->e.wDefense;
      s_rgwOrigDexterity[wEnemyIndex] = lpEnemy->e.wDexterity;
      s_rgwOrigMagicStrength[wEnemyIndex] = lpEnemy->e.wMagicStrength;
      s_rgwOrigFleeRate[wEnemyIndex] = lpEnemy->e.wFleeRate;

      lpEnemy->e.wAttackStrength = BTLSTAT_Scale80(lpEnemy->e.wAttackStrength);
      lpEnemy->e.wDefense = BTLSTAT_Scale80(lpEnemy->e.wDefense);
      lpEnemy->e.wDexterity = BTLSTAT_Scale80(lpEnemy->e.wDexterity);
      lpEnemy->e.wMagicStrength = BTLSTAT_Scale80(lpEnemy->e.wMagicStrength);
      lpEnemy->e.wFleeRate = BTLSTAT_Scale80(lpEnemy->e.wFleeRate);
   }

   s_rgwEnemyTurns[wEnemyIndex] = wTurns;
}

VOID
BTLSTAT_OnEnemyTurn(
   WORD wEnemyIndex
)
{
   if (wEnemyIndex >= MAX_ENEMIES_IN_TEAM || s_rgwEnemyTurns[wEnemyIndex] == 0)
   {
      return;
   }

   if (--s_rgwEnemyTurns[wEnemyIndex] == 0)
   {
      BTLSTAT_RestoreEnemy(wEnemyIndex);
   }
}

WORD
BTLSTAT_GetEnemyDebuffTurns(
   WORD wEnemyIndex
)
{
   if (wEnemyIndex >= MAX_ENEMIES_IN_TEAM)
   {
      return 0;
   }
   return s_rgwEnemyTurns[wEnemyIndex];
}

BOOL
BTLSTAT_HasAnyEnemyDebuff(
   VOID
)
{
   int i;

   for (i = 0; i <= g_Battle.wMaxEnemyIndex; i++)
   {
      if (s_rgwEnemyTurns[i] > 0)
      {
         return TRUE;
      }
   }
   return FALSE;
}

VOID
BTLSTAT_DrawEnemyBadges(
   VOID
)
{
   int i;

   for (i = 0; i <= g_Battle.wMaxEnemyIndex; i++)
   {
      BATTLEENEMY *lpEnemy = &g_Battle.rgEnemy[i];
      int x, y;
      static const WCHAR szBadges[] = L"五維↓";

      if (s_rgwEnemyTurns[i] == 0 || lpEnemy->wObjectID == 0 || lpEnemy->e.wHealth == 0)
      {
         continue;
      }

      x = PAL_X(lpEnemy->pos) + 16 - PAL_TextWidth(szBadges) / 2;
      y = PAL_Y(lpEnemy->pos) - 14;
      if (x < 2) x = 2;
      if (x + PAL_TextWidth(szBadges) > 318)
      {
         x = 318 - PAL_TextWidth(szBadges);
      }
      if (y < 2) y = 2;

      PAL_DrawText(szBadges, PAL_XY(x + 1, y + 1), 0x00, TRUE, FALSE, FALSE);
      PAL_DrawText(szBadges, PAL_XY(x, y), 0x5F, TRUE, FALSE, FALSE);
   }
}

VOID
BTLSTAT_DrawPlayerBadges(
   WORD wRole,
   int iX,
   int iY
)
{
   WCHAR szBadges[64] = L"";

   if (gpGlobals->g.PlayerRoles.rgwHP[wRole] == 0)
   {
      return;
   }

   if (gpGlobals->rgPlayerStatus[wRole][kStatusBravery] > 0)
   {
      wcsncat(szBadges, L"武↑", 5);
   }
   if (gpGlobals->rgPlayerStatus[wRole][kStatusProtect] > 0)
   {
      wcsncat(szBadges, L"防↑", 5);
   }
   if (gpGlobals->rgPlayerStatus[wRole][kStatusHaste] > 0)
   {
      wcsncat(szBadges, L"速↑", 5);
   }
   else if (gpGlobals->rgPlayerStatus[wRole][kStatusSlow] > 0)
   {
      wcsncat(szBadges, L"速↓", 5);
   }
   if (gpGlobals->rgPlayerStatus[wRole][kStatusConfused] > 0)
   {
      wcsncat(szBadges, L"運↓", 5);
   }
   if (gpGlobals->rgPlayerStatus[wRole][kStatusSilence] > 0)
   {
      wcsncat(szBadges, L"靈↓", 5);
   }

   if (szBadges[0] != 0)
   {
      PAL_DrawText(szBadges, PAL_XY(iX + 1, iY + 1), 0x00, TRUE, FALSE, FALSE);
      PAL_DrawText(szBadges, PAL_XY(iX, iY), 0x0F, TRUE, FALSE, FALSE);
   }
}
