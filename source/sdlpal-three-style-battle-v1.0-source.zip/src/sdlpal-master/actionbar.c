/*
 * SDLPAL Action Bar (PAL3-style shared A/B gauge) - compact layout
 *
 * Design goals (P3 UI revision):
 *   - no full-width black panel; only a 2px shared rail and tiny markers
 *   - party above the rail, enemies below it, all on the same 0..100 track
 *   - party faces are 12x12 nearest-neighbour downscales of the original
 *     32x32 UI face sprites (cached in memory; no new art assets)
 *   - enemy markers are 4x4 dots (dark 1px outline for readability)
 *   - total height: AB_HEIGHT (21px, ~10% of a 200px screen)
 *
 * The bar is drawn directly on gpScreen from PAL_BattleUIUpdate().
 */

#include "main.h"
#include "palcfg.h"
#include "actionbar.h"

#define AB_COLOR_BG        0x00
#define AB_COLOR_RED       0x1B   /* red ramp (200,88,76) */
#define AB_COLOR_BLUE      0x5B   /* blue ramp (96,96,204) */
#define AB_COLOR_LINE      0xBD   /* same as original time meter border */
#define AB_COLOR_ENEMY     0x1A
#define AB_COLOR_DARK      0x00

static BOOL s_fMenuPaused = FALSE;

static VOID
AB_DrawRect(
   int x,
   int y,
   int w,
   int h,
   BYTE color
);

/* P1/P2 per-fighter chanting state. */
static BOOL s_fChantPlayer[MAX_PLAYERS_IN_PARTY];
static BOOL s_fChantEnemy[MAX_ENEMIES_IN_TEAM];
static WORD s_wChantMagicPlayer[MAX_PLAYERS_IN_PARTY];
static WORD s_wChantMagicEnemy[MAX_ENEMIES_IN_TEAM];

/*
 * Small 12x12 party faces, sampled from the original 32x32 face sprites.
 * Values are palette indices; index 0 is treated as transparent.
 */
static BYTE s_rgFaceSmall[MAX_PLAYER_ROLES][AB_FACE_W * AB_FACE_H];
static BOOL s_fFaceReady[MAX_PLAYER_ROLES];
static BOOL s_fFacesAttempted = FALSE;

static const BYTE s_rgbRoleFallback[MAX_PLAYER_ROLES] =
{
   0x1B, 0x5B, 0x3C, 0x5D, 0x2A, 0x3F
};

/*
 * Distinct per-enemy colours (palette indices). The same colours are used for
 * the tiny marker next to the enemy sprite on the battlefield, so the player
 * can match "which dot is which enemy" at a glance.
 */
#define AB_ENEMY_COLOR_COUNT 5
#define AB_COLOR_TARGET      0x3F   /* bright white/yellow for target blink */

static const BYTE s_rgbEnemyColor[AB_ENEMY_COLOR_COUNT] =
{
   0x1B,  /* red */
   0x2A,  /* orange */
   0x8E,  /* green/cyan */
   0x6C,  /* purple */
   0x5B   /* blue */
};

static BYTE
AB_GetEnemyColor(
   WORD wEnemyIndex
)
{
   return s_rgbEnemyColor[wEnemyIndex % AB_ENEMY_COLOR_COUNT];
}

static BOOL
AB_IsEnemyTargeted(
   WORD wEnemyIndex
)
{
   if (g_Battle.UI.state == kBattleUISelectTargetEnemyAll)
   {
      return TRUE;
   }

   if (g_Battle.UI.state == kBattleUISelectTargetEnemy)
   {
      return ((SHORT)wEnemyIndex == g_Battle.UI.iSelectedIndex) ? TRUE : FALSE;
   }

   return FALSE;
}

static BOOL
AB_TargetBlinkPhase(
   VOID
)
{
   return ((SDL_GetTicks() / 250) & 1) ? TRUE : FALSE;
}

INT
AB_GetActionSplit(
   VOID
)
/*++
  Purpose:
    Return the A-segment end percentage (configurable, default 80).

  Return value:
    20..95
--*/
{
   INT i = gConfig.iActionSplit;

   if (i < 20 || i > 95)
   {
      i = 80;
   }

   return i;
}

BOOL
AB_IsEnabled(
   VOID
)
{
   return gConfig.fActionBarEnabled ? TRUE : FALSE;
}

BOOL
AB_IsWaitMode(
   VOID
)
{
   return gConfig.fBattleWaitMode ? TRUE : FALSE;
}

VOID
AB_SetMenuPaused(
   BOOL fPaused
)
{
   s_fMenuPaused = fPaused ? TRUE : FALSE;
   g_Battle.fWaitModePause = s_fMenuPaused;
}

BOOL
AB_IsMenuPaused(
   VOID
)
{
   return s_fMenuPaused;
}

VOID
AB_Reset(
   VOID
)
{
   int i;

   s_fMenuPaused = FALSE;
   g_Battle.fWaitModePause = FALSE;

   for (i = 0; i < MAX_PLAYERS_IN_PARTY; i++)
   {
      s_fChantPlayer[i] = FALSE;
      s_wChantMagicPlayer[i] = 0;
   }

   for (i = 0; i < MAX_ENEMIES_IN_TEAM; i++)
   {
      s_fChantEnemy[i] = FALSE;
      s_wChantMagicEnemy[i] = 0;
   }
}

/*
 * Build the 12x12 face cache from the original 32x32 UI face sprites.
 * Nearest-neighbour sampling keeps the palette indices intact.
 */
static VOID
AB_BuildSmallFaces(
   VOID
)
{
   int          iRole, x, y;
   SDL_Rect     rcSrc;
   SDL_Surface *lpSrc;
   LPCBITMAPRLE lpFrame;
   BYTE        *pSrcPixels;
   int          iSrcPitch;
   int          iNonZero;

   if (s_fFacesAttempted || gpScreen == NULL || gpSpriteUI == NULL ||
      SDL_GetPixelFormatDetails(gpScreen->format) == NULL ||
      SDL_GetPixelFormatDetails(gpScreen->format)->bits_per_pixel != 8)
   {
      return;
   }

   rcSrc.x = 0;
   rcSrc.y = 0;
   rcSrc.w = 32;
   rcSrc.h = 32;

   for (iRole = 0; iRole < MAX_PLAYER_ROLES; iRole++)
   {
      lpFrame = PAL_SpriteGetFrame(gpSpriteUI, SPRITENUM_PLAYERFACE_FIRST + iRole);
      if (lpFrame == NULL)
      {
         continue;
      }

      lpSrc = VIDEO_CreateCompatibleSizedSurface(gpScreen, &rcSrc);
      if (lpSrc == NULL)
      {
         continue;
      }

      SDL_FillRect(lpSrc, NULL, AB_COLOR_BG);
      PAL_RLEBlitToSurface(lpFrame, lpSrc, PAL_XY(0, 0));

      pSrcPixels = (BYTE *)lpSrc->pixels;
      iSrcPitch = lpSrc->pitch;
      iNonZero = 0;

      for (y = 0; y < AB_FACE_H; y++)
      {
         for (x = 0; x < AB_FACE_W; x++)
         {
            int sx = x * 32 / AB_FACE_W;
            int sy = y * 32 / AB_FACE_H;
            BYTE c = pSrcPixels[sy * iSrcPitch + sx];

            s_rgFaceSmall[iRole][y * AB_FACE_W + x] = c;
            if (c != 0)
            {
               iNonZero++;
            }
         }
      }

      SDL_DestroySurface(lpSrc);
      s_fFaceReady[iRole] = (iNonZero > 8) ? TRUE : FALSE;
   }

   s_fFacesAttempted = TRUE;
}

static VOID
AB_BlitSmallFace(
   int   x,
   int   y,
   WORD  wRole
)
{
   int xx, yy;

   if (x < 0 || y < 0 || x + AB_FACE_W > 320 || y + AB_FACE_H > 200)
   {
      return;
   }

   if (wRole < MAX_PLAYER_ROLES && s_fFaceReady[wRole] &&
      SDL_GetPixelFormatDetails(gpScreen->format) != NULL &&
      SDL_GetPixelFormatDetails(gpScreen->format)->bits_per_pixel == 8)
   {
      BYTE *pDst = (BYTE *)gpScreen->pixels;

      for (yy = 0; yy < AB_FACE_H; yy++)
      {
         BYTE *pRow = pDst + (y + yy) * gpScreen->pitch + x;

         for (xx = 0; xx < AB_FACE_W; xx++)
         {
            BYTE c = s_rgFaceSmall[wRole][yy * AB_FACE_W + xx];

            if (c != 0)
            {
               pRow[xx] = c;
            }
         }
      }
   }
   else
   {
      /* Fallback: a small colour square (still readable without a panel). */
      AB_DrawRect(x + 3, y + 3, 6, 6,
         (wRole < MAX_PLAYER_ROLES) ? s_rgbRoleFallback[wRole] : AB_COLOR_LINE);
   }
}

VOID
AB_OnBattleStart(
   VOID
)
{
   AB_Reset();
   AB_BuildSmallFaces();
}

BOOL
AB_IsChanting(
   WORD wIndex,
   BOOL fEnemy
)
{
   if (fEnemy)
   {
      return (wIndex < MAX_ENEMIES_IN_TEAM) ? s_fChantEnemy[wIndex] : FALSE;
   }

   return (wIndex < MAX_PLAYERS_IN_PARTY) ? s_fChantPlayer[wIndex] : FALSE;
}

VOID
AB_OnChantStart(
   WORD wIndex,
   BOOL fEnemy,
   WORD wMagic
)
{
   if (fEnemy)
   {
      if (wIndex < MAX_ENEMIES_IN_TEAM)
      {
         s_fChantEnemy[wIndex] = TRUE;
         s_wChantMagicEnemy[wIndex] = wMagic;
      }
   }
   else if (wIndex < MAX_PLAYERS_IN_PARTY)
   {
      s_fChantPlayer[wIndex] = TRUE;
      s_wChantMagicPlayer[wIndex] = wMagic;
   }
}

VOID
AB_OnChantInterrupt(
   WORD wIndex,
   BOOL fEnemy
)
{
   if (fEnemy)
   {
      if (wIndex < MAX_ENEMIES_IN_TEAM)
      {
         s_fChantEnemy[wIndex] = FALSE;
         s_wChantMagicEnemy[wIndex] = 0;
      }
   }
   else if (wIndex < MAX_PLAYERS_IN_PARTY)
   {
      s_fChantPlayer[wIndex] = FALSE;
      s_wChantMagicPlayer[wIndex] = 0;
   }
}

FLOAT
AB_GetChantSpeedDivisor(
   VOID
)
/*++
  Purpose:
    B-segment charging speed divisor. Default 2 => B fills at 1/2 of A speed.

  Return value:
    1.0 .. 4.0
--*/
{
   INT i = gConfig.iChantSpeedDiv;

   if (i < 1 || i > 4)
   {
      i = 2;
   }

   return (FLOAT)i;
}

static VOID
AB_DrawRect(
   int x,
   int y,
   int w,
   int h,
   BYTE color
)
{
   SDL_Rect rc;

   if (w <= 0 || h <= 0)
   {
      return;
   }

   rc.x = (Sint16)x;
   rc.y = (Sint16)y;
   rc.w = (Uint16)w;
   rc.h = (Uint16)h;
   SDL_FillRect(gpScreen, &rc, color);
}

/*
 * Draw a small colour dot next to each enemy sprite on the battlefield.
 * This is the in-world counterpart of the coloured markers in the action bar.
 */
static VOID
AB_DrawBattlefieldTags(
   VOID
)
{
   int      i;
   BOOL     fBlink = AB_TargetBlinkPhase();
   LPCBITMAPRLE lpFrame;
   int      w, h;
   int      ex, ey, left, top, dx, dy;

   if (gpScreen == NULL)
   {
      return;
   }

   for (i = 0; i <= g_Battle.wMaxEnemyIndex; i++)
   {
      if (g_Battle.rgEnemy[i].wObjectID == 0 || g_Battle.rgEnemy[i].lpSprite == NULL)
      {
         continue;
      }

      lpFrame = PAL_SpriteGetFrame(g_Battle.rgEnemy[i].lpSprite,
         g_Battle.rgEnemy[i].wCurrentFrame);
      if (lpFrame == NULL)
      {
         continue;
      }

      w = PAL_RLEGetWidth(lpFrame);
      h = PAL_RLEGetHeight(lpFrame);

      ex = PAL_X(g_Battle.rgEnemy[i].pos);
      ey = PAL_Y(g_Battle.rgEnemy[i].pos);
      left = ex - w / 2;
      top = ey - h;

      /* Prefer the left side of the sprite; fall back to the right side. */
      dx = left - 6;
      if (dx < 2)
      {
         dx = ex + w / 2 + 2;
      }
      dy = top + h / 3;

      if (dx < 2) dx = 2;
      if (dx > 314) dx = 314;
      if (dy < AB_HEIGHT + 3) dy = AB_HEIGHT + 3;
      if (dy > 130) dy = 130;

      AB_DrawRect(dx - 1, dy - 1, 6, 6, AB_COLOR_DARK);
      AB_DrawRect(dx, dy, 4, 4, AB_GetEnemyColor((WORD)i));

      if (g_Battle.rgEnemy[i].fChanting)
      {
         AB_DrawRect(dx - 1, dy - 1, 6, 1, AB_COLOR_BLUE);
      }

      if (AB_IsEnemyTargeted((WORD)i) && fBlink)
      {
         AB_DrawRect(dx - 2, dy - 2, 8, 1, AB_COLOR_TARGET);
         AB_DrawRect(dx - 2, dy + 5, 8, 1, AB_COLOR_TARGET);
         AB_DrawRect(dx - 2, dy - 1, 1, 6, AB_COLOR_TARGET);
         AB_DrawRect(dx + 5, dy - 1, 1, 6, AB_COLOR_TARGET);
      }
   }
}

VOID
AB_Draw(
   VOID
)
/*++
  Purpose:
    Draw the compact shared A/B action bar.
--*/
{
   int      i;
   int      iSplit;
   int      iSplitX;
   int      iTrackRight;
   FLOAT    flMeter;
   int      x, y;
   WORD     wRole;
   BOOL     fBlink;

   if (!AB_IsEnabled() || gpScreen == NULL || gpSpriteUI == NULL)
   {
      return;
   }

   AB_BuildSmallFaces();

   iSplit = AB_GetActionSplit();
   iTrackRight = AB_TRACK_X + AB_TRACK_W;
   iSplitX = AB_TRACK_X + (AB_TRACK_W * iSplit) / 100;
   fBlink = ((SDL_GetTicks() / 250) & 1) ? TRUE : FALSE;

   /*
    * Shared rail: red A segment, blue B segment, tiny split notch.
    * No background panel is drawn; the scene stays visible.
    */
   AB_DrawRect(AB_TRACK_X, AB_TRACK_Y, iSplitX - AB_TRACK_X, 2, AB_COLOR_RED);
   AB_DrawRect(iSplitX, AB_TRACK_Y, iTrackRight - iSplitX, 2, AB_COLOR_BLUE);
   AB_DrawRect(iSplitX, AB_TRACK_Y - 1, 1, 4, AB_COLOR_LINE);

   /*
    * Party: 12x12 downscaled faces above the rail.
    *
    * Faces with nearly equal charge would otherwise overlap completely (common
    * in Wait mode). Collect, sort by x and push overlapping faces to the right
    * so every ready/charging member remains visible. Positions stay visually
    * close to the true meter value.
    */
   {
      struct
      {
         int x;
         int i;
      } rgPos[MAX_PLAYERS_IN_PARTY];
      int iCount = 0;

      for (i = 0; i <= gpGlobals->wMaxPartyMemberIndex; i++)
      {
         if (gpGlobals->rgParty[i].wPlayerRole >= MAX_PLAYER_ROLES)
         {
            continue;
         }

         BOOL fInB = FALSE;

         flMeter = g_Battle.rgPlayer[i].flTimeMeter;

         if (g_Battle.rgPlayer[i].fChanting &&
            g_Battle.rgPlayer[i].state == kFighterAct &&
            g_Battle.rgPlayer[i].flChantTotal > 0.0f)
         {
            FLOAT flProgress = 1.0f - g_Battle.rgPlayer[i].action.flRemainingTime /
               g_Battle.rgPlayer[i].flChantTotal;

            if (flProgress < 0.0f) flProgress = 0.0f;
            if (flProgress > 1.0f) flProgress = 1.0f;

            flMeter = (FLOAT)iSplit + flProgress * (100.0f - (FLOAT)iSplit);
            fInB = TRUE;
         }
         else
         {
            /*
             * A full A-gauge may overshoot the split by one frame of charging.
             * Non-chanting fighters must never be drawn inside the blue B
             * segment; clamp them to the A endpoint.
             */
            if (flMeter > (FLOAT)iSplit)
            {
               flMeter = (FLOAT)iSplit;
            }
         }

         if (flMeter < 0.0f) flMeter = 0.0f;
         if (flMeter > 100.0f) flMeter = 100.0f;

         if (fInB)
         {
            FLOAT flProgress = (flMeter - (FLOAT)iSplit) / (100.0f - (FLOAT)iSplit);
            int   iSpan = iTrackRight - iSplitX;

            rgPos[iCount].x = iSplitX - AB_FACE_W + (int)(iSpan * flProgress);
         }
         else
         {
            int iSpan = iSplitX - AB_TRACK_X - AB_FACE_W;

            rgPos[iCount].x = AB_TRACK_X +
               (int)(iSpan * flMeter / (FLOAT)iSplit);
         }
         rgPos[iCount].i = i;
         iCount++;
      }

      /* insertion sort by x */
      for (i = 1; i < iCount; i++)
      {
         int j = i;
         while (j > 0 && rgPos[j - 1].x > rgPos[j].x)
         {
            int t = rgPos[j - 1].x;
            int ti = rgPos[j - 1].i;
            rgPos[j - 1].x = rgPos[j].x;
            rgPos[j - 1].i = rgPos[j].i;
            rgPos[j].x = t;
            rgPos[j].i = ti;
            j--;
         }
      }

      /* spread overlapping faces, then keep the whole cluster on screen */
      for (i = 1; i < iCount; i++)
      {
         if (rgPos[i].x < rgPos[i - 1].x + AB_FACE_W + 1)
         {
            rgPos[i].x = rgPos[i - 1].x + AB_FACE_W + 1;
         }
      }

      if (iCount > 0)
      {
         int iOverflow = (rgPos[iCount - 1].x + AB_FACE_W) -
            (AB_TRACK_X + AB_TRACK_W);

         if (iOverflow > 0)
         {
            for (i = 0; i < iCount; i++)
            {
               rgPos[i].x -= iOverflow;
            }
         }

         if (rgPos[0].x < AB_TRACK_X)
         {
            int iShift = AB_TRACK_X - rgPos[0].x;
            for (i = 0; i < iCount; i++)
            {
               rgPos[i].x += iShift;
            }
         }
      }

      for (i = 0; i < iCount; i++)
      {
         int iPlayer = rgPos[i].i;

         wRole = gpGlobals->rgParty[iPlayer].wPlayerRole;
         x = rgPos[i].x;
         y = AB_FACE_Y;
         flMeter = g_Battle.rgPlayer[iPlayer].flTimeMeter;

         AB_BlitSmallFace(x, y, wRole);

         /* Role colour tick: helps identify overlapping faces. */
         AB_DrawRect(x, AB_FACE_H - 1, AB_FACE_W, 1,
            (wRole < MAX_PLAYER_ROLES) ? s_rgbRoleFallback[wRole] : AB_COLOR_LINE);

         /* Thin status line between face and rail. */
         if (g_Battle.rgPlayer[iPlayer].fChanting)
         {
            AB_DrawRect(x, AB_FACE_H, AB_FACE_W, 1, AB_COLOR_BLUE);
         }
         else if (g_Battle.rgPlayer[iPlayer].state == kFighterCom)
         {
            AB_DrawRect(x, AB_FACE_H, AB_FACE_W, 1, AB_COLOR_RED);
         }

         /* Wait-mode freeze: blink a red outline around the ready player. */
         if (fBlink && AB_IsWaitMode() && g_Battle.fWaitModePause &&
            g_Battle.rgPlayer[iPlayer].state == kFighterCom)
         {
            AB_DrawRect(x - 1, y - 1, AB_FACE_W + 2, 1, AB_COLOR_RED);
            AB_DrawRect(x - 1, y + AB_FACE_H, AB_FACE_W + 2, 1, AB_COLOR_RED);
            AB_DrawRect(x - 1, y, 1, AB_FACE_H, AB_COLOR_RED);
            AB_DrawRect(x + AB_FACE_W, y, 1, AB_FACE_H, AB_COLOR_RED);
         }

         /* Haste/slow: tiny tick left of the face. */
         if (gpGlobals->rgPlayerStatus[wRole][kStatusHaste] != 0)
         {
            AB_DrawRect(x - 2, y + 3, 2, 6, 0x2A);
         }
         else if (gpGlobals->rgPlayerStatus[wRole][kStatusSlow] != 0)
         {
            AB_DrawRect(x - 2, y + 3, 2, 6, AB_COLOR_BLUE);
         }
      }
   }

   /*
    * Enemies: 4x4 markers below the rail, on the same 0..100 track.
    * Spread overlapping markers horizontally so 3-5 enemies stay visible.
    */
   {
      struct
      {
         int x;
         int i;
      } rgPos[MAX_ENEMIES_IN_TEAM];
      int iCount = 0;

      for (i = 0; i <= g_Battle.wMaxEnemyIndex; i++)
      {
         if (g_Battle.rgEnemy[i].wObjectID == 0)
         {
            continue;
         }

         BOOL fInB = FALSE;

         flMeter = g_Battle.rgEnemy[i].flTimeMeter;

         if (g_Battle.rgEnemy[i].fChanting &&
            g_Battle.rgEnemy[i].flChantTotal > 0.0f)
         {
            FLOAT flProgress = 1.0f - g_Battle.rgEnemy[i].flChantRemaining /
               g_Battle.rgEnemy[i].flChantTotal;

            if (flProgress < 0.0f) flProgress = 0.0f;
            if (flProgress > 1.0f) flProgress = 1.0f;

            flMeter = (FLOAT)iSplit + flProgress * (100.0f - (FLOAT)iSplit);
            fInB = TRUE;
         }
         else
         {
            /* Physical action / no chant: stop at the A endpoint. */
            if (flMeter > (FLOAT)iSplit)
            {
               flMeter = (FLOAT)iSplit;
            }
         }

         if (flMeter < 0.0f) flMeter = 0.0f;
         if (flMeter > 100.0f) flMeter = 100.0f;

         if (fInB)
         {
            FLOAT flProgress = (flMeter - (FLOAT)iSplit) / (100.0f - (FLOAT)iSplit);
            int   iSpan = iTrackRight - iSplitX;

            rgPos[iCount].x = iSplitX - AB_ENEMY_SIZE + (int)(iSpan * flProgress);
         }
         else
         {
            int iSpan = iSplitX - AB_TRACK_X - AB_ENEMY_SIZE;

            rgPos[iCount].x = AB_TRACK_X +
               (int)(iSpan * flMeter / (FLOAT)iSplit);
         }
         rgPos[iCount].i = i;
         iCount++;
      }

      for (i = 1; i < iCount; i++)
      {
         int j = i;
         while (j > 0 && rgPos[j - 1].x > rgPos[j].x)
         {
            int t = rgPos[j - 1].x;
            int ti = rgPos[j - 1].i;
            rgPos[j - 1].x = rgPos[j].x;
            rgPos[j - 1].i = rgPos[j].i;
            rgPos[j].x = t;
            rgPos[j].i = ti;
            j--;
         }
      }

      for (i = 1; i < iCount; i++)
      {
         if (rgPos[i].x < rgPos[i - 1].x + AB_ENEMY_SIZE + 2)
         {
            rgPos[i].x = rgPos[i - 1].x + AB_ENEMY_SIZE + 2;
         }
      }

      if (iCount > 0)
      {
         int iOverflow = (rgPos[iCount - 1].x + AB_ENEMY_SIZE) -
            (AB_TRACK_X + AB_TRACK_W);

         if (iOverflow > 0)
         {
            for (i = 0; i < iCount; i++)
            {
               rgPos[i].x -= iOverflow;
            }
         }

         if (rgPos[0].x < AB_TRACK_X)
         {
            int iShift = AB_TRACK_X - rgPos[0].x;
            for (i = 0; i < iCount; i++)
            {
               rgPos[i].x += iShift;
            }
         }
      }

      for (i = 0; i < iCount; i++)
      {
         int iEnemy = rgPos[i].i;

         x = rgPos[i].x;
         y = AB_ENEMY_Y;

         BOOL fTargeted = AB_IsEnemyTargeted((WORD)iEnemy);
         BOOL fBlink = AB_TargetBlinkPhase();
         BYTE color = AB_GetEnemyColor((WORD)iEnemy);

         /* 1px dark outline keeps the tiny marker visible on any battlefield. */
         AB_DrawRect(x - 1, y - 1, AB_ENEMY_SIZE + 2, AB_ENEMY_SIZE + 2, AB_COLOR_DARK);
         AB_DrawRect(x, y, AB_ENEMY_SIZE, AB_ENEMY_SIZE, color);

         /* Chanting is shown by a blue top border, not by replacing the colour. */
         if (g_Battle.rgEnemy[iEnemy].fChanting)
         {
            AB_DrawRect(x - 1, y - 1, AB_ENEMY_SIZE + 2, 1, AB_COLOR_BLUE);
         }

         /* Selected enemy blinks a bright outline in the action bar. */
         if (fTargeted && fBlink)
         {
            AB_DrawRect(x - 2, y - 2, AB_ENEMY_SIZE + 4, 1, AB_COLOR_TARGET);
            AB_DrawRect(x - 2, y + AB_ENEMY_SIZE + 1, AB_ENEMY_SIZE + 4, 1, AB_COLOR_TARGET);
            AB_DrawRect(x - 2, y - 1, 1, AB_ENEMY_SIZE + 2, AB_COLOR_TARGET);
            AB_DrawRect(x + AB_ENEMY_SIZE + 1, y - 1, 1, AB_ENEMY_SIZE + 2, AB_COLOR_TARGET);
         }
      }
   }
   AB_DrawBattlefieldTags();
}
