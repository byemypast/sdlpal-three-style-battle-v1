/* -*- mode: c; tab-width: 4; c-basic-offset: 4; c-file-style: "linux" -*- */
//
// Copyright (c) 2009-2011, Wei Mingzhi <whistler_wmz@users.sf.net>.
// Copyright (c) 2011-2026, SDLPAL development team.
// All rights reserved.
//
// This file is part of SDLPAL.
//
// SDLPAL is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License, version 3
// as published by the Free Software Foundation.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.
//

#include "main.h"
#include "magicprof.h"
#include "artifacts.h"
#include "customspell.h"

static struct MAGICITEM
{
   WORD         wMagic;
   WORD         wMP;
   BOOL         fEnabled;
} rgMagicItem[MAX_PLAYER_MAGICS];

static int     g_iNumMagic = 0;
static int     g_iCurrentItem = 0;
static WORD    g_wPlayerMP = 0;
static WORD    g_wMagicRole = 0;

/*
 * v0.6 magic categories.  The object-id mapping mirrors
 * design/magic-categories.csv; edit both together.
 */
enum
{
   kMagicCategoryClassic   = -1,
   kMagicCategorySupport   = 0,
   kMagicCategoryPhysical  = 1,
   kMagicCategoryElemental = 2,
   kMagicCategoryPoison    = 3,
   kMagicCategoryOther     = 4,
};

static struct MAGICITEM rgMagicItemAll[MAX_PLAYER_MAGICS];
static int     g_iNumMagicAll = 0;
static int     s_iMagicCategory = kMagicCategoryClassic;
static WORD    s_wDefaultMagic = 0;

static int
MagicCategoryOf(
   WORD wMagic
)
{
   switch (wMagic)
   {
   /* 辅助 */
   case 297: case 298: case 299: case 300: case 301: case 302:
   case 306: case 307: case 308: case 309: case 310: case 311:
   case 392:
      return kMagicCategorySupport;

   /* 物理 */
   case 337: case 340: case 341: case 342: case 344: case 345:
   case 346: case 348: case 351: case 363: case 349: case 394:
      return kMagicCategoryPhysical;

   /* 五行：风/雷/水/火/土 */
   case 313: case 314: case 315:
   case 316: case 317: case 318: case 319: case 320:
   case 321: case 322: case 323: case 325:
   case 327: case 328: case 329: case 330: case 389:
   case 332: case 333: case 334: case 335: case 336:
      return kMagicCategoryElemental;

   /* 毒蛊（含巫咒） */
   case 303: case 304: case 305:
   case 352: case 354: case 372: case 374:
      return kMagicCategoryPoison;

   /* 其他：飞龙探云手；未知法术也归入这里，避免分类后消失 */
   default:
      return kMagicCategoryOther;
   }
}


static int
MagicCategoryCount(
   int iCategory
)
{
   int i;

   if (iCategory == kMagicCategoryClassic)
   {
      return g_iNumMagicAll;
   }

   {
      int n = 0;
      for (i = 0; i < g_iNumMagicAll; i++)
      {
         if (MagicCategoryOf(rgMagicItemAll[i].wMagic) == iCategory)
         {
            n++;
         }
      }
      return n;
   }
}

static VOID
MagicRebuildFiltered(
   VOID
)
{
   int i;

   g_iNumMagic = 0;
   g_iCurrentItem = 0;

   for (i = 0; i < g_iNumMagicAll; i++)
   {
      if (s_iMagicCategory == kMagicCategoryClassic ||
         MagicCategoryOf(rgMagicItemAll[i].wMagic) == s_iMagicCategory)
      {
         rgMagicItem[g_iNumMagic++] = rgMagicItemAll[i];
      }
   }

   for (i = 0; i < g_iNumMagic; i++)
   {
      if (rgMagicItem[i].wMagic == s_wDefaultMagic)
      {
         g_iCurrentItem = i;
         break;
      }
   }
}

static BOOL
MagicHandleCategoryKeys(
   VOID
)
{
   int iCategory = -2;

   if (g_InputState.dwKeyPress & kKeyNum0) iCategory = kMagicCategoryClassic;
   else if (g_InputState.dwKeyPress & kKeyNum1) iCategory = kMagicCategorySupport;
   else if (g_InputState.dwKeyPress & kKeyNum2) iCategory = kMagicCategoryPhysical;
   else if (g_InputState.dwKeyPress & kKeyNum3) iCategory = kMagicCategoryElemental;
   else if (g_InputState.dwKeyPress & kKeyNum4) iCategory = kMagicCategoryPoison;
   else if (g_InputState.dwKeyPress & kKeyNum5) iCategory = kMagicCategoryOther;

   if (iCategory == -2)
   {
      return FALSE;
   }

   if (iCategory != s_iMagicCategory)
   {
      s_iMagicCategory = iCategory;
      MagicRebuildFiltered();
   }

   return TRUE;
}

static VOID
MagicDrawCategoryBar(
   int iBoxYOffset
)
{
   static const WCHAR *rgLabels[5] =
   {
      L"1輔助", L"2物理", L"3五行", L"4毒蠱", L"5其他"
   };
   int i, y;

   /* The list box is one row taller; draw the category row inside it. */
   y = 132 + iBoxYOffset;

   for (i = 0; i < 5; i++)
   {
      int x = 18 + i * 50;
      BYTE bColor = MENUITEM_COLOR;

      if (MagicCategoryCount(i) == 0)
      {
         bColor = MENUITEM_COLOR_INACTIVE;
      }

      PAL_DrawText(rgLabels[i], PAL_XY(x, y),
         (s_iMagicCategory == i) ? MENUITEM_COLOR_SELECTED : bColor,
         TRUE, FALSE, FALSE);
   }

   PAL_DrawText(L"0經典", PAL_XY(268, y),
      (s_iMagicCategory == kMagicCategoryClassic) ? MENUITEM_COLOR_SELECTED : MENUITEM_COLOR,
      TRUE, FALSE, FALSE);
}

static VOID
MagicDrawProficiency(
   VOID
)
{
   WCHAR szText[64];
   WORD  wMagic, wProf, wThreshold;

   if (g_iNumMagic <= 0 || g_iCurrentItem < 0 || g_iCurrentItem >= g_iNumMagic)
   {
      return;
   }

   wMagic = rgMagicItem[g_iCurrentItem].wMagic;
   wProf = MAGICPROF_Get(g_wMagicRole, wMagic);
   wThreshold = MAGICPROF_GetThreshold(wMagic);

   if (wProf >= wThreshold)
   {
      PAL_swprintf(szText, sizeof(szText) / sizeof(WCHAR),
         L"熟練度 %u/999  已精通", wProf);
   }
   else
   {
      PAL_swprintf(szText, sizeof(szText) / sizeof(WCHAR),
         L"熟練度 %u/999", wProf);
   }

   /*
    * White text in the description area.  The exact y depends on whether the
    * object description is present; keep it above the spell panel.
    */
   PAL_DrawText(szText, PAL_XY(102, 30), 0x3F, TRUE, FALSE, FALSE);
}

static VOID
MagicDrawArtifactBonus(
   VOID
)
{
   WCHAR szBonus[256];

   if (g_iNumMagic <= 0 || g_iCurrentItem < 0 || g_iCurrentItem >= g_iNumMagic)
   {
      return;
   }

   if (CUSTOMSPELL_IsCustom(rgMagicItem[g_iCurrentItem].wMagic))
   {
      PAL_DrawText(CUSTOMSPELL_GetShortDesc(), PAL_XY(10, 150), 0x1B, TRUE, FALSE, FALSE);
      return;
   }

   if (ART_GetMagicBonusText(g_wMagicRole, rgMagicItem[g_iCurrentItem].wMagic,
      szBonus, sizeof(szBonus) / sizeof(WCHAR)))
   {
      PAL_DrawText(szBonus, PAL_XY(10, 150), 0x5F, TRUE, FALSE, FALSE);
   }
}

WORD
PAL_MagicSelectionMenuUpdate(
   VOID
)
/*++
  Purpose:

    Update the magic selection menu.

  Parameters:

    None.

  Return value:

    The selected magic. 0 if cancelled, 0xFFFF if not confirmed.

--*/
{
   int         i, j, k, line, item_delta;
   BYTE        bColor;
   WORD        wScript;
   const int   iItemsPerLine = 32 / gConfig.dwWordLength;
   const int   iItemTextWidth = 8 * gConfig.dwWordLength + 7;
   const int   iLinesPerPage = 5 - gConfig.ScreenLayout.ExtraMagicDescLines;
   const int   iBoxYOffset = gConfig.ScreenLayout.ExtraMagicDescLines * 16;
   const int   iCursorXOffset = gConfig.dwWordLength * 5 / 2;
   const int   iPageLineOffset = iLinesPerPage / 2;

   //
   // Category hotkeys: 1..5 filter, 0 = classic list.
   //
   if (MagicHandleCategoryKeys())
   {
      return 0xFFFF;
   }

   //
   // Empty category: show a short message and keep the category bar usable.
   //
   if (g_iNumMagic == 0)
   {
      PAL_CreateBoxWithShadow(PAL_XY(10, 42 + iBoxYOffset), iLinesPerPage, 16, 1, FALSE, 0);
      PAL_DrawText(L"無", PAL_XY(150, 60 + iBoxYOffset), MENUITEM_COLOR_INACTIVE, TRUE, FALSE, FALSE);
      MagicDrawCategoryBar(iBoxYOffset);

      if (g_InputState.dwKeyPress & kKeyMenu)
      {
         return 0;
      }

      return 0xFFFF;
   }

   //
   // Check for inputs
   //
   if (g_InputState.dwKeyPress & kKeyUp)
   {
      item_delta = -iItemsPerLine;
   }
   else if (g_InputState.dwKeyPress & kKeyDown)
   {
      item_delta = iItemsPerLine;
   }
   else if (g_InputState.dwKeyPress & kKeyLeft)
   {
      item_delta = -1;
   }
   else if (g_InputState.dwKeyPress & kKeyRight)
   {
      item_delta = 1;
   }
   else if (g_InputState.dwKeyPress & kKeyPgUp)
   {
      item_delta = -(iItemsPerLine * iLinesPerPage);
   }
   else if (g_InputState.dwKeyPress & kKeyPgDn)
   {
      item_delta = iItemsPerLine * iLinesPerPage;
   }
   else if (g_InputState.dwKeyPress & kKeyHome)
   {
      item_delta = -g_iCurrentItem;
   }
   else if (g_InputState.dwKeyPress & kKeyEnd)
   {
      item_delta = g_iNumMagic - g_iCurrentItem - 1;
   }
   else if (g_InputState.dwKeyPress & kKeyMenu)
   {
      return 0;
   }
   else
   {
      item_delta = 0;
   }

   //
   // Make sure the current menu item index is in bound
   //
   if (g_iCurrentItem + item_delta < 0)
      g_iCurrentItem = 0;
   else if (g_iCurrentItem + item_delta >= g_iNumMagic)
      g_iCurrentItem = g_iNumMagic-1;
   else
      g_iCurrentItem += item_delta;

   //
   // Create the box.
   //
   PAL_CreateBoxWithShadow(PAL_XY(10, 42 + iBoxYOffset), iLinesPerPage, 16, 1, FALSE, 0);

   if (!gConfig.fIsWIN95)
   {
      if (gpGlobals->lpObjectDesc == NULL)
      {
         //
         // Draw the cash amount.
         //
         PAL_CreateSingleLineBox(PAL_XY(0, 0), 5, FALSE);
         PAL_DrawText(PAL_GetWord(CASH_LABEL), PAL_XY(10, 10), 0, FALSE, FALSE, FALSE);
         PAL_DrawNumber(gpGlobals->dwCash, 6, PAL_XY(49, 14), kNumColorYellow, kNumAlignRight);

         //
         // Draw the MP of the selected magic.
         //
         PAL_CreateSingleLineBox(PAL_XY(215, 0), 5, FALSE);
         PAL_RLEBlitToSurface(PAL_SpriteGetFrame(gpSpriteUI, SPRITENUM_SLASH),
            gpScreen, PAL_XY(260, 14));
         PAL_DrawNumber(rgMagicItem[g_iCurrentItem].wMP, 4, PAL_XY(230, 14),
            kNumColorYellow, kNumAlignRight);
         PAL_DrawNumber(g_wPlayerMP, 4, PAL_XY(265, 14), kNumColorCyan, kNumAlignRight);
      }
      else
      {
         WCHAR szDesc[512], *next;
         const WCHAR *d = PAL_GetObjectDesc(gpGlobals->lpObjectDesc, rgMagicItem[g_iCurrentItem].wMagic);

         //
         // Draw the magic description.
         //
         if (d != NULL)
         {
            k = 3;
		    wcscpy(szDesc, d);
            d = szDesc;

            while (TRUE)
            {
               next = wcschr(d, '*');
               if (next != NULL)
               {
                  *next++ = '\0';
               }

               PAL_DrawText(d, PAL_XY(102, k), DESCTEXT_COLOR, TRUE, FALSE, FALSE);
               k += 16;

               if (next == NULL)
               {
                  break;
               }

               d = next;
            }
         }

         //
         // Draw the MP of the selected magic.
         //
         PAL_CreateSingleLineBox(PAL_XY(0, 0), 5, FALSE);
         PAL_RLEBlitToSurface(PAL_SpriteGetFrame(gpSpriteUI, SPRITENUM_SLASH),
            gpScreen, PAL_XY(45, 14));
         PAL_DrawNumber(rgMagicItem[g_iCurrentItem].wMP, 4, PAL_XY(15, 14),
            kNumColorYellow, kNumAlignRight);
         PAL_DrawNumber(g_wPlayerMP, 4, PAL_XY(50, 14), kNumColorCyan, kNumAlignRight);
      }
   }
   else
   {
      wScript = gpGlobals->g.rgObject[rgMagicItem[g_iCurrentItem].wMagic].item.wScriptDesc;
      line = 0;
      while (wScript && gpGlobals->g.lprgScriptEntry[wScript].wOperation != 0)
      {
         if (gpGlobals->g.lprgScriptEntry[wScript].wOperation == 0xFFFF)
         {
            int line_incr = (gpGlobals->g.lprgScriptEntry[wScript].rgwOperand[1] != 1) ? 1 : 0;
            wScript = PAL_RunAutoScript(wScript, line);
            line += line_incr;
	     }
         else
         {
            wScript = PAL_RunAutoScript(wScript, 0);
         }
      }

      //
      // Draw the MP of the selected magic.
      //
      PAL_CreateSingleLineBox(PAL_XY(0, 0), PAL_X(gConfig.ScreenLayout.MagicMPDescLines), FALSE);
      PAL_RLEBlitToSurface(PAL_SpriteGetFrame(gpSpriteUI, SPRITENUM_SLASH),
          gpScreen, gConfig.ScreenLayout.MagicMPSlashPos);
      PAL_DrawNumber(rgMagicItem[g_iCurrentItem].wMP, 4, gConfig.ScreenLayout.MagicMPNeededPos,
          kNumColorYellow, kNumAlignRight);
      PAL_DrawNumber(g_wPlayerMP, 4, gConfig.ScreenLayout.MagicMPCurrentPos, kNumColorCyan, kNumAlignRight);
   }


   //
   // Draw the texts of the current page
   //
   i = g_iCurrentItem / iItemsPerLine * iItemsPerLine - iItemsPerLine * iPageLineOffset;
   if (i < 0)
   {
      i = 0;
   }

   for (j = 0; j < iLinesPerPage; j++)
   {
      for (k = 0; k < iItemsPerLine; k++)
      {
         bColor = MENUITEM_COLOR;

         if (i >= g_iNumMagic)
         {
            //
            // End of the list reached
            //
            j = iLinesPerPage;
            break;
         }

         if (i == g_iCurrentItem)
         {
            if (rgMagicItem[i].fEnabled)
            {
               bColor = MENUITEM_COLOR_SELECTED;
            }
            else
            {
               bColor = MENUITEM_COLOR_SELECTED_INACTIVE;
            }
         }
         else if (!rgMagicItem[i].fEnabled)
         {
            bColor = MENUITEM_COLOR_INACTIVE;
         }

         //
         // Draw the text
         //
         PAL_DrawText(PAL_GetWord(rgMagicItem[i].wMagic), PAL_XY(35 + k * iItemTextWidth, 54 + j * 16 + iBoxYOffset), bColor, TRUE, FALSE, FALSE);

         //
         // Draw the cursor on the current selected item
         //
         if (i == g_iCurrentItem)
         {
            PAL_RLEBlitToSurface(PAL_SpriteGetFrame(gpSpriteUI, SPRITENUM_CURSOR),
               gpScreen, PAL_XY(35 + iCursorXOffset + k * iItemTextWidth, 64 + j * 16 + iBoxYOffset));
         }

         i++;
      }
   }

   MagicDrawProficiency();
   MagicDrawArtifactBonus();
   MagicDrawCategoryBar(iBoxYOffset);

   if (g_InputState.dwKeyPress & kKeySearch)
   {
      if (rgMagicItem[g_iCurrentItem].fEnabled)
      {
         j = g_iCurrentItem % iItemsPerLine;
         k = (g_iCurrentItem < iItemsPerLine * iPageLineOffset) ? (g_iCurrentItem / iItemsPerLine) : iPageLineOffset;

         j = 35 + j * iItemTextWidth;
         k = 54 + k * 16 + iBoxYOffset;

         PAL_DrawText(PAL_GetWord(rgMagicItem[g_iCurrentItem].wMagic), PAL_XY(j, k), MENUITEM_COLOR_CONFIRMED, FALSE, TRUE, FALSE);

         //
         // Draw the cursor on the current selected item
         //
         PAL_RLEBlitToSurface(PAL_SpriteGetFrame(gpSpriteUI, SPRITENUM_CURSOR), gpScreen, PAL_XY(j + iCursorXOffset, k + 10));

         return rgMagicItem[g_iCurrentItem].wMagic;
      }
   }

   return 0xFFFF;
}

VOID
PAL_MagicSelectionMenuInit(
   WORD         wPlayerRole,
   BOOL         fInBattle,
   WORD         wDefaultMagic
)
/*++
  Purpose:

    Initialize the magic selection menu.

  Parameters:

    [IN]  wPlayerRole - the player ID.

    [IN]  fInBattle - TRUE if in battle, FALSE if not.

    [IN]  wDefaultMagic - the default magic item.

  Return value:

    None.

--*/
{
   WORD       w;
   int        i, j;

   g_iCurrentItem = 0;
   g_iNumMagic = 0;
   g_iNumMagicAll = 0;
   s_iMagicCategory = kMagicCategoryClassic;
   s_wDefaultMagic = wDefaultMagic;

   g_wPlayerMP = gpGlobals->g.PlayerRoles.rgwMP[wPlayerRole];
   g_wMagicRole = wPlayerRole;

   //
   // Put all magics of this player to the array
   //
   for (i = 0; i < MAX_PLAYER_MAGICS; i++)
   {
      w = gpGlobals->g.PlayerRoles.rgwMagic[i][wPlayerRole];
      if (w != 0)
      {
         rgMagicItemAll[g_iNumMagicAll].wMagic = w;

         w = gpGlobals->g.rgObject[w].magic.wMagicNumber;
         rgMagicItemAll[g_iNumMagicAll].wMP = gpGlobals->g.lprgMagic[w].wCostMP;

         rgMagicItemAll[g_iNumMagicAll].fEnabled = TRUE;

         if (rgMagicItemAll[g_iNumMagicAll].wMP > g_wPlayerMP)
         {
            rgMagicItemAll[g_iNumMagicAll].fEnabled = FALSE;
         }

         w = gpGlobals->g.rgObject[rgMagicItemAll[g_iNumMagicAll].wMagic].magic.wFlags;
         if (fInBattle)
         {
            if (!(w & kMagicFlagUsableInBattle))
            {
               rgMagicItemAll[g_iNumMagicAll].fEnabled = FALSE;
            }
         }
         else
         {
            if (!(w & kMagicFlagUsableOutsideBattle))
            {
               rgMagicItemAll[g_iNumMagicAll].fEnabled = FALSE;
            }
         }

         g_iNumMagicAll++;
      }
   }

   //
   // Sort the full array by object id (classic order)
   //
   for (i = 0; i < g_iNumMagicAll - 1; i++)
   {
      BOOL fCompleted = TRUE;

      for (j = 0; j < g_iNumMagicAll - 1 - i; j++)
      {
         if (rgMagicItemAll[j].wMagic > rgMagicItemAll[j + 1].wMagic)
         {
            struct MAGICITEM t = rgMagicItemAll[j];
            rgMagicItemAll[j] = rgMagicItemAll[j + 1];
            rgMagicItemAll[j + 1] = t;

            fCompleted = FALSE;
         }
      }

      if (fCompleted)
      {
         break;
      }
   }

   //
   // Default: classic list.  Category keys rebuild the filtered view.
   //
   MagicRebuildFiltered();
}

WORD
PAL_MagicSelectionMenu(
   WORD         wPlayerRole,
   BOOL         fInBattle,
   WORD         wDefaultMagic
)
/*++
  Purpose:

    Show the magic selection menu.

  Parameters:

    [IN]  wPlayerRole - the player ID.

    [IN]  fInBattle - TRUE if in battle, FALSE if not.

    [IN]  wDefaultMagic - the default magic item.

  Return value:

    The selected magic. 0 if cancelled.

--*/
{
   WORD            w;
   int             i;
   DWORD           dwTime;

   PAL_MagicSelectionMenuInit(wPlayerRole, fInBattle, wDefaultMagic);
   PAL_ClearKeyState();

   dwTime = SDL_GetTicks();

   while (TRUE)
   {
      PAL_MakeScene();

      w = 45;

      for (i = 0; i <= gpGlobals->wMaxPartyMemberIndex; i++)
      {
         PAL_PlayerInfoBox(PAL_XY(w, 165), gpGlobals->rgParty[i].wPlayerRole, 100,
            TIMEMETER_COLOR_DEFAULT, FALSE);
         w += 78;
      }

      w = PAL_MagicSelectionMenuUpdate();
      VIDEO_UpdateScreen(NULL);

      PAL_ClearKeyState();

      if (w != 0xFFFF)
      {
         return w;
      }

      PAL_ProcessEvent();
      while (!SDL_TICKS_PASSED(SDL_GetTicks(), dwTime))
      {
         PAL_ProcessEvent();
         if (g_InputState.dwKeyPress != 0)
         {
            break;
         }
         SDL_Delay(5);
      }

      dwTime = SDL_GetTicks() + FRAME_TIME;
   }

   return 0; // should not really reach here
}
