#ifndef _CUSTOM_SPELL_H
#define _CUSTOM_SPELL_H

#include "common.h"

#ifdef __cplusplus
extern "C" {
#endif

#define CUSTOMSPELL_OBJECT_ID 599

VOID
CUSTOMSPELL_Init(
   VOID
);

BOOL
CUSTOMSPELL_IsCustom(
   WORD wObject
);

WORD
CUSTOMSPELL_GetObjectID(
   VOID
);

LPCWSTR
CUSTOMSPELL_GetName(
   VOID
);

LPCWSTR
CUSTOMSPELL_GetShortDesc(
   VOID
);

LPCWSTR
CUSTOMSPELL_GetDesc(
   VOID
);

VOID
CUSTOMSPELL_PlayAnimation(
   WORD wPlayerIndex
);

VOID
CUSTOMSPELL_Apply(
   WORD wPlayerRole
);

#ifdef __cplusplus
}
#endif

#endif
