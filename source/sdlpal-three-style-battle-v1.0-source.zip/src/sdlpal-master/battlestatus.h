#ifndef _BATTLE_STATUS_H
#define _BATTLE_STATUS_H

#include "common.h"
#include "battle.h"

/*
 * Five-stat battle status system for the new "五靈鎮嶽" spell.
 *
 * The original game only has a handful of generic statuses.  This module
 * keeps the WU/FANG/SU/YUN/LING (武/防/速/運/靈) presentation separate from
 * the artifact buff strip so that the HUD can show only the five classic
 * stat arrows, while the full artifact list stays on key 5.
 */

#ifdef __cplusplus
extern "C" {
#endif

#define BTLSTAT_COUNT 5

enum
{
   BTLSTAT_ATK = 0,  /* 武 */
   BTLSTAT_DEF,      /* 防 */
   BTLSTAT_DEX,      /* 速 */
   BTLSTAT_LUK,      /* 運 */
   BTLSTAT_SPR       /* 靈 */
};

VOID
BTLSTAT_Reset(
   VOID
);

VOID
BTLSTAT_ApplyEnemyDebuff(
   WORD wEnemyIndex,
   WORD wTurns
);

VOID
BTLSTAT_OnEnemyTurn(
   WORD wEnemyIndex
);

WORD
BTLSTAT_GetEnemyDebuffTurns(
   WORD wEnemyIndex
);

BOOL
BTLSTAT_HasAnyEnemyDebuff(
   VOID
);

VOID
BTLSTAT_DrawEnemyBadges(
   VOID
);

VOID
BTLSTAT_DrawPlayerBadges(
   WORD wRole,
   int iX,
   int iY
);

#ifdef __cplusplus
}
#endif

#endif
