/*
 * SDLPAL Action Bar (PAL3-style A/B gauge) - public interface
 *
 * P0: shared A/B gauge + split threshold + wait-mode pause support.
 * P1/P2: B-phase chanting hooks.
 * P3+: compact layout (no black panel, party above / enemies below).
 */

#ifndef ACTIONBAR_H
#define ACTIONBAR_H

#include "common.h"

/*
 * Compact layout (320x200):
 *   y=0..11   party 12x12 downscaled faces
 *   y=12      party ready/chant underline
 *   y=13..14  shared A/B rail (red A, blue B)
 *   y=15..20  enemy 4x4 markers (1px dark outline)
 *   total     AB_HEIGHT = 21 pixels (~10% of screen height)
 */
#define AB_HEIGHT        21
#define AB_TRACK_X       8
#define AB_TRACK_W       304
#define AB_TRACK_Y       13
#define AB_FACE_W        12
#define AB_FACE_H        12
#define AB_FACE_Y        0
#define AB_ENEMY_Y       16
#define AB_ENEMY_SIZE    4

#define AB_DEFAULT_SPLIT 80

PAL_C_LINKAGE_BEGIN

VOID
AB_Reset(
   VOID
);

VOID
AB_OnBattleStart(
   VOID
);

VOID
AB_Draw(
   VOID
);

INT
AB_GetActionSplit(
   VOID
);

BOOL
AB_IsEnabled(
   VOID
);

BOOL
AB_IsWaitMode(
   VOID
);

VOID
AB_SetMenuPaused(
   BOOL fPaused
);

BOOL
AB_IsMenuPaused(
   VOID
);

/*
 * B-phase (chanting) interface. These are called by the battle engine in
 * P1/P2; they remain available for external extensions.
 */
BOOL
AB_IsChanting(
   WORD wIndex,
   BOOL fEnemy
);

VOID
AB_OnChantStart(
   WORD wIndex,
   BOOL fEnemy,
   WORD wMagic
);

VOID
AB_OnChantInterrupt(
   WORD wIndex,
   BOOL fEnemy
);

FLOAT
AB_GetChantSpeedDivisor(
   VOID
);

PAL_C_LINKAGE_END

#endif
