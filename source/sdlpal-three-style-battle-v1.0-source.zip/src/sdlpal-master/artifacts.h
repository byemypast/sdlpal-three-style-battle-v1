#ifndef ARTIFACTS_H
#define ARTIFACTS_H

#include "common.h"
#include "magicprof.h"

#define MAX_ARTIFACTS          999
#define ARTIFACT_SLOTS         3
#define ARTIFACT_MAX_AFFIXES   5

#define ARTIFACT_QUALITY_WHITE 0
#define ARTIFACT_QUALITY_BLUE  1
#define ARTIFACT_QUALITY_RED   2
#define ARTIFACT_QUALITY_GOLD  3

enum
{
   ART_DMG_PHYSICAL = 0,
   ART_DMG_FIRE,
   ART_DMG_WIND,
   ART_DMG_LIGHTNING,
   ART_DMG_WATER,
   ART_DMG_EARTH,
   ART_DMG_POISON,
   ART_DMG_OTHER
};

typedef struct tagARTIFACT_AFFIX
{
   WORD wAffix;
   WORD wValue;
   BYTE bTier;
} ARTIFACT_AFFIX;

typedef struct tagARTIFACT_INSTANCE
{
   BOOL  fUsed;
   WORD  wTemplate;
   BYTE  bQuality;
   BYTE  bAffixCount;
   ARTIFACT_AFFIX affixes[ARTIFACT_MAX_AFFIXES];
} ARTIFACT_INSTANCE;

typedef struct tagARTIFACT_DROP
{
   ARTIFACT_INSTANCE instance;
   BOOL fKept;
   BOOL fAutoDismantled;
   DWORD dwLingChen;
} ARTIFACT_DROP;

PAL_C_LINKAGE_BEGIN

VOID
ART_Init(
   VOID
);

VOID
ART_Reset(
   VOID
);

BOOL
ART_LoadSidecar(
   int iSaveSlot
);

BOOL
ART_SaveSidecar(
   int iSaveSlot
);

ARTIFACT_INSTANCE *
ART_GetInstance(
   int iIndex
);

LPCWSTR
ART_GetTemplateName(
   WORD wTemplate
);

WORD
ART_GetTemplateBitmap(
   WORD wTemplate
);

LPCWSTR
ART_GetQualityName(
   BYTE bQuality
);

BYTE
ART_GetQualityColor(
   BYTE bQuality
);

LPCWSTR
ART_GetAffixName(
   WORD wAffix
);

VOID
ART_GetAffixDesc(
   const ARTIFACT_INSTANCE *lpInstance,
   int iAffix,
   LPWSTR lpBuffer,
   int iBufferChars
);

INT
ART_GetFirstFreeBagSlot(
   VOID
);

INT
ART_AddInstance(
   const ARTIFACT_INSTANCE *lpInstance,
   BOOL *pfAutoDismantled
);

VOID
ART_RemoveInstance(
   int iIndex
);

BOOL
ART_IsInstanceEquipped(
   int iIndex,
   int *piRole,
   int *piSlot
);

INT
ART_GetEquipped(
   int iRole,
   int iSlot
);

BOOL
ART_Equip(
   int iRole,
   int iSlot,
   int iIndex
);

VOID
ART_Unequip(
   int iRole,
   int iSlot
);

VOID
ART_Dismantle(
   int iIndex
);

DWORD
ART_GetLingChen(
   VOID
);

VOID
ART_AddLingChen(
   DWORD dwAmount
);

INT
ART_GetBagCount(
   VOID
);

INT
ART_GetBagIndexByOrdinal(
   int iOrdinal
);

INT
ART_GetUnequippedBagCount(
   VOID
);

INT
ART_GetUnequippedBagIndexByOrdinal(
   int iOrdinal
);


#define ART_BUFF_COUNT 16

/* Battle effect notices */
VOID
ART_NotifyEffect(
   LPCWSTR lpszText
);

BOOL
ART_GetBattleNotice(
   LPWSTR lpszBuffer,
   size_t iBufferChars
);

VOID
ART_DrawBattleNotices(
   VOID
);

VOID
ART_ClearBattleNotices(
   VOID
);

WORD
ART_GetBuffMask(
   WORD wRole
);

LPCWSTR
ART_GetBuffAbbrev(
   int iIndex
);

BOOL
ART_GetBuffDetail(
   WORD wRole,
   int iIndex,
   LPWSTR lpszBuffer,
   size_t iBufferChars
);

BOOL
ART_GetMagicBonusText(
   WORD wRole,
   WORD wMagicObject,
   LPWSTR lpszBuffer,
   size_t iBufferChars
);

VOID
ART_ShowBattleStatus(
   VOID
);

/* Combat hooks */
VOID
ART_OnBattleStart(
   VOID
);

VOID
ART_OnBattleEnd(
   VOID
);

VOID
ART_OnPlayerAction(
   VOID
);

BOOL
ART_IsChantUninterruptible(
   WORD wRole
);

WORD
ART_GetStartMeterBonus(
   WORD wRole
);

FLOAT
ART_GetSpeedMultiplier(
   WORD wRole
);

FLOAT
ART_GetPhysicalMultiplier(
   WORD wRole
);

WORD
ART_GetMultiHitCount(
   WORD wRole
);

BYTE
ART_GetComboChance(
   WORD wRole
);

BOOL
ART_ShouldFailSpell(
   WORD wRole
);

VOID
ART_ApplyPoisonHit(
   WORD wEnemyIndex
);

BOOL
ART_HasPoisonHit(
   WORD wRole
);

BOOL
ART_HasDamageMP(
   WORD wRole
);

BOOL
ART_HasElementAttack(
   WORD wRole
);

FLOAT
ART_GetMagicMultiplier(
   WORD wRole,
   WORD wMagicObject
);

BOOL
ART_HasProficiencyPower(
   WORD wRole
);

BOOL
ART_ShouldDisableInstant(
   WORD wRole
);

BOOL
ART_ShouldDisableChantSpeed(
   WORD wRole
);

FLOAT
ART_GetEnemySlowMultiplier(
   VOID
);

WORD
ART_GetIncomingDamage(
   WORD wRole,
   WORD wDamage,
   BYTE bType,
   WORD wAttackerEnemy
);

VOID
ART_OnPlayerDamaged(
   WORD wRole
);

BYTE
ART_GetMagicDamageType(
   WORD wMagicObject
);

BYTE
ART_GetItemSaveChance(
   WORD wRole
);

BYTE
ART_GetMagicCritChance(
   WORD wRole,
   WORD wMagicObject
);

VOID
ART_OnSuccessfulSpell(
   WORD wRole,
   WORD wMagicObject
);

BOOL
ART_IsAffixActive(
   int iRole,
   int iSlot,
   int iAffix
);

/* UI / drop */
VOID
ART_ShowMenu(
   VOID
);

VOID
ART_ShowBattleDrops(
   BOOL fBoss
);

VOID
ART_GenerateDrops(
   BOOL fBoss,
   ARTIFACT_DROP *pDrops,
   int *piCount
);

PAL_C_LINKAGE_END

#endif
