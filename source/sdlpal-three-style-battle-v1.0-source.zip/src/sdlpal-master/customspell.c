#include "main.h"
#include "battle.h"
#include "battlestatus.h"
#include "customspell.h"
#include "artifacts.h"
#include "text.h"

#include <math.h>

static WORD s_wCustomSpellObject = CUSTOMSPELL_OBJECT_ID;
static WORD s_wCustomSpellMagic = 0;
static WORD s_wSwordObject = 0;
static BOOL s_fInitialized = FALSE;

LPCWSTR
CUSTOMSPELL_GetName(
   VOID
)
{
   return L"五靈鎮嶽";
}

LPCWSTR
CUSTOMSPELL_GetShortDesc(
   VOID
)
{
   return L"50%全體五維降至80%·3回合";
}

LPCWSTR
CUSTOMSPELL_GetDesc(
   VOID
)
{
   return L"五靈鎮嶽：50%機率使敵方全體武/防/速/運/靈降至80%，持續3回合；真氣消耗同劍神。";
}

WORD
CUSTOMSPELL_GetObjectID(
   VOID
)
{
   return s_wCustomSpellObject;
}

BOOL
CUSTOMSPELL_IsCustom(
   WORD wObject
)
{
   return (wObject == s_wCustomSpellObject);
}

static WORD
CUSTOMSPELL_FindSwordGodMagic(
   VOID
)
{
   int i;

   for (i = 1; i < MAX_OBJECTS; i++)
   {
      LPCWSTR lpszName = PAL_GetWord((WORD)i);
      WORD wMagic = gpGlobals->g.rgObject[i].magic.wMagicNumber;

      if (lpszName != NULL && wMagic > 0 && wMagic < gpGlobals->g.nMagic &&
         (wcscmp(lpszName, L"劍神") == 0 || wcscmp(lpszName, L"剑神") == 0))
      {
         s_wSwordObject = (WORD)i;
         return wMagic;
      }
   }
   return 0;
}

static int
CUSTOMSPELL_FindRoleByName(
   LPCWSTR lpszName
)
{
   int role;

   for (role = 0; role < MAX_PLAYER_ROLES; role++)
   {
      LPCWSTR lpsz = PAL_GetWord(gpGlobals->g.PlayerRoles.rgwName[role]);
      if (lpsz != NULL && wcscmp(lpsz, lpszName) == 0)
      {
         return role;
      }
   }
   return -1;
}

static BOOL
CUSTOMSPELL_AddToRole(
   int iRole
)
{
   int i;

   if (iRole < 0 || iRole >= MAX_PLAYER_ROLES)
   {
      return FALSE;
   }

   for (i = 0; i < MAX_PLAYER_MAGICS; i++)
   {
      if (gpGlobals->g.PlayerRoles.rgwMagic[i][iRole] == s_wCustomSpellObject)
      {
         return TRUE;
      }
   }

   for (i = 0; i < MAX_PLAYER_MAGICS; i++)
   {
      if (gpGlobals->g.PlayerRoles.rgwMagic[i][iRole] == 0)
      {
         gpGlobals->g.PlayerRoles.rgwMagic[i][iRole] = s_wCustomSpellObject;
         return TRUE;
      }
   }

   gpGlobals->g.PlayerRoles.rgwMagic[MAX_PLAYER_MAGICS - 1][iRole] = s_wCustomSpellObject;
   return TRUE;
}

VOID
CUSTOMSPELL_Init(
   VOID
)
{
   WORD wSwordMagic;
   int i;
   int iAnuRole;

   s_fInitialized = TRUE;
   s_wCustomSpellObject = CUSTOMSPELL_OBJECT_ID;
   s_wSwordObject = 0;
   wSwordMagic = CUSTOMSPELL_FindSwordGodMagic();
   if (wSwordMagic == 0)
   {
      /* Fallback: first usable magic with a nonzero MP cost. */
      for (i = 1; i < gpGlobals->g.nMagic; i++)
      {
         if (gpGlobals->g.lprgMagic[i].wCostMP > 0)
         {
            wSwordMagic = (WORD)i;
            break;
         }
      }
   }
   s_wCustomSpellMagic = wSwordMagic;

   memset(&gpGlobals->g.rgObject[s_wCustomSpellObject].magic, 0,
      sizeof(gpGlobals->g.rgObject[s_wCustomSpellObject].magic));
   gpGlobals->g.rgObject[s_wCustomSpellObject].magic.wMagicNumber = wSwordMagic;
   gpGlobals->g.rgObject[s_wCustomSpellObject].magic.wFlags =
      (s_wSwordObject != 0) ? gpGlobals->g.rgObject[s_wSwordObject].magic.wFlags : 0;
   gpGlobals->g.rgObject[s_wCustomSpellObject].magic.wScriptOnUse = 0;
   gpGlobals->g.rgObject[s_wCustomSpellObject].magic.wScriptOnSuccess = 0;
   gpGlobals->g.rgObject[s_wCustomSpellObject].magic.wScriptDesc = 0;

   /*
    * New games assign the spell to Anu only.  Existing saves that already
    * contain the custom object in Li Xiaoyao's list are left untouched; this
    * keeps the current progress save working while new games no longer put it
    * on Li Xiaoyao.
    */
   iAnuRole = CUSTOMSPELL_FindRoleByName(L"阿奴");
   if (iAnuRole < 0)
   {
      iAnuRole = 3; /* PAL role order: Li, Zhao, Lin, Anu */
   }
   CUSTOMSPELL_AddToRole(iAnuRole);
}

static VOID
CUSTOMSPELL_PutPixel(
   SDL_Surface *lpSurface,
   int x,
   int y,
   Uint8 color
)
{
   Uint8 *pixels;

   if (lpSurface == NULL || x < 0 || y < 0 || x >= lpSurface->w || y >= lpSurface->h)
   {
      return;
   }
   pixels = (Uint8 *)lpSurface->pixels;
   pixels[y * lpSurface->pitch + x] = color;
}

static VOID
CUSTOMSPELL_Line(
   SDL_Surface *lpSurface,
   int x1,
   int y1,
   int x2,
   int y2,
   Uint8 color
)
{
   int dx = abs(x2 - x1);
   int dy = abs(y2 - y1);
   int sx = (x1 < x2) ? 1 : -1;
   int sy = (y1 < y2) ? 1 : -1;
   int err = dx - dy;

   while (TRUE)
   {
      CUSTOMSPELL_PutPixel(lpSurface, x1, y1, color);
      if (x1 == x2 && y1 == y2) break;
      if (2 * err > -dy) { err -= dy; x1 += sx; }
      if (2 * err < dx) { err += dx; y1 += sy; }
   }
}

static VOID
CUSTOMSPELL_Orb(
   SDL_Surface *lpSurface,
   int x,
   int y,
   int radius,
   Uint8 color
)
{
   int dx, dy;

   for (dy = -radius; dy <= radius; dy++)
   {
      for (dx = -radius; dx <= radius; dx++)
      {
         if (abs(dx) + abs(dy) <= radius)
         {
            CUSTOMSPELL_PutPixel(lpSurface, x + dx, y + dy, color);
         }
      }
   }
}

VOID
CUSTOMSPELL_PlayAnimation(
   WORD wPlayerIndex
)
{
   static const Uint8 rguiColor[5] = { 0x2C, 0x1B, 0x3F, 0x0C, 0x1A };
   static const LPCWSTR rgszElement[5] = { L"風", L"雷", L"水", L"火", L"土" };
   SDL_Surface *lpBackup;
   SDL_Rect rc;
   int i, t;

   (VOID)wPlayerIndex;

   UTIL_LogOutput(LOGLEVEL_DEBUG, "[SPELL] wuling anim-start\n");
   VIDEO_CopyEntireSurface(g_Battle.lpSceneBuf, gpScreen);
   lpBackup = VIDEO_CreateCompatibleSurface(gpScreen);
   if (lpBackup != NULL)
   {
      VIDEO_CopyEntireSurface(gpScreen, lpBackup);
   }

   for (t = 0; t < 16; t++)
   {
      if (lpBackup != NULL)
      {
         VIDEO_CopyEntireSurface(lpBackup, gpScreen);
      }

      /* Five rotating element diamonds. */
      for (i = 0; i < 5; i++)
      {
         static const int rgiAngle[5] = { -90, -18, 54, 126, 198 };
         int a = rgiAngle[i] + t * 6;
         int cx = 160 + (int)(cos(a * 3.14159265 / 180.0) * 50);
         int cy = 82 + (int)(sin(a * 3.14159265 / 180.0) * 50);
         int r = 4;
         int dy;
         for (dy = -r; dy <= r; dy++)
         {
            int half = r - abs(dy);
            rc.x = cx - half;
            rc.y = cy + dy;
            rc.w = half * 2 + 1;
            rc.h = 1;
            SDL_FillRect(gpScreen, &rc, rguiColor[i]);
         }
         PAL_DrawText(rgszElement[i], PAL_XY(cx - 8, cy - 24), rguiColor[i], TRUE, FALSE, FALSE);
      }

      /* Sword beam down the middle. */
      rc.x = 158;
      rc.y = 24;
      rc.w = 4;
      rc.h = 40 + t * 4;
      SDL_FillRect(gpScreen, &rc, 0x1B);
      rc.x = 159;
      rc.w = 2;
      SDL_FillRect(gpScreen, &rc, 0x0F);

      /* Expanding golden ring, drawn as four short bars. */
      rc.y = 80;
      rc.h = 2;
      rc.x = 160 - t * 3;
      rc.w = t * 6;
      SDL_FillRect(gpScreen, &rc, 0x1B);

      PAL_DrawText(L"五靈鎮嶽", PAL_XY(126, 2), 0x1B, TRUE, FALSE, FALSE);

      if (t == 10)
      {
         rc.x = 0;
         rc.y = 0;
         rc.w = 320;
         rc.h = 200;
         SDL_FillRect(gpScreen, &rc, 0x0F);
      }

      VIDEO_UpdateScreen(NULL);
      SDL_Delay(32);
      PAL_ProcessEvent();
   }

   VIDEO_CopyEntireSurface(g_Battle.lpSceneBuf, gpScreen);
   VIDEO_UpdateScreen(NULL);
   if (lpBackup != NULL)
   {
      VIDEO_FreeSurface(lpBackup);
   }
   UTIL_LogOutput(LOGLEVEL_DEBUG, "[SPELL] wuling anim-end\n");
}


VOID
CUSTOMSPELL_Apply(
   WORD wPlayerRole
)
{
   int i;

   (VOID)wPlayerRole;

   for (i = 0; i <= g_Battle.wMaxEnemyIndex; i++)
   {
      BATTLEENEMY *lpEnemy = &g_Battle.rgEnemy[i];

      if (lpEnemy->wObjectID == 0 || lpEnemy->e.wHealth == 0)
      {
         continue;
      }

      if (RandomLong(0, 99) < 50)
      {
         BTLSTAT_ApplyEnemyDebuff((WORD)i, 3);
         ART_NotifyEffect(L"[仙術] 五靈鎮嶽·武防速運靈↓");
         UTIL_LogOutput(LOGLEVEL_DEBUG, "[SPELL] wuling enemy=%d result=debuff turns=3\n", i);
      }
      else
      {
         ART_NotifyEffect(L"[仙術] 五靈鎮嶽·抵抗");
         UTIL_LogOutput(LOGLEVEL_DEBUG, "[SPELL] wuling enemy=%d result=resist\n", i);
      }
   }
}
