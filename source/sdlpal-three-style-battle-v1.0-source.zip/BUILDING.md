﻿# Building from source

This repository contains the modified SDLPAL source for the Windows x64 build.

Requirements:

- MinGW-w64 GCC with GNU Make
- SDL3 3.4.x development package
- The original PAL DOS game data for runtime (not included)

The build entry point used for this release is `src/sdlpal-master/win32/Makefile.dsh`.
It expects the SDL3 include/library paths to be configured for the local toolchain.
The binary release in the same GitHub release was built from this source tree.

The original game data is copyrighted by SoftStar / 大宇资讯 and is not included.
